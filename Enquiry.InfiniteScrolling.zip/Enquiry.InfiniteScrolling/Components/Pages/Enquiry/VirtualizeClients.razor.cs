﻿using Microsoft.AspNetCore.Components.Web.Virtualization;
using Microsoft.AspNetCore.Components;
using Enquiry.Blazor.Dtos;

namespace Enquiry.Blazor.Components.Pages.Enquiry
{
    public partial class VirtualizeClients
    {
        [Parameter]
        public List<ClientListDto> clients { get; set; }
        [Parameter]
        public int TotalSize { get; set; }
        [Parameter]
        public EventCallback<ClientListParameters> OnScroll { get; set; }

        private async ValueTask<ItemsProviderResult<ClientListDto>> LoadClients(ItemsProviderRequest request)
        {
            var productNum = Math.Min(request.Count, TotalSize - request.StartIndex);
            await OnScroll.InvokeAsync(new ClientListParameters
            {
                StartIndex = request.StartIndex,
                PageSize = productNum == 0 ? request.Count : productNum
            });
            return new ItemsProviderResult<ClientListDto>(clients, TotalSize);
        }
    }
}
