﻿using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Services.Interface;
using Enquiry.Blazor.StateManagement.Enquiry;
using Fluxor;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.QuickGrid;
using Microsoft.JSInterop;

namespace Enquiry.Blazor.Components.Pages.Enquiry
{
    public partial class Clients 
    {
        private readonly SemaphoreSlim _semaphore = new SemaphoreSlim(1, 1);

        [Inject]
        public IJSRuntime JSRuntime { get; set; }

        [Inject]
        IDispatcher Dispatcher { get; set; }

        [Inject]
        IState<ClientState> ClientState { get; set; }

        [Inject]
        protected IClient _client { get; set; }

        private string searchTerm = string.Empty;
        private GridItemsProvider<ClientListDto> itemsProvider;
        private Timer debounceTimer;
        private const int DebounceDelay = 500; // milliseconds

        protected override void OnInitialized()
        {
            base.OnInitialized();
            itemsProvider = GetClientItems;
        }

        private async ValueTask<GridItemsProviderResult<ClientListDto>> GetClientItems(GridItemsProviderRequest<ClientListDto> request)
        {
            await _semaphore.WaitAsync();
            try
            {
                int pageIndex = (request.StartIndex / (request.Count ?? 100)) + 1;

                // Check if data is already available for the requested range
                if (request.StartIndex + (request.Count ?? 100) <= ClientState.Value.Clients.Count)
                {
                    var items = ClientState.Value.Clients.Skip(request.StartIndex).Take(request.Count ?? 100).ToList();

                    return new GridItemsProviderResult<ClientListDto>
                    {
                        Items = items,
                        TotalItemCount = ClientState.Value.TotalSize
                    };
                }
                Dispatcher.Dispatch(new SetLoadingAction(true));

                // Dispatch action to load more data
                Dispatcher.Dispatch(new LoadClientsAction(pageIndex, request.Count ?? 100, searchTerm));
                if (ClientState.Value.TotalSize==0)
                    await Task.Delay(500);


                // Wait for state to update

                var clients =  ClientState.Value.Clients.Skip(request.StartIndex).Take(request.Count ?? 100).ToList();

                if (ClientState.Value.TotalSize==0)
                await Task.Delay(500);
                Dispatcher.Dispatch(new SetLoadingAction(false));


                return new GridItemsProviderResult<ClientListDto>
                {
                    Items = clients,
                    TotalItemCount = ClientState.Value.TotalSize
                };
            }
            finally
            {
                _semaphore.Release();

            }
        }

        private async Task<List<ClientListDto>> FetchItemsFromStateAsync(int startIndex, int count)
        {
            return await Task.Run(() =>
            {
                // Simulate async operation for retrieving items from ClientState
                return ClientState.Value.Clients.Skip(startIndex).Take(count).ToList();
            });
        }

        //private void OnStateChanged(object sender, EventArgs e)
        //{
        //    InvokeAsync(StateHasChanged);
        //}

        //public void Dispose()
        //{
        //    ClientState.StateChanged -= OnStateChanged;
        //}


        private async void OnSearchChanged(ChangeEventArgs e)
        {
            searchTerm = e.Value?.ToString() ?? string.Empty;

            debounceTimer?.Dispose();
            debounceTimer = new Timer(async _ =>
            {
                Dispatcher.Dispatch(new LoadClientsAction(0, 100, searchTerm));
                itemsProvider = GetClientItems;
                //await InvokeAsync(StateHasChanged);
            }, null, DebounceDelay, Timeout.Infinite);
        }


    }

}
