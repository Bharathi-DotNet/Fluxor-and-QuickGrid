﻿using Enquiry.Blazor.Helpers;
using Enquiry.Blazor.Keys;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Net.Http.Headers;

namespace Enquiry.Blazor.Extensions;

public static class AuthenticationExtensions
{
    public static IServiceCollection AddAsymmetricAuthentication(this IServiceCollection services)
    {
        var issuerSigningCertificate = new SigningIssuerCertificate();
        RsaSecurityKey issuerSigningKey = issuerSigningCertificate.GetIssuerSigningKey();
        services.AddAuthentication(authOptions =>
        {
            authOptions.DefaultChallengeScheme = "JWT_OR_COOKIE";
            authOptions.DefaultScheme = "JWT_OR_COOKIE";
            //authOptions.RequireAuthenticatedSignIn = false;
        })
            .AddCookie("Cookies", options =>
            {
                options.LoginPath = "/Login";
                options.AccessDeniedPath = "/Home/Error";
                options.LogoutPath = "/Login";
                options.ExpireTimeSpan = TimeSpan.FromDays(1);
            })
            .AddJwtBearer("Bearer", options =>
            {
                options.SaveToken = true;
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    //ValidIssuer = "https://localhost:44365",
                    //ValidAudience = "https://localhost:44365",
                    ValidateAudience = true,
                    ValidateIssuer = true,
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = issuerSigningKey,
                    LifetimeValidator = LifetimeValidator
                };
                options.Events = new JwtBearerEvents
                {
                    OnMessageReceived = context =>
                    {
                        // Optionally extract JWT from a cookie
                        var token = context.Request.Cookies[".AspNetCore.Cookies"];
                        if (!string.IsNullOrEmpty(token))
                        {
                            context.Token = token;  // Set the token from the cookie
                        }
                        return Task.CompletedTask;
                    }
                };
            }).AddPolicyScheme("JWT_OR_COOKIE", "JWT_OR_COOKIE", options =>
            {
                // runs on each request
                options.ForwardDefaultSelector = context =>
                {
                    // filter by auth type
                    string authorization = context.Request.Headers[HeaderNames.Authorization];
                    if (!string.IsNullOrEmpty(authorization) && authorization.StartsWith("Bearer "))
                        return JwtBearerDefaults.AuthenticationScheme;

                    //context.Request.Headers.Add("Cookie", context.Request.Cookies.ToString());
                    return CookieAuthenticationDefaults.AuthenticationScheme;
                };
            });

        services.AddAuthorization(options =>
        {
            options.AddPolicy("BdaManagerPolicy", policy =>
                policy.Requirements.Add(new PolicyRequirement("BDA", "Manager")));
            options.AddPolicy("BdaTeamLeadPolicy", policy =>
            policy.Requirements.Add(new PolicyRequirement("BDA", "Team Lead")));
            options.AddPolicy("BdaExecutivePolicy", policy =>
            policy.Requirements.Add(new PolicyRequirement("BDA", "Executive")));
            options.AddPolicy("PubManagerPolicy", policy =>
                policy.Requirements.Add(new PolicyRequirement("Publication", "Manager")));
            options.AddPolicy("PubTeamLeadPolicy", policy =>
            policy.Requirements.Add(new PolicyRequirement("Publication", "Team Lead")));
            options.AddPolicy("PubExecutivePolicy", policy =>
            policy.Requirements.Add(new PolicyRequirement("Publication", "Executive")));
            options.AddPolicy("TechManagerPolicy", policy =>
                policy.Requirements.Add(new PolicyRequirement("Tech", "Manager")));
            options.AddPolicy("TechTeamLeadPolicy", policy =>
            policy.Requirements.Add(new PolicyRequirement("Tech", "Team Lead")));
            options.AddPolicy("TechExecutivePolicy", policy =>
            policy.Requirements.Add(new PolicyRequirement("Tech", "Executive")));
            options.AddPolicy("ProgrammingManagerPolicy", policy =>
                policy.Requirements.Add(new PolicyRequirement("Programming", "Manager")));
            options.AddPolicy("ProgrammingTeamLeadPolicy", policy =>
            policy.Requirements.Add(new PolicyRequirement("Programming", "Team Lead")));
            options.AddPolicy("ProgrammingExecutivePolicy", policy =>
            policy.Requirements.Add(new PolicyRequirement("Programming", "Executive")));

        });

        services.AddSingleton<IAuthorizationHandler, PolicyHandler>();

        return services;
    }

    private static bool LifetimeValidator(DateTime? notBefore,
            DateTime? expires,
            SecurityToken securityToken,
            TokenValidationParameters validationParameters)
    {
        return expires != null && expires > DateTime.Now;
    }
}
