﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Enum
{
    public enum Department
    {
        BDA = 1, //Business Development Associate
        Tech, // Technical Expert
        Programming, // Programmer
        Publication
    }

    public enum Roles
    {
        Manager = 1,
        [Description("Team Lead")]
        TeamLead,
        Executive
    }
    public enum PhaseName
    {
        [DaysToDeadline(5)]
        [SecondDeadline(1)]
        [Display(Name = "Project Confirmation")]
        Project_Confirmation = 1,
        [DaysToDeadline(15)]
        [SecondDeadline(2)]
        [Display(Name = "Proposal")]
        Proposal,
        [DaysToDeadline(15)]
        [SecondDeadline(4)]
        [Display(Name = " Research Proposal")]
        Research_Proposal,
        [DaysToDeadline(30)]
        [SecondDeadline(8)]
        [Display(Name = "Review Paper writing")]
        Review_Paper_writing,
        [DaysToDeadline(35)]
        [SecondDeadline(6)]
        [Display(Name = "Scopus Paper writing")]
        Scopus_Paper_writing,
        [DaysToDeadline(35)]
        [SecondDeadline(7)]
        [Display(Name = "SCI Paper writing")]
        SCI_Paper_writing,
        [DaysToDeadline(35)]
        [SecondDeadline(9)]
        [Display(Name = "IEEE Paper writing")]
        IEEE_Paper_writing,
        [DaysToDeadline(35)]
        [SecondDeadline(6)]
        [Display(Name = "Scopus Paper Implementation")]
        Scopus_Paper_Implementation,
        [DaysToDeadline(35)]
        [SecondDeadline(7)]
        [Display(Name = "SCI Paper Implementation")]
        SCI_Paper_Implementation,
        [DaysToDeadline(35)]
        [SecondDeadline(9)]
        [Display(Name = "IEEE Paper Implementation")]
        IEEE_Paper_Implementation,
        [DaysToDeadline(35)]
        [SecondDeadline(7)]
        [Display(Name = "Only Implementation")]
        Only_Implementation,
        [DaysToDeadline(25)]
        [SecondDeadline(5)]
        [Display(Name = "Thesis 4 Chapters")]
        Thesis_4_Chapters,
        [DaysToDeadline(25)]
        [SecondDeadline(5)]
        [Display(Name = " Thesis 3 Chapters")]
        Thesis_3_Chapters,
        [DaysToDeadline(25)]
        [SecondDeadline(5)]
        [Display(Name = "Thesis 2 Chapters")]
        Thesis_2_Chapters,
        [DaysToDeadline(25)]
        [SecondDeadline(5)]
        [Display(Name = "Thesis 1 Chapters")]
        Thesis_1_Chapters,
        [DaysToDeadline(15)]
        [SecondDeadline(3)]
        [Display(Name = "Major Revision")]
        Major_Revision,
        [DaysToDeadline(15)]
        [SecondDeadline(2)]
        [Display(Name = "Minor Revision")]
        Minor_Revision,
        [DaysToDeadline(15)]
        [SecondDeadline(5)]
        [Display(Name = "Page Reduction")]
        Page_Reduction,
        [DaysToDeadline(15)]
        [SecondDeadline(2)]
        [Display(Name = "Synopsis")]
        Synopsis,
        [DaysToDeadline(2)]
        [SecondDeadline(1)]
        [Display(Name = "Client Modification")]
        Client_Modification
    }
    public enum PhaseName1
    {
        [Deadline(3)]
        [Display(Name = "Any Scopus Paid Publication")]
        Any_Scopus_Paid_Publication,
        [Deadline(5)]
        [Display(Name = "Any Scopus free Publication")]
        Any_Scopus_free_Publication,
        [Deadline(6)]
        [Display(Name = "Any SCI Paid Publication")]
        Any_SCI_Paid_Publication,
        [Deadline(9)]
        [Display(Name = "Any SCI free Publication")]
        Any_free_Publication,
        [Deadline(11)]
        [Display(Name = "Only Springer or Blsener")]
        Only_Springer_or_Blsener,
        [Deadline(9)]
        [Display(Name = "q3 or q4")]
        q3_or_q4,
        [Deadline(12)]
        [Display(Name = "q1 or q2")]
        q1_or_q2,
        [Deadline(18)]
        [Display(Name = "IEE")]
        IEE
    }
    [AttributeUsage(AttributeTargets.Field, Inherited = false, AllowMultiple = false)]
    sealed class DeadlineAttribute : Attribute
    {
        public int Month { get; }

        public DeadlineAttribute(int month)
        {
            Month = month;
        }
    }
    [AttributeUsage(AttributeTargets.Field, Inherited = false, AllowMultiple = false)]
    sealed class DaysToDeadlineAttribute : Attribute
    {
        public int Days { get; }

        public DaysToDeadlineAttribute(int days)
        {
            Days = days;
        }
    }
    [AttributeUsage(AttributeTargets.Field, Inherited = false, AllowMultiple = false)]
    sealed class SecondDeadlineAttribute : Attribute
    {
        public int Days { get; }

        public SecondDeadlineAttribute(int days)
        {
            Days = days;
        }
    }

}
