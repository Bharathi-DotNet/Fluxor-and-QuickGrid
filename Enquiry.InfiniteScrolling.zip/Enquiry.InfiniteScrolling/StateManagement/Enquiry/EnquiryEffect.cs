﻿using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Services.Interface;
using Fluxor;

namespace Enquiry.Blazor.StateManagement.Enquiry
{
    public class EnquiryEffect
    {
        private readonly SemaphoreSlim _semaphore = new SemaphoreSlim(1, 1);
        protected IClient _client { get; set; }
        public EnquiryEffect(IClient client)
        {
            _client = client;
        }


        [EffectMethod]
        public async Task HandleLoadClientsAction(LoadClientsAction action, IDispatcher dispatcher)
        {
            // Prevent simultaneous API calls with semaphore
            await _semaphore.WaitAsync();
            try
            {
                var response = await _client.GetVirtualizeClientsAsync('A',
                  new ClientListParameters
                  {
                      StartIndex = action.PageIndex,
                      PageSize = action.PageSize,
                      SearchTerm = action.SearchTerm
                  });

                if ( response.Data != null)
                {
                    dispatcher.Dispatch(new ClientsLoadedAction(response.Data.Items, response.Data.TotalSize, action.PageIndex));

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            finally
            {
                _semaphore.Release();
            }   
        }


    }
}
