﻿using Fluxor;


namespace Enquiry.Blazor.StateManagement.Enquiry
{
    public class EnquiryReducer
    {

      

        [ReducerMethod]
        public static ClientState ReduceClientsLoadedAction(ClientState state, ClientsLoadedAction action)
        {
            // Determine the updated client list
            var updatedClients = action.PageIndex == 0
                ? action.Items // Reset the list for a new search
                : state.Clients .Concat(action.Items).ToList();

            return state with
            {

                TotalSize = action.TotalSize,
                Clients = updatedClients
            };
        }


        [ReducerMethod]
        public static ClientState ReduceSetLoadingAction(ClientState state, SetLoadingAction action)
             {

            return state with { IsLoading = action.IsLoading
            };
        }


        //    [ReducerMethod]
        //    public static ClientState ReduceTriggerRefreshAction(ClientState state, TriggerRefreshAction action) =>
        //state with { NeedsRefresh = true };
        ////}
        ///

    }
}
