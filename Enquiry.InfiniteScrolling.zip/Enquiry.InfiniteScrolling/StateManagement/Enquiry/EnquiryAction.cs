﻿using Enquiry.Blazor.Dtos;

namespace Enquiry.Blazor.StateManagement.Enquiry
{
    public record LoadClientsAction(int PageIndex, int PageSize, string SearchTerm);
    public record ClientsLoadedAction(List<ClientListDto> Items, int TotalSize, int PageIndex);
    public record SetLoadingAction(bool IsLoading);
    //public record FetchDataAction;
    //    public record DataFetchedAction;
}
