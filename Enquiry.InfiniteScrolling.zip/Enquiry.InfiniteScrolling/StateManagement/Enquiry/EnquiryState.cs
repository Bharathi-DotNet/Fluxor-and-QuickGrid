﻿using Enquiry.Blazor.Dtos;
using Fluxor;

namespace Enquiry.Blazor.StateManagement.Enquiry
{

    //public record ClientState
    //{
    //    public List<ClientListDto> Clients { get; init; } = new List<ClientListDto>();
    //    public int TotalSize { get; init; }
    //    public int LastFetchedPage { get; init; } = 0; // Keep track of pages fetched
    //    public string SearchTerm { get; set; } = string.Empty;
    //    public bool IsDataLoaded { get; init; } = false; // New flag to track data loading
    //    public bool NeedsRefresh { get; init; } = false; // Add this property
    //    public bool IsLoading { get; set; }

    //}
    [FeatureState]

    public record ClientState
    {
        public List<ClientListDto> Clients { get; set; } = new List<ClientListDto>();
        public int TotalSize { get; set; }
        public bool IsLoading { get; set; }
    }

}
