﻿using Enquiry.Blazor.Models.Interface;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Enquiry.Blazor.Models
{
    public class PhaseExecution : IAuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PhaseExecutionId { get; set; }
        [ForeignKey("Employees")]
        public int EmpId { get; set; }        
        [ForeignKey("Phase")]
        public int PhaseId { get; set; }
        [ForeignKey("WorkStatus")]
        public int Status { get; set; }
        public DateTime? DemoDate { get; set; }
        public string Remarks { get; set; }
        public int Progress { get; set; }
        public int Priority { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        //public int? Score { get; set; }

        public virtual Employees Employees { get; set; }
        public virtual WorkStatus WorkStatus { get; set; }
        public virtual Phase Phase { get; set; }
    }
}
