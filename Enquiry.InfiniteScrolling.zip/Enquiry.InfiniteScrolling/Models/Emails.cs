﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Enquiry.Blazor.Models.Interface;

namespace Enquiry.Blazor.Models
{
    public class Emails : IAuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EmailId { get; set; }
        public string FromAddress { get; set; }
        public string ToAddress { get; set; }
        public string ClientName { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public DateTime ReceivedDate { get; set; }
        public bool IsRead { get; set; }
        public bool IsPublication { get; set; }
        [ForeignKey("Projects")]
        public int? ProjectId { get; set; }
        [ForeignKey("Clients")]
        public int? EnquiryId { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public bool IsSender { get; set; }
        public string MessageId { get; set; }
        public string UpdatedMessage { get; set; }
        public string MemberId { get; set; }
        public bool Visibility { get; set; }
        public bool IsTechVisibility { get; set; }
        public bool IsProgrammerVisibility { get; set; }
        public bool IsTrashMail { get; set; }

        public virtual Projects Projects { get; set; }
        public virtual Clients Clients { get; set; }
        public virtual ICollection<EmailAttachmentsFiles> EmailAttachmentsFiles { get; set; }
    }
}
