﻿using Enquiry.Blazor.Enum;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Enquiry.Blazor.Models
{
    public class PhaseStatus
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        public string PhaseName { get; set; }
        [Required]
        public int EmployeeDeadline { get; set; }
        [Required]
        public int ClientDeadline { get; set; }
        public bool IsMonthCalc { get; set; } = false;
        public bool IsScore { get; set; } = true;
        public bool OnlyForProgrammers { get; set; } = false;
        public bool OnlyForTech { get; set; } = false;
        public bool SpecialDeadline { get; set; } = false;
        public bool IsActive { get; set; }
        public bool SkipPublication { get; set; }
    }
}
