﻿using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Models
{
    public class StoreGoogleTokens
    {
        [Key]
        public int Tokens { get; set; }
        public int UserId { get; set; }
        public string Email { get; set; }
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
        public long ExpiresIn { get; set; }
        public DateTime ExpiryTime { get; set; }

    }
}
