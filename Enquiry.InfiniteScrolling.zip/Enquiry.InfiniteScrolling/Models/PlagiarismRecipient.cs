﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Enquiry.Blazor.Services;
using Enquiry.Blazor.Models.Interface;

namespace Enquiry.Blazor.Models
{
    public class PlagiarismRecipient: IAuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PlagiarismRecipientId { get; set; }

        [ForeignKey("Plagiarism")]
        public int PlagiarismId { get; set; }

        [ForeignKey("Employees")]
        public int EmployeeId { get; set; }

        public bool IsDownloaded { get; set; }
        public bool IsUploaded { get; set; }
        public string UploadedFileName { get; set; }
        public string UploadedFilePath { get; set; }
        public string StoreFileId { get; set; }
        public bool SentToSlack { get; set; }

        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }

        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }

        // Navigation properties
        public virtual Plagiarism Plagiarism { get; set; }
        public virtual Employees Employees { get; set; }
    }
}
