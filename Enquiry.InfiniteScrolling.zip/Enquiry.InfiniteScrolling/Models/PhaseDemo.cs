﻿using Enquiry.Blazor.Models.Interface;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Enquiry.Blazor.Helpers;

namespace Enquiry.Blazor.Models
{
    public class PhaseDemo : IAuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int DemoId { get; set; }
        [ForeignKey("Phase")]
        public int PhaseId { get; set; }
        [ForeignKey("Employees")]
        public int? EmpId { get; set; }
        [ForeignKey("Clients")]
        public int? ClientId { get; set; }
        public bool IsClient { get; set; }
        public string Link { get; set; }
        public string Feedback { get; set; }
        public bool Status { get; set; }  //1 for completed
        public bool IsMessageSent { get; set; }  //Slack message
        public bool IsDemoAgain { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }

        public virtual Phase Phase { get; set; }
        public virtual Employees Employees { get; set; }
        public virtual Clients Clients { get; set; }
    }
}
