﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Enquiry.Blazor.Models.Interface;

namespace Enquiry.Blazor.Models
{
    public class PhaseFiles : IAuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PhaseFileId { get; set; }
        [ForeignKey("Phase")]
        public int PhaseId { get; set; }
        [ForeignKey("Employees")]
        public int? EmpId { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
        public bool IsPublication { get; set; }
        public bool IsJournalComment { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }

        public virtual Phase Phase { get; set; }
        public virtual Employees Employees { get; set; }

    }
}
