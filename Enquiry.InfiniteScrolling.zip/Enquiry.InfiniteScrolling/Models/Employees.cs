﻿using Enquiry.Blazor.Models.Interface;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Enquiry.Blazor.Models;

public class Employees : IAuditableEntity
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int EmpId { get; set; }
    public string IdentityNo { get; set; }
    public string EmployeeName { get; set; }
    public string ContactNo { get; set; }
    public string Password { get; set; }
    public bool IsPasswordChanged { get; set; }
    public string EmailId { get; set; }
    public string Address { get; set; }
    public string MemberId { get; set; }
    public string Designation { get; set; }
    [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
    public DateTime DOB { get; set; }
    [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
    public DateTime DOJ { get; set; }
    [ForeignKey("Department")]
    public int DeptId { get; set; }
    [ForeignKey("Roles")]
    public int RoleId { get; set; }
    public int CreatedBy { get; set; }
    public int UpdatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public DateTime UpdatedDate { get; set; }
    public bool IsActive { get; set; }
    public virtual Roles Roles { get; set; }
    public virtual Department Department { get; set; }
    public int? SuperiorId { get; set; }
    public string EmployeePhotoUrl { get; set; }
    public string BirthdayPhotoUrl { get; set; }
    public string AnniversaryPhotoUrl { get; set; }
    public bool IsEnquiry { get; set; }
    public bool IsPlagiarismChecker { get; set; }
    public DateTime PlagiarismUpdatedDate { get; set; }
    public bool IsEmailChecker { get; set; }
    public DateTime EmailUpdatedDate { get; set; }
    public int? OtpGiven { get; set; }
    public string DeviceName { get; set; }
    public virtual ICollection<Projects> Projects { get; set; }
}
