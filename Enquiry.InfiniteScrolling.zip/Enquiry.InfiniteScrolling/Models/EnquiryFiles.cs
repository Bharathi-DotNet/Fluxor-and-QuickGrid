﻿using Enquiry.Blazor.Models.Interface;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Models
{
    public class EnquiryFiles : IAuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EnquiryFileId { get; set; }
        [ForeignKey("Clients")]
        public int EnquiryId { get; set; }
        [ForeignKey("Employees")]
        public int? EmpId { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
        public bool IsTech { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }

        public virtual Clients Clients { get; set; }
        public virtual Employees Employees { get; set; }
    }
}
