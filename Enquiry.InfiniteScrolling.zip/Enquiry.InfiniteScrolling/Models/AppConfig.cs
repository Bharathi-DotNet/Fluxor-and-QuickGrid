﻿namespace Enquiry.Blazor.Models
{
    public class SlackConfig
    {
        public string ApiToken { get; set; }
        public string SigningSecret { get; set; }
        public IList<string> EnquiryMail { get; set; }
        public IList<string> FeeApproval { get; set; }
        public IList<string> PublicationApproval { get; set; }
        public IList<string> JournalStatus { get; set; }
        public IList<string> PublicationFileUpload { get; set; }
        public IList<string> EnquiryEmailChecker { get; set; }
        public IList<string> ProductionEmailChecker { get; set; }
        public IList<string> PublicationEmailChecker { get; set; }
    }

    public class FtpConfig
    {
        public string FtpServer { get; set; }
        public string FtpUsername { get; set; }
        public string FtpPassword { get; set; }
        public string FtpPort { get; set; }
    }

    public class AssignTime
    {
        public int StartHour { get; set; }
        public int StartMinute { get; set; }
        public int EndHour { get; set; }
        public int EndMinute { get; set; }
    }
    public class ImapMailConfig
    {
        public string ImapServer { get; set; }
        public int Port { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string SmptServer { get; set; }
        public int SmptPort { get; set; }
    }

    public class GoogleAuthConfig
    {
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
    }
    public class IpConfig
    {
        public IList<string> IpAddress { get; set; }
    }
}
