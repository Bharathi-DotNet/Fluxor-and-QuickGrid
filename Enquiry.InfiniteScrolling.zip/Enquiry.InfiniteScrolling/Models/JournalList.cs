﻿using Enquiry.Blazor.Models.Interface;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Enquiry.Blazor.Models
{
    public class JournalList: IAuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int JournalId { get; set; }
        public string JournalName { get; set; }
        public string Link { get; set; }
        public string Publisher { get; set; }
        public string Index { get; set; }
        public string Domain { get; set; }
        public string Tags { get; set; }
        public DateTime VerifiedDate { get; set; }
        public int VerifiedBy { get; set; }
        public bool IsActive { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string Paid { get; set; }
    }
}
