﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Enquiry.Blazor.Models.Interface;

namespace Enquiry.Blazor.Models
{
    public class Feedback : IAuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int FeedbackId { get; set; }
        [ForeignKey("Employees")]
        public int? EmployeeId { get; set; }
        public string Scenario {  get; set; }
        public string EmpFeedback {  get; set; }
        public string Feedbacks { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public virtual Employees Employees { get; set; }

    }
}
