﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Enquiry.Blazor.Models.Interface;

namespace Enquiry.Blazor.Models
{
    public class PublicationHistory : IAuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int HistoryId { get; set; }
        [ForeignKey("Employees")]
        public int EmpId { get; set; }
        [ForeignKey("Publication")]
        public int PublicationId { get; set; }
        [ForeignKey("JournalStatus")]
        public int Status { get; set; }
        public string Comments { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }

        public virtual Employees Employees { get; set; }
        public virtual Publication Publication { get; set; }
        public virtual JournalStatus JournalStatus { get; set; }
    }
}
