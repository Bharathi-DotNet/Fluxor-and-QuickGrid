﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Models
{
    public class EmailAttachmentsFiles
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EmailAttachmentId { get; set; }
        [ForeignKey("Emails")]
        public int EmailId { get; set; }
        public string AttachmentFilePath { get; set; }
        public string AttachmentFileName { get; set; }
        public string OriginalUrl { get; set; }
        public string ShortUrl { get; set; }

        public bool IsSelected { get; set; }
        public virtual Emails Emails { get; set; }
    }
}
