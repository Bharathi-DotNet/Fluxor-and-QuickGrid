﻿using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Models
{
    public class WorkStatus
    {
        [Key]
        public int WorkStatusId { get; set; }
        public string WorkStatusName { get; set; }
        public bool IsActive { get; set; }
    }
}
