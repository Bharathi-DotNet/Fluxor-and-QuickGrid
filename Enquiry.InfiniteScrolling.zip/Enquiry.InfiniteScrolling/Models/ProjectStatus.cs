﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Models
{
    public class ProjectStatus
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ProjectStatusId { get; set; }
        [Required]
        public string ProjectName { get; set; }
        public string WorkType { get; set; }
        [Required]
        public double AgentPayment { get; set; }
        [Required]
        public double NormalPayment { get; set; }
        public int Incentive { get; set; }
        public int ReducedIncentive { get; set; }
    }
}
