﻿namespace Enquiry.Blazor.Models
{
    public class VoipCallHistory
    {
        public int Id { get; set; }
        public string Starttime { get; set; }
        public string Callid { get; set; }
        public string Emp_phone { get; set; }
        public string Clicktocalldid { get; set; }
        public string Callto { get; set; }
        public string Dialstatus { get; set; }
        public string Filename { get; set; }
        public string Direction { get; set; }
        public string Endtime { get; set; }
        public string Disconnectedby { get; set; }
        public string Answeredtime { get; set; }
        public string Groupname { get; set; }
        public string Agentname { get; set; }
    }
}
