﻿using Enquiry.Blazor.Models.Interface;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Models
{
    public class Data : IAuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int DataId { get; set; }
        public string Name { get; set; }
        public string Department { get; set; }
        public string PhoneNo1 { get; set; }
        public string PhoneNo2 { get; set; }
        public string Email1 { get; set; }
        public string Email2 { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string CallsStatus { get; set; }
        public string WhatsappStatus { get; set; }
        public string EmailStatus { get; set; }
        public DateTime CallsUpdatedDate { get; set; }
        public DateTime WhatsappUpdatedDate { get; set; }
        public DateTime EmailUpdatedDate { get; set; }

    }
}
