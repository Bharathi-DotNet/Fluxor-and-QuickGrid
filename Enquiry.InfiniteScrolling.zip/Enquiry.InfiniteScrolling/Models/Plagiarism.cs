﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Enquiry.Blazor.Models.Interface;
using Enquiry.Blazor.Services;

namespace Enquiry.Blazor.Models
{
    public class Plagiarism : IAuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PlagiarismId { get; set; }

        [ForeignKey("Employees")]
        public int UploadedEmpId { get; set; }

        [Required]
        public string UploadedFileName { get; set; }

        [Required]
        public string UploadedFilePath { get; set; }

        public bool IsDownloaded { get; set; }

        public string ClassName { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
        [ForeignKey("Phase")]
        public int? PhaseId { get; set; }
        [ForeignKey("Clients")]
        public int? EnquiryId { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }

        public virtual ICollection<PlagiarismRecipient> PlagiarismRecipients { get; set; }

        public virtual Employees Employees { get; set; }
        public virtual Phase Phase { get; set; }
        public virtual Clients Clients { get; set; }
    }
}
