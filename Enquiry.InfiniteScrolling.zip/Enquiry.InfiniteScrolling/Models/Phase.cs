﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Enquiry.Blazor.Models;

public class Phase
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int PhaseId { get; set; }
    public string PhaseName { get; set; }
    [ForeignKey("Projects")]
    public int ProjectId { get; set; }
    [ForeignKey("Employees")]
    public int? TechExpert { get; set; }
    [ForeignKey("Employees1")]
    public int? TechExpert1 { get; set; }
    [ForeignKey("Employees2")]
    public int? TechExpert2 { get; set; }
    [ForeignKey("Employees3")]
    public int? TechExpert3 { get; set; }
    [ForeignKey("Employees4")]
    public int? Programmer { get; set; }
    [ForeignKey("Employees5")]
    public int? Programmer1 { get; set; }
    public DateTime? DemoDate { get; set; }
    public DateTime? DemoDate1 { get; set; }
    public DateTime? DemoDate2 { get; set; }
    public DateTime? DemoDate3 { get; set; }
    public DateTime? DemoDate4 { get; set; }
    public DateTime? DemoDate5 { get; set; }
    public string Remarks { get; set; }
    public string Remarks1 { get; set; }
    public string Remarks2 { get; set; }
    public string Remarks3 { get; set; }
    public string Remarks4 { get; set; }
    public string Remarks5 { get; set; }
    public string PhaseRemark { get; set; }
    public int Progress { get; set; }
    public int Progress1 { get; set; }
    public int Progress2 { get; set; }
    public int Progress3 { get; set; }
    [ForeignKey("Priority")]
    public int? TechPriority { get; set; }
    [ForeignKey("Priority1")]
    public int? TechPriority1 { get; set; }
    [ForeignKey("Priority2")]
    public int? TechPriority2 { get; set; }
    [ForeignKey("Priority3")]
    public int? TechPriority3 { get; set; }
    [ForeignKey("Priority4")]
    public int? ProgrammerPriority { get; set; }
    [ForeignKey("Priority5")]
    public int? ProgrammerPriority1 { get; set; }
    public DateTime? DeadLine { get; set; }
    public DateTime? AssignedDate { get; set; }
    public double? DeadLineCount { get; set; }
    [ForeignKey("WorkStatus")]
    public int Status { get; set; }
    public DateTime? NextAppoinment { get; set; }
    public string Comment { get; set; }

    public bool TechStatus { get; set; }
    public bool TechStatus1 { get; set; }
    public bool TechStatus2 { get; set; }
    public bool TechStatus3 { get; set; }
    public int? TechTL { get; set; }
    public int? PgmTL { get; set; }
    public bool TechTLStatus { get; set; }
    public bool PgmTLStatus { get; set; }
    public bool ProgrammerStatus { get; set; }
    public bool ProgrammerStatus1 { get; set; }
    public bool IsProgrammerNeeded { get; set; }
    public bool IsTechNeeded { get; set; }
    public bool IsPublicationApproval { get; set; }
    public int? TechScore { get; set; }
    public int? TechScore1 { get; set; }
    public int? TechScore2 { get; set; }
    public int? TechScore3 { get; set; }
    public int? ProgrammerScore { get; set; }
    public int? ProgrammerScore1 { get; set; }

    public virtual Projects Projects { get; set; }
    public virtual Employees Employees { get; set; }
    public virtual Employees Employees1 { get; set; }
    public virtual Employees Employees2 { get; set; }
    public virtual Employees Employees3 { get; set; }
    public virtual Employees Employees4 { get; set; }
    public virtual Employees Employees5 { get; set; }
    public virtual WorkStatus WorkStatus { get; set; }
    public virtual Priority Priority { get; set; }
    public virtual Priority Priority1 { get; set; }
    public virtual Priority Priority2 { get; set; }
    public virtual Priority Priority3 { get; set; }
    public virtual Priority Priority4 { get; set; }
    public virtual Priority Priority5 { get; set; }
    public virtual ICollection<PhaseHistory> PhaseHistory { get; set; }
    public virtual ICollection<PhaseExecution> PhaseExecution { get; set; }
    public virtual ICollection<PhaseDemo> PhaseDemo { get; set; }
    public virtual ICollection<PhaseFiles> PhaseFiles { get; set; }
    public virtual ICollection<Plagiarism> Plagiarism { get; set; }
}

