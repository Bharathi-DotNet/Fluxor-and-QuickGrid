﻿using Enquiry.Blazor.Models.Interface;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Enquiry.Blazor.Models;

public class Clients : IAuditableEntity
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
   
    public int EnquiryId { get; set; }
    public string ClientName { get; set; }
    public string EnquiryRef { get; set; }
    public string Contact { get; set; }
    public string Domain { get; set; }
    [ForeignKey("TechEmployee")]
    public int? TechExpert { get; set; }
    [ForeignKey("BDAEmployee")]
    public int? BDA { get; set; }
    [ForeignKey("ProgrammerEmployee")]
    public int? Programmer { get; set; }
    public string PaymentRemarks { get; set; }
    public DateTime EnquiryDate { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? AppoinmentDate { get; set; }
    public bool IsTechAppoinment { get; set; } = false;
    public bool IsEmailed { get; set; } = false;
    public string Password { get; set; }
    public bool IsPasswordChanged { get; set; }
    public int CreatedBy { get; set; }
    public int UpdatedBy { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime CreatedDate { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime UpdatedDate { get; set; }
    public bool IsActive { get; set; }
    public bool Registered { get; set; } = false;
    public bool BackToEnquiry { get; set; } = false;
    public int PreviousEnquiryId { get; set; }
    [ForeignKey("TechTLEmployee")]
    public int? TechTL { get; set; }
    [ForeignKey("ProgrammerTLEmployee")]
    public int? ProgrammerTL { get; set; }
    [ForeignKey("PublicationEmployee")]
    public int? PublicationEmpId { get; set; }
    public bool IsAgent { get; set; } = false;

    //ClientForm
    public string ClientToken { get; set; }
    
    public string Discovery { get; set; }
    public string ClientQuery { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DateOfBirth { get; set; }
    //-------


    public virtual Employees BDAEmployee { get; set; }
    public virtual Employees TechEmployee { get; set; }
    public virtual Employees TechTLEmployee { get; set; }
    public virtual Employees ProgrammerTLEmployee { get; set; }
    public virtual Employees ProgrammerEmployee { get; set; }
    public virtual Employees PublicationEmployee { get; set; }
    public virtual ICollection<History> History { get; set; }
    public virtual ICollection<Projects> Projects { get; set; }
    public virtual ICollection<EnquiryFiles> EnquiryFiles { get; set; }
    public virtual ICollection<Plagiarism> Plagiarism { get; set; }
    public virtual ICollection<Emails> Emails { get; set; }
}
