﻿using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos
{
    public class ChangePasswordDto
    {
        [Required]
        public string CurrentPassword { get; set; }

        [RegularExpression(@"^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{5,}$", ErrorMessage = "Password must contains alphanumeric and special character")]
        [Required(ErrorMessage = "Confirm Password is required")]
        [StringLength(15, ErrorMessage = "Password contains minimum 5 and maximum 15 characters", MinimumLength = 5)]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [RegularExpression(@"^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{5,}$", ErrorMessage = "Password must contains alphanumeric and special character")]
        [Required(ErrorMessage = "Confirm Password is required")]
        [StringLength(15, ErrorMessage = "Password contains minimum 5 and maximum 15 characters", MinimumLength = 5)]
        [DataType(DataType.Password)]
        [Compare("Password")]
        public string ConfirmPassword { get; set; }
    }
}
