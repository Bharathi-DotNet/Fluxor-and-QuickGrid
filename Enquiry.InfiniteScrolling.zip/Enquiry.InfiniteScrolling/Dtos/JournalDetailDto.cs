﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos
{
    public class JournalDetailDto
    {
        public JournalDetailDto()
        {
            DateOfSubmission = DateTime.Now;
            RemainderDate = DateTime.Now;
            PublicationHistoryDto = new List<PublicationHistoryDto>();
        }
        public int PublicationId { get; set; }
        public int ProjectId { get; set; }
        
        [DataType(DataType.Date)]
        public DateTime RemainderDate { get; set; }
        
        public string JournelName { get; set; }
        
        public string Link { get; set; }
        
        public string UserId { get; set; }
        
        public string Password { get; set; }
        
        public string Publisher { get; set; }
        [Required]
        [DataType(DataType.Date)]
        public DateTime? DateOfSubmission { get; set; }
        [Required]
        public int Status { get; set; }
        /* [Editable(true)]*/
        [DisplayName("Comments")]
        public string Reason { get; set; }
        public bool? IsTechnicalRejected { get; set; }
        public IList<PublicationHistoryDto> PublicationHistoryDto { get; set; }
    }
    public class JournalPhaseFileDetailDto
    {
        public IList<PhaseFilesDto> PhaseFilesDto { get; set; }
        public IList<JournalDetailDto> JournalDetailDto { get; set; }
        public IList<EmailDto> EmailDto { get; set; }
        public string EnquiryRef { get; set; }
        public string PublicationEmpName { get; set; }
        public int? PublicationEmpId { get; set; }
        public int EnquiryId { get; set; }
    }
        public class PublicationHistoryDto
    {
        public int HistoryId { get; set; }
        public string EmployeeName { get; set; }
        public string Status { get; set; }
        public string Comments { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    public class AllJournalDto
    {
        public int? JournalId { get; set; }
        [Required]
        public string JournalName { get; set; }
        [Required]
        public string Publisher { get; set; }
        [Required]
        public string Link { get; set; }
        [Required]
        public string Index { get; set; }
        [Required]
        public string Domain { get; set; }
        [Required]
        public string Paid { get; set; }
        public DateTime? VerifiedDate { get; set; }
    }
    public class OldJournalDto
    {
        public int JournalId { get; set; }
        public string JournalName { get; set; }
        public string Publisher { get; set; }
        public string VerificationDate { get; set; }
        public string Index { get; set; }
        public string Domain { get; set; }
        public string Link { get; set; }
        public string Paid { get; set; }
    }

    public class UpdatedJournalDto
    {
        public int JournalId { get; set; }
        public string JournalName { get; set; }
        public string Publisher { get; set; }
        public string Index { get; set; }
        public string Domain { get; set; }
        public string Link { get; set; }
        public string Paid { get; set; }
    }
    public class GetJournalDetailsClient
    {
        public string ClientName { get; set; }
        public string ProjectRef { get; set; }
        public string Domain { get; set; }
        public string Status { get; set; }
        public string Reason { get; set; }
    }
}
