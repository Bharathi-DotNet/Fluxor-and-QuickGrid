﻿using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos
{
    public class FeedbackDto
    {
        public int FeedbackId { get; set; }
        [Required(ErrorMessage = "EmployeeId is required")]
        public int? EmployeeId { get; set; }

        [Required(ErrorMessage = "Scenario is required")]
        public string Scenario { get; set; }
        public string EmpFeedback { get; set; }
        [Required(ErrorMessage = "Feedback is required")]

        public string Feedbacks { get; set; }
        public string EmployeeName { get; set; }
        public DateTime CreatedOn { get; set; }
    }
    public class FeedbackDetailDto
    {
        public FeedbackDto FeedbackDto { get; set; }
        public IEnumerable<FeedbackDto> FeedbackDetail { get; set; }
    }
    }
