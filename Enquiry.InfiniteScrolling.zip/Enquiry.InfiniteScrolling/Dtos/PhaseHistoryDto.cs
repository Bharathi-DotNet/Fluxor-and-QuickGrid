﻿
using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos
{
    public class PhaseHistoryDto
    {
        public int PhaseId { get; set; }
        public string EmpName { get; set; }
        public int? TechExpertId { get; set; }
        public int? TechExpert1Id { get; set; }
        public int? TechExpert2Id { get; set; }
        public int? TechExpert3Id { get; set; }
        public int? ProgrammerId { get; set; }
        public int? Programmer1Id { get; set; }
        public string Comments { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? CreatedDate { get; set; }
        public bool IsReassigned { get; set; }
        public bool AssignedDate { get; set; }
        public bool IsClient { get; set; }
        public int EmailId { get; set; }
        public IList<EmailAttachmentDto> EmailAttachmentDto { get; set; }
    }
}
