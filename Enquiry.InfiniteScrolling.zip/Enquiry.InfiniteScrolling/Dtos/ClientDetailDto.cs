﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos;

public class ClientDetailDto
{
    public int EnquiryId { get; set; }
    public string EnquiryRef { get; set; }
    public string ClientName { get; set; }
    public string Contact { get; set; }
    public string MainContactNo { get; set; }
    public string Email { get; set; }
    public string AlternateNo { get; set; }
    public string Domain { get; set; }
    public string TechName { get; set; }
    public string BDAName { get; set; }
    public string ProName { get; set; }
    public int? BDAId { get; set; }
    public int? TechId { get; set; }
    public int? ProId { get; set; }
    public bool IsTechAppoinment { get; set; }
    public bool TechIsActive { get; set; }
    public bool IsEmailed { get; set; }
    public string PaymentRemarks { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime EnquiryDate { get; set; }

    public DateTime? AppoinmentDate { get; set; }
    public string LastComment { get; set; }
    public bool Registered { get; set; }
    public bool IsAgent { get; set; }
    public int PreviousEnquiryId { get; set; }

    public string Query { get; set; }
    public string Token { get; set; }
    public string Discovery { get; set; }
    public PlagiarismfileView PlagiarismfileView { get; set; }
    public IList<EnquiryFilesDto> EnquiryFilesDto { get; set; }

}
public class EnquiryFilesDto
{
    public int EnquiryFileId { get; set; }
    public int EnquiryId { get; set; }
    public string FilePath { get; set; }
    public string FileName { get; set; }
    public DateTime CreatedDate { get; set; }
    public bool IsTech { get; set; }
}
public class ClientFilesDto
{
    public string Comments { get; set; }
    public List<ClientFiles> ClientFiles { get; set; }
}

public class ClientFiles
{
    public int FileId { get; set; }
    public string FilePath { get; set; }
}
public class ComposedEmailDto
{
    public string ToAddress { get; set; }
    public string Subject { get; set; }
    public string OriginalMessage { get; set; }
    public string Message { get; set; }
    public string MessageId { get; set; }
    public int? EnquiryId { get; set; }
    public int? ProjectId { get; set; }
    public int? TechTL { get; set; }
    public int? PgmTL { get; set; }
    public IEnumerable<IFormFile> AttachmentFiles { get; set; }
    public bool IsPublication { get; set; }
    public string EmployeeName { get; set; }
    public string Designation { get; set; }
    public String ProposalPath { get; set; }
    public String VisoPath { get; set; }
    public String ReferencePaperPath { get; set; }
    public String OthersPath { get; set; }
    public String CodePath { get; set; }
    public String DataSetPath { get; set; }
    public String GraphPath { get; set; }
    public String OthersPgmPath { get; set; }
    public String Proposal { get; set; }
    public String Viso { get; set; }
    public String ReferencePaper { get; set; }
    public String Others { get; set; }
    public String Code { get; set; }
    public String DataSet { get; set; }
    public String Graph { get; set; }
    public String OthersPgm { get; set; }
    public string PlagFileName { get; set; }
    public string PlagFilePath { get; set; }
    public string AIFileName { get; set; }
    public string AIFilePath { get; set; }
    public bool Visibility { get; set; }
    public bool IsTechVisibility { get; set; }
    public bool IsProgrammerVisibility { get; set; }
    public List<string> SelectedFiles { get; set; }
    public List<string> SelectedPgmFiles { get; set; }
}
