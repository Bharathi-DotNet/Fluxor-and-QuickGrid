﻿namespace Enquiry.Blazor.Dtos
{
    public class ClientListParameters
    {
        private int _pageSize = 50;
        public int StartIndex { get; set; }
        public string SearchTerm { get; set; }
        public int PageSize
        {
            get
            {
                return _pageSize;
            }
            set
            {
                _pageSize = value;
            }
        }
    }

    public class VirtualizeResponse<T>
    {
        public List<T> Items { get; set; }
        public int TotalSize { get; set; }
    }
}
