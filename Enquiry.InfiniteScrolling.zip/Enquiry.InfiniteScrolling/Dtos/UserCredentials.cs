﻿namespace Enquiry.Blazor.Dtos
{
    public class UserCredentials
    {
        private string _username;

        public string Username
        {
            get => _username;
            set => _username = value.ToUpper();
        }
        public string Password { get; set; }
    }
}
