﻿using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos
{
    public class PhaseExecutionDto
    {
        [Required]
        public int EmpId { get; set; }
        [Required]
        public int PhaseId { get; set; }
        public int Status { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime? DemoDate { get; set; }
        public string Remarks { get; set; }
    }
}
