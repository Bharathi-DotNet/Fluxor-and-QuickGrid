﻿using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos;

public class ClientActivityDto
{
    public int Id { get; set; }
    public string EmployeeName { get; set; }
    public string ClientName { get; set; }
    public string Comments { get; set; }
    public DateTime CreatedDate { get; set; }
    public string FileName { get; set; }
    public string FilePath { get; set; }
    public IList<EmailAttachmentDto> EmailAttachmentDto { get; set; }
}
