﻿using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos
{
    public class PhaseStatusDto
    {
        public int Id { get; set; }
        [Required]
        public string PhaseName { get; set; }
        [Required]
        public int EmployeeDeadline { get; set; }
        [Required]
        public int ClientDeadline { get; set; }
        public bool IsMonthCalc { get; set; }
        public bool IsScore { get; set; }
        public bool OnlyForProgrammers { get; set; }
        public bool OnlyForTech { get; set; }
        public bool SpecialDeadline { get; set; }
        public bool IsActive { get; set; } = true;
        public bool SkipPublication { get; set; }
    }
}
