﻿namespace Enquiry.Blazor.Dtos
{
    public class PlagiarismListDto
    {
        public int PlagiarismId { get; set; }
        public int PlagiarismRecipientId { get; set; }
        public string UploadedEmployeeName { get; set; }
        public string UploadedEmployeeMemberId { get; set; }
        public string DownloadedEmployeeName { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public int? PhaseId { get; set; }
        public int? EnquiryId { get; set; }
    }
    public class PlagiarismPhaseDetailsDto
    {
        public int PhaseId { get; set; }
        public string ProjectRef { get; set; }
        public string PhaseName { get; set; }

    }
}
