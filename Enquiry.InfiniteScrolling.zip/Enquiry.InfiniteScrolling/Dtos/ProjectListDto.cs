﻿using Microsoft.VisualBasic;
using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos;

public class ProjectListDto
{
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? NextAppoinment { get; set; }
    public string status { get; set; }
    public int EnquiryId { get; set; }
    public int PhaseId { get; set; }
    public int ProjectId { get; set; }
    public string ClientName { get; set; }
    public string ProjectName { get; set; }
    public string PhaseName { get; set; }
    public string EnquiryRef { get; set; }
    public string Contact { get; set; }
    public string Domain { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DeadLine { get; set; }
    public string Status { get; set; }
    public int StatusId { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DemoDate { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DemoDate3 { get; set; }
    public DateTime? DemoDate1 { get; set; }
    public DateTime? DemoDate2 { get; set; }
    public DateTime? DemoDate4 { get; set; }
    public DateTime? DemoDate5 { get; set; }
    public string AssignedTech { get; set; }
    public string AssignedTech1 { get; set; }
    public string AssignedTech2 { get; set; }
    public string AssignedTech3 { get; set; }
    public string AssignedTech4 { get; set; }
    public string AssignedTech5 { get; set; }
    public int WorkCountTech { get; set; }
    public int WorkCountTech1 { get; set; } = 0;
    public int WorkCountTech2 { get; set; }
    public int WorkCountTech3 { get; set; }
    public int WorkCountTech4 { get; set; }
    public int WorkCountTech5 { get; set; }

    public int? TechExpert { get; set; }
    public int? TechExpert1 { get; set; }
    public int? TechExpert2 { get; set; }
    public int? TechExpert3 { get; set; }
    public int? Programmer { get; set; }
    public int? Programmer1 { get; set; }
    public int? TechPriority { get; set; }
    public int? TechPriority1 { get; set; }
    public int? TechPriority2 { get; set; }
    public int? TechPriority3 { get; set; }
    public int? ProgrammerPriority { get; set; }
    public int? ProgrammerPriority1 { get; set; }
    public bool TechStatus { get; set; }
    public bool TechStatus1 { get; set; }
    public bool TechStatus2 { get; set; }
    public bool TechStatus3 { get; set; }
    public bool ProgrammerStatus { get; set; }
    public bool ProgrammerStatus1 { get; set; }
    public string IsProgrammerNeeded { get; set; }
    public string IsTechNeeded { get; set; }
    public string IsTechPgmDisabled { get; set; }
    public string Comment { get; set; }
    public int? Priority { get; set; }
    public int? ManagerPriority { get; set; }
    public int? TechTL { get; set; }
    public int? PgmTL { get; set; }
    public bool TechTLStatus { get; set; }
    public bool PgmTLStatus { get; set; }
    public bool TechTLStatus1 { get; set; }
    public bool PgmTLStatus1 { get; set; }
    public bool TechStatusAny { get; set; }
    public bool PgmStatusAny { get; set; }
    public IList<SubordinatesProjectListDto> SubordinatesProjectListDto {  get; set; }

}

public class ProjectNew
{
    public string clientName { get; set; }
    public string projectName { get; set; }
    public string phaseName { get; set; }
    public string comment { get; set; }
    public string assignedTech { get; set; }
    public string? nextAppoinment { get; set; }
    public string? deadLine { get; set; }
    public string status { get; set; }
    public string enquiryRef { get; set; }
    public string contact { get; set; }
    public int enquiryId { get; set; }
    public int projectId { get; set; }
    public int phaseId { get; set; }
    public string? demoDate { get; set; }
    public int? priority { get; set; }
}
public class SubordinatesProjectListDto
{
    public string EmpName { get; set; }
    public int EnquiryId { get; set; }
    public int PhaseId { get; set; }
    public int ProjectId { get; set; }
    public string ClientName { get; set; }
    public string ProjectName { get; set; }
    public string PhaseName { get; set; }
    public string EnquiryRef { get; set; }
    public string Contact { get; set; }
    public string Domain { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DeadLine { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? NextAppoinment { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DemoDate { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DemoDate3 { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DemoDate1 { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DemoDate2 { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DemoDate4 { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DemoDate5 { get; set; }
    public string Status { get; set; }
    public int StatusId { get; set; }
    public string AssignedTech { get; set; }
    public string AssignedTech1 { get; set; }
    public string AssignedTech2 { get; set; }
    public string AssignedTech3 { get; set; }
    public string AssignedTech4 { get; set; }
    public string AssignedTech5 { get; set; }
    public int WorkCountTech { get; set; }
    public int WorkCountTech1 { get; set; }
    public int WorkCountTech2 { get; set; }
    public int WorkCountTech3 { get; set; }
    public int WorkCountTech4 { get; set; }
    public int WorkCountTech5 { get; set; }
    public string Comment { get; set; }
    public int? TechExpert { get; set; }
    public int? TechExpert1 { get; set; }
    public int? TechExpert2 { get; set; }
    public int? TechExpert3 { get; set; }
    public int? Programmer { get; set; }
    public int? Programmer1 { get; set; }
    public int? TechPriority { get; set; }
    public int? TechPriority1 { get; set; }
    public int? TechPriority2 { get; set; }
    public int? TechPriority3 { get; set; }
    public int? ProgrammerPriority { get; set; }
    public int? ProgrammerPriority1 { get; set; }
    public bool TechStatus { get; set; }
    public bool TechStatus1 { get; set; }
    public bool TechStatus2 { get; set; }
    public bool TechStatus3 { get; set; }
    public bool ProgrammerStatus { get; set; }
    public bool ProgrammerStatus1 { get; set; }
    public int? Priority { get; set; }
    public int? ManagerPriority { get; set; }
    public int? TechTL { get; set; }
    public int? PgmTL { get; set; }
    public bool TechTLStatus { get; set; }
    public bool PgmTLStatus { get; set; }
    public bool TechTLStatus1 { get; set; }
    public bool PgmTLStatus1 { get; set; }
    public bool TechStatusAny { get; set; }
    public bool PgmStatusAny { get; set; }
}
