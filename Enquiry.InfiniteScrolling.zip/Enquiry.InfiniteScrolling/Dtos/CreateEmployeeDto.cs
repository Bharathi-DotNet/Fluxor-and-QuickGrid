﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos;

public class CreateEmployeeDto
{
    [DisplayName("Employee Name")]
    [Required]
    public string EmployeeName { get; set; }
    [DisplayName("Contact")]
    [Required]
    public string ContactNo { get; set; }
    [DisplayName("Email")]
    [Required]
    public string EmailId { get; set; }
    [Required]
    public string Address { get; set; }
    [Required]
    public string MemberId { get; set; }
    [Required]
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]
    public DateTime DOB { get; set; }
    [Required]
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]
    public DateTime DOJ { get; set; }
    [DisplayName("Department")]
    [Required]
    public int DeptId { get; set; }
    [DisplayName("Role")]
    [Required]
    public int RoleId { get; set; }
    [Required]
    public int Superior { get; set; }
    [Required]
    public string Designation { get; set; }
    public bool IsEnquiry { get; set; }
    public IFormFile EmployeePhotos { get; set; }
    public byte[] EmployeePhotoBytes { get; set; }

}
public class EditEmployeeDto
{
    public int EmpId { get; set; }
    [DisplayName("Employee Name")]
    [Required]
    public string EmployeeName { get; set; }
    [DisplayName("Contact")]
    [Required]
    public string ContactNo { get; set; }
    [DisplayName("Email")]
    [Required]
    public string EmailId { get; set; }
    [Required]
    public string Address { get; set; }
    //[Required]
    //public string MemberId { get; set; }
    [Required]
    [DataType(DataType.Date)]
    public DateTime DOB { get; set; }
    [Required]
    [DataType(DataType.Date)]
    public DateTime DOJ { get; set; }
    [Required]
    public string Designation { get; set; }
    public bool IsEnquiry { get; set; }
    public string EmployeePhotos { get; set; }
    public IFormFile EmployeeImageUpload { get; set; }
    public byte[] EmployeePhotoBytes { get; set; }


}