﻿using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos
{
    public class LoginOtpDto
    {
        [Required(ErrorMessage = "OTP is required.")]
        [RegularExpression(@"\d{4}", ErrorMessage = "OTP must be a 4-digit number.")]
        public int? Otp { get; set; }

        [Required(ErrorMessage = "Device name is required.")]
        [StringLength(20, ErrorMessage = "Device name cannot be longer than 50 characters.")]
        public string DeviceName { get; set; }
    }
}
