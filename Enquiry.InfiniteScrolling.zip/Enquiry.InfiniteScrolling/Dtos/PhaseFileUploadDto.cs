﻿using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos
{
    public class PhaseFileUploadDto
    {
        public int PhaseId { get; set; }
        public List<FileUpload> Files { get; set; } = new List<FileUpload>();
    }

    public class FileUpload
    {
        [Required(ErrorMessage = "Filename is required.")]
        public string Filename { get; set; }
        [Required(ErrorMessage = "File is required.")]
        public IFormFile File { get; set; }
    }
    public class PublicationFileUploadDto
    {
        public int PhaseId { get; set; }
        public List<FileUpload> Files { get; set; } = new List<FileUpload>();
    }

    public class PublicationFileUpload
    {
        [Required(ErrorMessage = "Filename is required.")]
        public string Filename { get; set; }
        [Required(ErrorMessage = "File is required.")]
        public IFormFile File { get; set; }
    }
}
