﻿using System.ComponentModel;

namespace Enquiry.Blazor.Dtos
{
    public class DataDto
    {
        public string Name { get; set; }
        public string Department { get; set; }
        [DisplayName("PhoneNumber1")]
        public string PhoneNo1 { get; set; }
        [DisplayName("PhoneNumber2")]
        public string PhoneNo2 { get; set; }
        public string Email1 { get; set; }
        public string Email2 { get; set; }
        //public string CallsStatus { get; set; }
        //public string WhatsappStatus { get; set; }
        //public string EmailStatus { get; set; }
        //public DateTime CallsUpdatedDate { get; set; }
        //public DateTime WhatsappUpdatedDate { get; set; }
        //public DateTime EmailUpdatedDate { get; set; }
    }
    public class DataCount
    {
        public int TodayPhoneNumberCount { get; set; }
        public int TodayEmailCount { get; set; }
        public int TotalPhoneNumberCount { get; set; }
        public int TotalEmailCount { get; set; }
    }
    public class ClientData
    {
        public DataDto DataDto { get; set; }
        public DataCount DataCount { get; set; }
    }
}
