﻿using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos
{
    public class McubeOutboundCallRequest
    {
        [Required]
        public string Exenumber { get; set; }
        [Required]
        public string Custnumber { get; set; }
        public string Refurl { get; set; } = "https://api.mcube.com/Restmcube-api/outbound-calls"; // Default URL
        public string Refid { get; set; } // Optional
    }

    public class McubeOutboundCallResponse
    {
        public string Status { get; set; }
        public string Msg { get; set; }
        public string Callid { get; set; }
    }

    public class McubeInboundCallData
    {
        public string Starttime { get; set; }
        public string Callid { get; set; }
        public string Emp_phone { get; set; }
        public string Clicktocalldid { get; set; }
        public string Callto { get; set; }
        public string Dialstatus { get; set; }
        public string Filename { get; set; }
        public string Direction { get; set; }
        public string Endtime { get; set; }
        public string Disconnectedby { get; set; }
        public string Answeredtime { get; set; }
        public string Groupname { get; set; }
        public string Agentname { get; set; }
    }
}
