﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Enquiry.Blazor.Dtos
{
    public class EmailDto
    {
        public int EmailId { get; set; }
        public string FromAddress { get; set; }
        public string ToAddress { get; set; }
        public bool IsToAddress { get; set; }
        public bool IsFromAddress { get; set; }
        public string ClientName { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public DateTime ReceivedDate { get; set; }
        public int? ProjectId { get; set; }
        public string SenderClientName { get; set; }
        public int? PublicationProjectId { get; set; }
        public int? EnquiryId { get; set; }
        public bool IsPublication { get; set; }
        public bool IsSender { get; set; }
        public bool Visibility { get; set; }
        public bool IsTechVisibility { get; set; }
        public bool IsProgrammerVisibility { get; set; }
        public string UpdatedBy { get; set; }
        public IList<EmailAttachmentDto> EmailAttachmentDto { get; set; }
    }
    public class EmailAttachmentDto
    {
        public int AttachmentFileId { get; set; }
        public string AttachmentFilePath { get; set; }
        public string AttachmentFileName { get; set; }
        public bool IsSelected { get; set; }
    }
    public class EnquiryDropdown
    {
        public int? EnquiryId { get; set; }
        public string ClientName { get; set; }
        public string TechTl { get; set; }
        public string EnquiryRef { get; set; }
    }
    public class ProjectDropdown
    {
        public int? ProjectId { get; set; }
        public string ClientName { get; set; }
        public string ProjectRef { get; set; }
        public string Status { get; set; }
        public string ProjectName { get; set; }
    }
    public class PublicationDropdown
    {
        public int? ProjectId { get; set; }
        public string ClientName { get; set; }
        public string ProjectName { get; set; }
        public string ProjectRef { get; set; }
        public int ToApplyCount { get; set; }
    }
}
