﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Enquiry.Blazor.Dtos
{
    public class EmployeeTreeDto
    {
        public int EmpId { get; set; }
        public string IdentityNo { get; set; }
        public string EmployeeName { get; set; }
        public int DeptId { get; set; }
        public int RoleId { get; set; }
        public int? SuperiorId { get; set; }
        public bool Checked { get; set; } = false;
        public string SuperiorName { get; set; }
        public bool IsActive { get; set; }
        public List<string> SubordinateNames { get; set; }
        public List<int> SubordinateIds { get; set; }
        public int SuperiorWorkCount { get; set; }
        public List<int> SubordinateWorkCount { get; set; }
    }

    public class OrganizationTreeDto
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Parent { get; set; }
        public int? SuperiorId { get; set; }
        public bool Checked { get; set; } = false;
    }

    public class BinaryChartModel
    {
        public object[] Result { get; set; }
    }
}
