﻿namespace Enquiry.Blazor.Dtos
{
    public class ClientformDto
    {
        //ClientForm

        public string ClientName { get; set; }
        public string Contact { get; set; }
        public string ClientToken { get; set; }
      
        public string Discovery { get; set; }
        public string ClientQuery { get; set; }
        public string Domain { get; set; }
        public DateTime? DateOfBirth { get; set; }
        //-------
    }
}
