﻿using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos
{
    public class ProjectStatusDto
    {
        public int ProjectStatusId { get; set; }
        [Required]
        public string ProjectName { get; set; }
        public string WorkType { get; set; }
        [Required]
        public double AgentPayment { get; set; }
        [Required]
        public double NormalPayment { get; set; }
        public int Incentive { get; set; }
        public int ReducedIncentive { get; set; }
    }
    public class ApprovalDto
    {
        [Required]
        public string PaymentRemark { get; set; }
        public int ProjectId { get; set; }
    }
}
