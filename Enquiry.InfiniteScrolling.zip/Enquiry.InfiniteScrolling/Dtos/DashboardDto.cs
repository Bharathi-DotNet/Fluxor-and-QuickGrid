﻿namespace Enquiry.Blazor.Dtos
{
    public class DashboardDto
    {
        public class EmployeeInfo
        {
            public int EmpId { get; set; }
            public string Role { get; set; }
            public string Dept { get; set; }
        }
        public class DiscussionPendingDto: EmployeeInfo
        {
            public string ClientName { get; set; }
            public int EnquiryId { get; set; }
            public string TechName { get; set; }
            public string BDAName { get; set; }
            public DateTime? AppointmentDate { get; set; }
        }

        public class AssignedPhaseDto: EmployeeInfo
        {
            public string ClientName { get; set; }
            public string PhaseName { get; set; }
            public string ProjectRef { get; set; }
            public int ProjectId { get; set; }
            public int EnquiryId { get; set; }
            public bool IsTechEnabled { get; set; }
            public bool IsPgmEnabled { get; set; }
            public DateTime? DeadLine { get; set; }
            public string TechTl { get; set; }
        }
        public class ManagerApprovalDto : EmployeeInfo
        {
            public string ClientName { get; set; }
            public string PhaseName { get; set; }
            public string ProjectRef { get; set; }
            public int ProjectId { get; set; }
            public int EnquiryId { get; set; }
            public bool IsTechEnabled { get; set; }
            public bool IsPgmEnabled { get; set; }
            public DateTime? DeadLine { get; set; }
        }
        public class JournalSubmit : EmployeeInfo
        {
            public string ClientName { get; set; }
            public string ProjectName { get; set; }
            public int ProjectId { get; set; }
            public int EnquiryId { get; set; }
            public string PhaseName { get; set; }
            public string ProjectRef { get; set; }
            public int Submitted { get; set; }
            public int Rejected { get; set; }
            public int Major { get; set; }
            public int Minor { get; set; }
            public int Accepted { get; set; }
            public int Published { get; set; }
        }

        public class ProductionDueDateExceededDto : EmployeeInfo
        {
            public string EmployeeName { get; set; }
            public IList<PhaseListDto> PhaseListDto { get; set; }
        }

        public class PhaseListDto
        {
            public string PhaseName { get; set; }
            public string ClientName { get; set; }
            public DateTime? DemoDate { get; set; }
        }

        public class DueDateExceededDto: EmployeeInfo
        {
            public string ClientName { get; set; }
            public int EnquiryId { get; set; }
            public int ProjectId { get; set; }
            public string PhaseName { get; set; }
            public string ProjectRef { get; set; }
            public int? Tech { get; set; }
            public List<ClientName> ClientNames { get; set; }
            public List<DateTime?> DemoDates { get; set; }
            public List<string> PhaseNames { get; set; }
            public string TechName { get; set; }
            public string TechName1 { get; set; }
            public string TechName2 { get; set; }
            public string TechName3 { get; set; }
            public string Programmer { get; set; }
            public string Programmer1 { get; set; }
            public DateTime? DemoDate { get; set; }
            public DateTime? DemoDate1 { get; set; }
            public DateTime? DemoDate2 { get; set; }
            public DateTime? DemoDate3 { get; set; }
            public DateTime? DemoDate4 { get; set; }
            public DateTime? DemoDate5 { get; set; }
            public DateTime? Deadline { get; set; }

        }
        public class ClientName
        {
            public string Name { get; set; }
            public int EnquiryId { get; set; }
            public int ProjectId { get; set; }
        }
        public class PublicationDeadLineDto : EmployeeInfo
        {
            public string ClientName { get; set; }
            public string PhaseName { get; set; }
            public string ProjectRef { get; set; }
            public int ProjectId { get; set; }
            public int EnquiryId { get; set; }
            public DateTime? Deadline { get; set; }
            public int Submitted { get; set; }
            public int Rejected { get; set; }
            public int Major { get; set; }
            public int Minor { get; set; }
            //public int Accepted { get; set; }
            //public int Published { get; set; }

        }


        public class JournalPendingDto: EmployeeInfo
        {
            public string ClientName { get; set; }
            public DateTime AssignedDate { get; set; }
        }

    }
}
