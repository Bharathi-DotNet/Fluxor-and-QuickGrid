﻿using Enquiry.Blazor.Extensions;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos
{
    public class CreateClientDto
    {
        public CreateClientDto()
        {
            AppoinmentDate = DatetimeExtension.ToDateTime(DateTimeOffset.Now);
        }
        [DisplayName("Client Name")]
        [Required]
        public string ClientName { get; set; }
        [Required]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^(\+?[0-9]{1,3}[-. ]?)?\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid phone number")]
        [MaxLength(15)]
        public string ContactNo { get; set; }

        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^(\+?[0-9]{1,3}[-. ]?)?\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid phone number")]
        [MaxLength(15)]
        public string AlternateNo { get; set; }

        [EmailAddress]
        public string Email { get; set; }
        [Required]
        public string Domain { get; set; }
        [DisplayName("BDA Remarks")]
        public string BDARemarks { get; set; }
        [DisplayName("Payment Remarks")]
        public string PaymentRemarks { get; set; }

        [DisplayName("Appointment")]
        public DateTime? AppoinmentDate { get; set; }

        [DisplayName("Tech")]
        [Required]
        public int? TechExpert { get; set; }


        [DisplayName("Enable Tech Appoinment")]
        public bool IsTechAppoinment { get; set; } = false;
        public bool IsAgent { get; set; }
    }

    public class EditClientDto
    {
        public int EnquiryId { get; set; }
        [DisplayName("Client Name")]
        [Required]
        public string ClientName { get; set; }
        [Required]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^(\+?[0-9]{1,3}[-. ]?)?\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid phone number")]
        [MaxLength(15)]
        public string ContactNo { get; set; }

        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^(\+?[0-9]{1,3}[-. ]?)?\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid phone number")]
        [MaxLength(15)]
        public string AlternateNo { get; set; }

        [EmailAddress]
        public string Email { get; set; }
        [Required]
        public string Domain { get; set; }
        [DisplayName("Payment Remarks")]
        public string PaymentRemarks { get; set; }
    }
}
