﻿using System.Security.Claims;

namespace Enquiry.Blazor.Dtos
{
    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string EmpId { get; set; }
        public string Email { get; set; }
        public string EmployeeName { get; set; }
        public string Dept { get; set; }
        public string EmployeePhotoUrl { get; set; }
        public IEnumerable<string> Roles { get; set; }
        public string SuperiorId { get; set; }
        public string IsEnquiry { get; set; }
        public string PlagiarismEnabled { get; set; }
        public string MemberId { get; set; }

        public IEnumerable<Claim> Claims()
        {
            var claims = new List<Claim> {
                new Claim(ClaimTypes.Name, Username),
                new Claim("EmpId", EmpId),
                new Claim(ClaimTypes.Email, Email),
                new Claim("EmployeeName", EmployeeName),
                new Claim("Dept", Dept),
                new Claim("EmployeePhotoUrl", EmployeePhotoUrl ?? string.Empty),
                new Claim("SuperiorId", SuperiorId ?? "0"),
                new Claim("IsEnquiry", IsEnquiry ?? "0"),
                new Claim("PlagiarismEnabled", PlagiarismEnabled ?? "0"),
                new Claim("MemberId", MemberId ?? string.Empty),
            };
            claims.AddRange(Roles.Select(role => new Claim(ClaimTypes.Role, role)));

            return claims;
        }
    }
}
