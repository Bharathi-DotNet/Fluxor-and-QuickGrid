﻿namespace Enquiry.Blazor.Dtos
{
    public class DocumentRedirectDto
    {
        public string Url { get; set; }
        public int PlagiarismRecipientId { get; set; }
        public string FilePath { get; set; }
    }
}
