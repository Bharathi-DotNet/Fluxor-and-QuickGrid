﻿using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos
{
    public class ScoreDto
    {
        public ScoreDto() 
        {
            NewEnquiryDto = new List<NewEnquiryDto>();
        }
        public IList<PaymentDto> PaymentDto { get; set; }
        public IList<BDAPaymentDto> BDAPaymentDto { get; set; }
        public List<NewEnquiryDto> NewEnquiryDto { get; set; }
        public List<NewRegistrationDto> NewRegistrationDto { get; set; }
        public List<Discovery> Discovery { get; set; }
    }

    public class PaymentDto
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public int Role { get; set; }
        public int Department { get; set; }
        public int TotalPaid { get; set; }
        public int OldReg { get; set; }
        public int NewReg { get; set; }
    }
    public class BDAPaymentDto
    {
        public int? EmpId { get; set; }
        public string EmpName { get; set; }
        public int Role { get; set; }
        public int Department { get; set; }
        public int TotalPaid { get; set; }
        public int OldReg { get; set; }
        public int NewReg { get; set; }
    }
    public class Discovery
    {
        public string EmployeeName { get; set; }
        public int Google { get; set; }
        public int Facebook { get; set; }
        public int LinkedIn { get; set; }
        public int Call { get; set; }
        public int WhatsApp { get; set; }
        public int Email { get; set; }
        public int Others { get; set; }
        public int Referred { get; set; }
        public int JustDial { get; set; }

        public int Total => Google + Facebook + LinkedIn + Call + WhatsApp + Email + Others + Referred + JustDial;
    }

    public class NewEnquiryDto
    {
        public int BDAId { get; set; }
        public string BDA { get; set; }
        public int OldEnquiry { get; set; }
        public int NewEnquiry { get; set; }
    }

    public class NewRegistrationDto
    {
        public int BDAId { get; set; }
        public string BDA { get; set; }
        public int OldRegistrationCount { get; set; }
        public int NewRegistrationCount { get; set; }
        public int Incentive { get; set; }
    }

    public class EnquiryRegisteredDto
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public int Role { get; set; }
        public int Department { get; set; }
        public int OldEnquiry { get; set; }
        public int NewEnquiry { get; set; }
    }
    public class EnquiryDetailDto
    {
        public string EnquiryRef { get; set; }
        public string ClientName { get; set; }
        public int? TechExpertId { get; set; }
        public string TechExpertName { get; set; }
        public string Domain { get; set; }
        public int EnquiryId { get; set; }
    }

    public class NewRegistrationTechDto
    {
        public int TechId { get; set; }
        public string TechName { get; set; }
        public int OldRegistrationCount { get; set; }
        public int NewRegistrationCount { get; set; }
    }

    public class TechProductionDto
    {
        public int TechId { get; set; }
        public int ProjectId { get; set; }
        public int EnquiryId { get; set; }
        public string ProjectRef { get; set; }
        public string TechName { get; set; }
        public string ClientName { get; set; }
        public string PhaseName { get; set; }
        public string Reason { get; set; }
        public decimal? Points { get; set; }
        public int? Score { get; set; }
        public int Point { get; set; }

    }
    public class TechPointCountDto
    {
        public int? TechId { get; set; }
        public string TechName { get; set; }
        public int TotalRows { get; set; }
        public int RowsWithPoints { get; set; }
        public int RowsWithoutPoints { get; set; }
        public decimal? Points { get; set; }
    }
    public class ScoreTechDto
    {
        public IList<NewRegistrationTechDto> NewRegistrationTechDto { get; set; }
        public List<TechProductionDto> TechProductionDto { get; set; }
        public List<TechPointCountDto> TechPointCountDto { get; set; }
    }
    public class BDARegistrationDto
    {
        public string ProjectRef { get; set; }
        public string ClientName { get; set; }
        public string TechExpert { get; set; }
        public string ProjectName { get; set; }
        public int EnquiryId { get; set; }
    }
    public class TechRegistrationDto
    {
        public string ProjectRef { get; set; }
        public string ClientName { get; set; }
        public string BDA { get; set; }
        public string ProjectName { get; set; }
        public int EnquiryId { get; set; }
    }
    public class ProgrammerRegistrationDto
    {
        public string ProjectRef { get; set; }
        public string ClientName { get; set; }
        public string TechExpert { get; set; }
        public string ProjectName { get; set; }
        public int EnquiryId { get; set; }
    }
    public class ScoreProgrammingDto
    {
        public IList<NewRegistrationProgrammingDto> NewRegistrationProgrammingDto { get; set; }
        public List<ProgrammingProductionDto> ProgrammingProductionDto { get; set; }
        public List<ProgrammingPointCountDto> ProgrammingPointCountDto { get; set; }
    }
    public class ProgrammingPointCountDto
    {
        public int? ProgrammerId { get; set; }
        public string ProgrammerName { get; set; }
        public int TotalRows { get; set; }
        public int RowsWithPoints { get; set; }
        public int RowsWithoutPoints { get; set; }
        public decimal? Points { get; set; }
    }
    public class NewRegistrationProgrammingDto
    {
        public int ProgrammerId { get; set; }
        public string ProgrammerName { get; set; }
        public int OldRegistrationCount { get; set; }
        public int NewRegistrationCount { get; set; }
    }

    public class ProgrammingProductionDto
    {
        public int ProgrammerId { get; set; }
        public int ProjectId { get; set; }
        public int EnquiryId { get; set; }
        public string ProjectRef { get; set; }
        public string programmerName { get; set; }
        public string ClientName { get; set; }
        public string PhaseName { get; set; }
        public string Reason { get; set; }
        public decimal? Points { get; set; }
    }
    public class ScorePublicationDto
    {
        public IList<PublicationDto> PublicationDto { get; set; }
        public List<PublicationPointCountDto> PublicationPointCountDto { get; set; }

    }
    public class PublicationDto
    {
        public string EmpName { get; set; }
        public string ClientName { get; set; }
        public int ProjectId { get; set; }
        public int EnquiryId { get; set; }
        public string JournalName { get; set; }
        public string Reason { get; set; }
        public int EmpId { get; set; }
        public int Status { get; set; }
        public string ProjectRef { get; set; }
        public string Domain { get; set; }
        public bool? RejectionStatus { get; set; }
    }

    public class PublicationPointCountDto
    {
        public int? EmpId { get; set; }
        public string EmpName { get; set; }
        public int Submitted { get; set; }
        public int Rejected { get; set; }
        public int MajorOrMinor { get; set; }
        public int Accepted { get; set; }
        public int ToApply { get; set; }
        public int MailAccount { get; set; }
        public int ClientWithdraw { get; set; }
        public int Terminated { get; set; }
    }

    public class EmpPointsDto
    {
        public int Id { get; set; }
        public int EnquiryId { get; set; }
        public int ProjectId { get; set; }
        public string ProjectRef { get; set; }
        public string Name { get; set; }
        public string ClientName { get; set; }
        public string PhaseName { get; set; }
        public string Reason { get; set; }
        public decimal? Points { get; set; }
    }

    public class EnquiryWisePaymentDto
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public int EnquiryId { get; set; }
        public string EnquiryName { get; set; }
        public double Payment { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? Date { get; set; }
    }
}
