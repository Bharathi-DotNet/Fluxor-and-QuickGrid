﻿namespace Enquiry.Blazor.Dtos
{
    public class ProfileConstants
    {
        public string UserName { get; set; }
        public int EmpId { get; set; }
        public string EmployeeName { get; set; }
        public string EmailId { get; set; }
        public string Roles { get; set; }
        public string Dept { get; set; }
        public string EmployeePhotoUrl { get; set; }
        public int SuperiorId { get; set; }
        public string IsEnquiry { get; set; }
        public int PlagiarismEnabled { get; set; }
        public string MemberId { get; set; }
    }
}
