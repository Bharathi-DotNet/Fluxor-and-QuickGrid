﻿using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos
{
    public class ReassignedPhaseDto
    {
        public string ReassignedPhase { get; set; }
        public int ProjectId { get; set; }
        public DateTime Deadline { get; set; }
        public DateTime AssignedDate { get; set; }
        [Required(ErrorMessage = "Required")]
        [StringLength(25, ErrorMessage = "Length can't be more than 25.")]
        public string Reason { get; set; }
    }
}
