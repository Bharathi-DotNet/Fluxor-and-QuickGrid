﻿using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos
{
    public class IndividualClientListDto
    {
        public int EnquiryId { get; set; }
        public int projectId { get; set; }
        public string ClientName { get; set; }
        public string EnquiryRef { get; set; }
        public string Domain { get; set; }
        public string Contact { get; set; }
        public string Status { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime RegistrationDate { get; set; }
    }
}
