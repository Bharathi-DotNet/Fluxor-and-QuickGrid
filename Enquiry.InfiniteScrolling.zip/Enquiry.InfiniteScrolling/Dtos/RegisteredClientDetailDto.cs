﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Enquiry.Blazor.Dtos;

public class RegisteredClientDetailDto
{
    public int EnquiryId { get; set; }
    public int ProjectId { get; set; }
    public string ClientName { get; set; }
    public string EnquiryRef { get; set; }
    public string ProjectRef { get; set; }
    public string ProjectName { get; set; }
    public string Contact { get; set; }
    public string Domain { get; set; }
    public string BDAName { get; set; }
    public string TechTL { get; set; }
    public string TechName { get; set; }
    public string PgmTL { get; set; }
    public string ProName { get; set; }
    public bool BackToEnquiry { get; set; }
    public bool? IsTechTlActive { get; set; }
    public bool? IsTechNameActive { get; set; }
    public bool? IsPgmTlActive { get; set; }
    public bool? IsPgmNameActive { get; set; }
    public IList<ProjectDetailDto> ProjectDetailDto { get; set; }
}

public class ProjectDetailDto
{
    public int ProjectId { get; set; }
    public string ProjectName { get; set; }
    public int EnquiryId { get; set; }
    public string ProjectRef { get; set; }
    public int TotalPayment { get; set; }
    public int PartPayment { get; set; }
    public int Balance { get; set; }
    public string FeeConfirmation { get; set; }
    public bool? TechIsActive { get; set; }
    public bool? TechTlIsActive { get; set; }
    public bool IsPlag { get; set; }
    public DateTime RegistrationDate { get; set; }
    public IList<EmployIdData> EmployIdData { get; set; }
    public IList<PaymentDetailDto> PaymentDetailDto { get; set; }
    public List<PhaseHistoryDto> PhaseHistoryDto { get; set; } = new List<PhaseHistoryDto>();
    public IList<PhaseDetailDto> PhaseDetailDto { get; set; }
    public IList<RegisteredClientDetailDto> RegisteredClientDetailDto { get; set; }
    public IList<PhasefileViewDto> PhasefileView { get; set; }
    public IList<PlagiarismfileView> PlagiarismfileView { get; set; }
    //public IList<GetDemoFeedbackDto> GetDemoFeedbackDto { get; set; }
}

public class PhaseFilesDto
{
    public int PhaseFileId { get; set; }
    public int? EmpId { get; set; }
    public int PhaseId { get; set; }
    public string FilePath { get; set; }
    public string FileName { get; set; }
    public bool IsPublication { get; set; }
}


public class PaymentDetailDto
{
    public int PaymentId { get; set; }
    public int ProjectId { get; set; }
    public int? PartPayment { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? PaymentDate { get; set; }
}

public class PhaseDetailDto
{
    
    public int PhaseId { get; set; }
    public string PhaseName { get; set; }
    public string PhaseRemark { get; set; }
    public string Programmer { get; set; }
    public string Programmer1 { get; set; }
    public string TechExpert { get; set; }
    public string TechExpert1 { get; set; }
    public string TechExpert2 { get; set; }
    public string TechExpert3 { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DeadLine { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DemoDate { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DemoDate1 { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DemoDate2 { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DemoDate3 { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DemoDate4 { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? DemoDate5 { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public string Remarks { get; set; }
    public string Remarks1 { get; set; }
    public string Remarks2 { get; set; }
    public string Remarks3 { get; set; }
    public string Remarks4 { get; set; }
    public string Remarks5 { get; set; }
    public int Progress { get; set; }
    public int Progress1 { get; set; }
    public int Progress2 { get; set; }
    public int Progress3 { get; set; }
    public string Status { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? NextAppoinment { get; set; }
    public string Comment { get; set; }
    public int? TechExpertId { get; set; }
    public int? TechExpert1Id { get; set; }
    public int? TechExpert2Id { get; set; }
    public int? TechExpert3Id { get; set; }
    public int? ProgrammerId { get; set; }
    public int? Programmer1Id { get; set; }
    [DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? AssignedDate { get; set; }
}
public class EmployIdData
{
    public int? TechExpertId { get; set; }
    public int? TechExpert1Id { get; set; }
    public int? TechExpert2Id { get; set; }
    public int? TechExpert3Id { get; set; }
    public int? ProgrammerId { get; set; }
    public int? Programmer1Id { get; set; }
    public int WorkCountTech { get; set; }
    public int WorkCountTech1 { get; set; } = 0;
    public int WorkCountTech2 { get; set; }
    public int WorkCountTech3 { get; set; }
    public int WorkCountTech4 { get; set; }
    public int WorkCountTech5 { get; set; }
    public int? EnquiryId { get; set; }
    public string TechName { get; set; }
    public string TechName1 { get; set; }
    public string TechName2 { get; set; }
    public string TechName3 { get; set; }
    public string Programmer { get; set; }
    public string Programmer1 { get; set; }
    public int? Priority { get; set; }
    public int? ManagerPriority { get; set; }
    public int? Status { get; set; }
    public bool TechStatus { get; set; }
    public bool TechStatus1 { get; set; }
    public bool TechStatus2 { get; set; }
    public bool TechStatus3 { get; set; }
    public bool ProgrammerStatus { get; set; }
    public bool ProgrammerStatus1 { get; set; }
    public int? TechTL { get; set; }
    public int? PgmTL { get; set; }
    public bool TechTLStatus { get; set; }
    public bool PgmTLStatus { get; set; }
    public bool TechTLStatus1 { get; set; }
    public bool PgmTLStatus1 { get; set; }
    public bool TechStatusAny { get; set; }
    public bool PgmStatusAny { get; set; }
    public bool IsOnDemo { get; set; }
    public string DemoLink { get; set; }
    public bool TechAssign { get; set; }
    public bool Tech1Assign { get; set; }
    public bool Tech2Assign { get; set; }
    public bool Tech3Assign { get; set; }
    public bool PgmAssign { get; set; }
    public bool Pgm1Assign { get; set; }
}
public class ChangeTlInActive
{
    [Required]
    public int TeamLeader { get; set; }
    [Required]
    public string EnquiryRef { get; set; }

}