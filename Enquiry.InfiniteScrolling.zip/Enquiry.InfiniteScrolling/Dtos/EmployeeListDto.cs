﻿using Enquiry.Blazor.Models;
using Enquiry.Blazor.Services;

namespace Enquiry.Blazor.Dtos;

public class EmployeeListDto
{
    public int EmpId { get; set; }
    public string IdentityNo { get; set; }
    public string EmployeeName { get; set; }
    public string ContactNo { get; set; }
    public string EmailId { get; set; }
    public string Address { get; set; }
    public string DeptName { get; set; }
    public string RoleName { get; set; }
    public int? SuperiorId { get; set; }
    public string SuperiorName { get; set; }
    public string MemberId { get; set; }
    public bool IsPasswordChanges { get; set; }
    public bool IsActive { get; set; }
}

public class EmployeeSalaryInfo
{
    public int TotalAmount { get; set; }
    public double BasicSalary { get; set; }
    public double HRA { get; set; }
    public double EmployerPF { get; set; }
    public double EmployeePF { get; set; }
    public double TotalPF { get; set; }
    public double EmployerEsi { get; set; }
    public double EmployeeEsi { get; set; }
    public double TotalEsi { get; set; }
    public double TakeHome { get; set; }
    public double GrossSalary { get; set; }
    public double CTC { get; set; }
}

public class EmployeeFileViewModel
{
    public List<EmployeeListDto> Employees { get; set; }
    public List<int> SelectedEmployeeIds { get; set; }
    public IFormFile UploadedFile { get; set; }
}

