﻿using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Dtos
{
    public class CreateProjectDto
    {
        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime RegistrationDate { get; set; }
        [Required]
        public string FeeConfirmation { get; set; }
        [Required]
        public string ProjectName { get; set; }
        [Required]
        public int TotalPayment { get; set; }
        [Required]
        public string WorkType { get; set; }
        public string ProjectRemark { get; set; }
        public CreatePhaseDto CreatePhaseDto { get; set; }
        public CreatePayment CreatePayment { get; set; }
        public ClientDetailsDto ClientDetailsDto { get; set; }

    }
    public class CreatePhaseDto
    {
        [Required]
        public int PhaseName { get; set; }
        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime? DeadLine { get; set; }
        //[DataType(DataType.Date)]
        //public DateTime? AssignedDate { get; set; }
        public bool IsPublication { get; set; } = false;
        [Required]
        public string PhaseRemark { get; set; }
        public IEnumerable<IFormFile> JournalFiles { get; set; }

    }

    public class CreatePayment
    {
        [Required]
        public int? PartPayment { get; set; }
        [Required]
        public int PaymentType { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime? PaymentDate { get; set; }

    }

    public class ClientDetailsDto
    {
        public int EnquiryId { get; set; }
        public string ClientName { get; set; }
        public string Domain { get; set; }
        public string Contact { get; set; }
        public string EnquiryRef { get; set; }
        public int? TechId { get; set; }
        public string ProName { get; set; }
        public string BDAName { get; set; }
        public string TechName { get; set; }
        public bool TechIsActive { get; set; }
    }

    public class EditPhaseDto
    {
        public int PhaseId { get; set; }
        [Required]
        public string PhaseName { get; set; }
        [Required]
        public DateTime? DeadLine { get; set; }
        public int? Programmer { get; set; }
        public int? Programmer1 { get; set; }
        public DateTime? DemoDate { get; set; } = null;
        public DateTime? DemoDate1 { get; set; }
        public DateTime? DemoDate2 { get; set; }
        public DateTime? DemoDate3 { get; set; }
        public DateTime? DemoDate4 { get; set; }
        public DateTime? DemoDate5 { get; set; }
        public int? TechExpert { get; set; }
        public int? TechExpert1 { get; set; }
        public int? TechExpert2 { get; set; }
        public int? TechExpert3 { get; set; }
        public string Remarks { get; set; }
        public string Remarks1 { get; set; }
        public string Remarks2 { get; set; }
        public string Remarks3 { get; set; }
        public string Remarks4 { get; set; }
        public string Remarks5 { get; set; }
        public bool IsPublication { get; set; }
        public bool TechStatus { get; set; }
        public bool TechStatus1 { get; set; }
        public bool TechStatus2 { get; set; }
        public bool TechStatus3 { get; set; }
        public bool IsProgrammerNeeded { get; set; }
        public bool IsTechNeeded { get; set; }
        public bool TechTLStatus { get; set; }
        public bool PgmTLStatus { get; set; }
        //public int? TechScore1 { get; set; }
        //public int? TechScore2 { get; set; }
        //public int? TechScore3 { get; set; }
        public bool ProgrammerStatus { get; set; }
        public bool ProgrammerStatus1 { get; set; }
    }
    public class EditPaymentDto
    {
        public int PaymentId { get; set; }
        [Required]
        public int? PartPayment { get; set; }
        [Required]
        public int PaymentType { get; set; }

    }

    public class EditPhaseOnHoldDto
    {
        [Required]
        public string Comment { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime? NextAppoinment { get; set; } = DateTime.Now;
        public bool IsCompleted { get; set; } = false;
        public bool IsCompletedphase { get; set; } = false;
        public bool IsCompletedphaseToHold { get; set; } = false;
        public bool IsCompletedphasbyTechTL { get; set; } = false;
        public bool IsCompletedphasbyPgmTL { get; set; } = false;
        public bool IsCompletedphaseqc { get; set; } = false;
        public bool CanCompleteProgrammer { get; set; } = false;
        public bool IsPublication { get; set; } = false;
        public string TechExpert { get; set; }
        public string TechExpert1 { get; set; }
        public string TechExpert2 { get; set; }
        public string TechExpert3 { get; set; }
        public string Programmer { get; set; }
        public string Programmer1 { get; set; }
        public int? TechScore { get; set; }
        public int? TechScore1 { get; set; }
        public int? TechScore2 { get; set; }
        public int? TechScore3 { get; set; }
        public int? ProgrammerScore { get; set; }
        public int? ProgrammerScore1 { get; set; }
        public bool IsReassigned { get; set; }
        public bool IsTL { get; set; } = false;
        public int? TechTL { get; set; }
        public int? PgmTL { get; set; }
        public bool TechTLStatus { get; set; }
        public bool PgmTLStatus { get; set; }
        public bool LastPublication { get; set; }
        public bool IsSelectFile { get; set; }
        public int? TechExpertId { get; set; }
        public int? TechExpert1Id { get; set; }
        public int? TechExpert2Id { get; set; }
        public int? TechExpert3Id { get; set; }
        public string Status { get; set; }
        public List<int> selectedTechFilesForPub { get; set; }
        public PhasefileViewDto phasefile { get; set; }
        public PlagiarismfileView PlagiarismfileView { get; set; }
    }
    public class PlagiarismfileView
    {
        public int PlagiarismRecipientId { get; set; }
        public int? PhaseId { get; set; }
        public int? EnquiryId { get; set; }
        public int? PlagFileId { get; set; }
        public int? AIFileId { get; set; }
        public string PlagFileName { get; set; }
        public string PlagFilePath { get; set; }
        public string AIFileName { get; set; }
        public string AIFilePath { get; set; }
        public DateTime? CreatedDate { get; set; }

    }
    public class PhasefileView
    {
        public int? PhaseId { get; set; }
        public int? ProposalId { get; set; }
        public int? VisoId { get; set; }
        public int? ReferencePaperId { get; set; }
        public int? OthersId { get; set; }
        public int? CodeId { get; set; }
        public int? DataSetId { get; set; }
        public int? GraphId { get; set; }
        public int? OthersPgmId { get; set; }
        public String ProposalPath { get; set; }
        public String VisoPath { get; set; }
        public String ReferencePaperPath { get; set; }
        public String OthersPath { get; set; }
        public String CodePath { get; set; }
        public String DataSetPath { get; set; }
        public String GraphPath { get; set; }
        public String OthersPgmPath { get; set; }
        public String Proposal { get; set; }
        public String Viso { get; set; }
        public String ReferencePaper { get; set; }
        public String Others { get; set; }
        public String Code { get; set; }
        public String DataSet { get; set; }
        public String Graph { get; set; }
        public String OthersPgm { get; set; }
        public bool? IsPublication { get; set; }
    }
    public class PhasefileViewDto
    {
        public IList<ProposalDto> ProposalDto { get; set; }
        public IList<VisoDto> VisoDto { get; set; }
        public IList<ReferencePaperDto> ReferencePaperDto { get; set; }
        public IList<OthersDto> OthersDto { get; set; }
        public IList<CodeDto> CodeDto { get; set; }
        public IList<DataSetDto> DataSetDto { get; set; }
        public IList<GraphDto> GraphDto { get; set; }
        public IList<OthersPgmDto> OthersPgmDto { get; set; }
        public IList<JournalCommentsDto> JournalCommentsDto { get; set; }
        public int? PhaseId { get; set; }
        public bool? IsPublication { get; set; }
    }
    public class ProposalDto
    {
        public int? EmpId { get; set; }
        public int? ProposalId { get; set; }
        public String Proposal { get; set; }
        public String ProposalPath { get; set; }
    }
    public class VisoDto
    {
        public int? EmpId { get; set; }
        public int? VisoId { get; set; }
        public String Viso { get; set; }
        public String VisoPath { get; set; }

    }
    public class ReferencePaperDto
    {
        public int? EmpId { get; set; }
        public int? ReferencePaperId { get; set; }
        public String ReferencePaper { get; set; }
        public String ReferencePaperPath { get; set; }

    }
    public class OthersDto
    {
        public int? EmpId { get; set; }
        public int? OthersId { get; set; }
        public String Others { get; set; }
        public String OthersPath { get; set; }

    }
    public class JournalCommentsDto
    {
        public int? EmpId { get; set; }
        public int? JournalCommentId { get; set; }
        public String JournalComment { get; set; }
        public String JournalCommentPath { get; set; }

    }
    public class CodeDto
    {
        public int? EmpId { get; set; }
        public int? CodeId { get; set; }
        public String Code { get; set; }
        public String CodePath { get; set; }

    }
    public class DataSetDto
    {
        public int? EmpId { get; set; }
        public int? DataSetId { get; set; }
        public String DataSet { get; set; }
        public String DataSetPath { get; set; }

    }
    public class GraphDto
    {
        public int? EmpId { get; set; }
        public int? GraphId { get; set; }
        public String Graph { get; set; }
        public String GraphPath { get; set; }

    }
    public class OthersPgmDto
    {
        public int? EmpId { get; set; }
        public int? OthersPgmId { get; set; }
        public String OthersPgm { get; set; }
        public String OthersPgmPath { get; set; }

    }
    public class PhaseDemoDto
    {
        [Required]
        public string Link { get; set; }
        public string TechExpert { get; set; }
        public string TechExpert1 { get; set; }
        public string TechExpert2 { get; set; }
        public string TechExpert3 { get; set; }
        public string Programmer { get; set; }
        public string Programmer1 { get; set; }
        public int? TechExpertId { get; set; }
        public int? TechExpert1Id { get; set; }
        public int? TechExpert2Id { get; set; }
        public int? TechExpert3Id { get; set; }
        public int? ProgrammerId { get; set; }
        public int? Programmer1Id { get; set; }
        public bool TechExpertChecked { get; set; }
        public bool TechExpert1Checked { get; set; }
        public bool TechExpert2Checked { get; set; }
        public bool TechExpert3Checked { get; set; }
        public bool ProgrammerChecked { get; set; }
        public bool Programmer1Checked { get; set; }

    }

    public class PhaseDemoListDto
    {
        public int PhaseId { get; set; }
        public string PhaseName { get; set; }
        public string Link { get; set; }
        public string ProjectRef { get; set; }
        public IList<TechFeedbackDto> TechFeedbackDto { get; set; }
        public IList<ProgrammerFeedbackDto> ProgrammerFeedbackDto { get; set; }
        public IList<BDAFeedbackDto> BDAFeedbackDto { get; set; }
        public string ClientName { get; set; }
        public int? EmpId { get; set; }
        public int? ClientId { get; set; }
        public string Status { get; set; }
        public string EmpStatus { get; set; }
        public bool IsClient { get; set; }
        public string IsClientFeedback { get; set; }
        public string IsClientFeedbackUpdatedBy { get; set; }
        public string Contact { get; set; }
        public DateTime CreatedOn { get; set; }

    }
    public class BDAFeedbackDto
    {
        public int? EmpId { get; set; }
        public string EmpName { get; set; }
        public string EmpFeedback { get; set; }
    }
    public class TechFeedbackDto
    {
        public int? EmpId { get; set; }
        public string EmpName { get; set; }
        public string EmpFeedback { get;set; }
    }
    public class ProgrammerFeedbackDto
    {
        public int? EmpId { get; set; }
        public string EmpName { get; set; }
        public string EmpFeedback { get; set; }
    }
    public class UpdatePhaseDemoListDto
    {
        public string Status { get; set; }
        [Required(ErrorMessage = "Feedback is required.")]
        public string Feedback { get; set; }
        public bool IsClient { get; set; } = false;
        public bool IsDemoAgain { get; set; }
        public string Link { get; set; }
        public int? EmpId { get; set; }
    }
    public class GetDemoFeedbackDto
    {
        public int PhaseId { get; set; }
        public int? EmpId { get; set; }
        public string Link { get; set; }
        public string ClientName { get; set; }
        public string Contact { get; set; }
        public string? Feedback { get; set; }

    }
    public class EditTotalPaymentDetailDto
    {
        public int ProjectId { get; set; }
        [Required]
        public int TotalPayment { get; set; }
        [Required]
        public string PaymentConfirmation { get; set; }
        public string ProjectName { get; set; }
        [Display(Name = "ProjectName")]
        public string ProjectStatusName { get; set; }
        [Display(Name = "TotalPayment")]
        public int Payment { get; set; }
        public string WorkType { get; set; }
        public int EnquiryId { get; set; }
    }

    public class PhaseForPublicationDto
    {
        public int PhaseId { get; set; }
        public string Name { get; set; }

    }
}
