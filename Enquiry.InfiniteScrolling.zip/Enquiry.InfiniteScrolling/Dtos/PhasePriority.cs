﻿namespace Enquiry.Blazor.Dtos
{
    public class PhasePriority
    {
        public int PhaseId { get; set; }
        public int EmployeeId { get; set; }
        public int PriorityId { get; set; }
        public DateTime DemoDate { get; set; }
        public string Input { get; set; }
        public string Remark { get; set; }

    }
}
