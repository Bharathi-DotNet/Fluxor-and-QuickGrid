﻿using System.Net;
using System.Security.Authentication;
namespace Enquiry.Blazor.Helpers
{
    public class GlobalExceptionHandler
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<GlobalExceptionHandler> _logger;
        private readonly ISession _session;
        public GlobalExceptionHandler(
        RequestDelegate next,
        ILogger<GlobalExceptionHandler> logger, IHttpContextAccessor httpContextAccessor)
        {
            _next = next;
            _logger = logger;
            _session = httpContextAccessor.HttpContext?.Session;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                _logger.LogError(
                    ex, "Exception occurred: {Message}", ex.Message);

                if (IsCookieOrSessionException(ex))
                {
                    context.Response.Redirect("/Login/CheckCookieValidity");
                    return;
                }

                await HandleGlobalExceptionAsync(context, ex);
            }
        }

        private bool IsCookieOrSessionException(Exception ex)
        {            
            bool isSessionNull = _session == null;

            return ex.Message.Contains("cookie", StringComparison.OrdinalIgnoreCase)
                || ex.Message.Contains("session", StringComparison.OrdinalIgnoreCase)
                || isSessionNull
                || ex is CookieException
                || ex is AuthenticationException;
        }

        private Task HandleGlobalExceptionAsync(HttpContext context, Exception ex)
        {
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            context.Response.ContentType = "text/html";

            // Redirect to a generic error page or return a custom error response
            context.Response.Redirect("/Home/Error");

            return Task.CompletedTask;
        }
    }
}
