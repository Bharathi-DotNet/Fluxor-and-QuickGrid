﻿using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using System.IO;
using System.IO.Compression;
using System.Net.Mime;
using System.Reflection.PortableExecutable;

namespace Enquiry.Blazor.Helpers
{
    public static class StreamCompression
    {
        public static byte[] Compress(byte[] data)
        {
            using (MemoryStream compressedStream = new MemoryStream())
            {
                using (GZipStream gzipStream = new GZipStream(compressedStream, CompressionMode.Compress))
                {
                    gzipStream.Write(data, 0, data.Length);
                }
                return compressedStream.ToArray();
            }
        }

        public static byte[] Decompress(byte[] data)
        {
            using (MemoryStream compressedStream = new MemoryStream(data))
            using (MemoryStream decompressedStream = new MemoryStream())
            {
                using (GZipStream gzipStream = new GZipStream(compressedStream, CompressionMode.Decompress))
                {
                    gzipStream.CopyTo(decompressedStream);
                }
                return decompressedStream.ToArray();
            }
        }

        public static async Task<byte[]> UploadImageToDb(IFormFile photo)
        {
            using (var ms = new MemoryStream())
            {
                await photo.CopyToAsync(ms);
                using (var image = Image.Load(ms.ToArray()))
                {
                    long lengthInBytes;
                    if (ms.Length > 100 * 1024)
                    {
                        do
                        {
                            image.Mutate(x => x.Resize(image.Width / 2, image.Height / 2));

                            using (var tempStream = new MemoryStream())
                            {
                                image.Save(tempStream, new SixLabors.ImageSharp.Formats.Jpeg.JpegEncoder());
                                lengthInBytes = tempStream.Length;
                                ms.SetLength(0);
                                tempStream.Seek(0, SeekOrigin.Begin);
                                await tempStream.CopyToAsync(ms);
                            }

                        } while (lengthInBytes > 100 * 1024); // 100 KB
                    }
                    ms.Seek(0, SeekOrigin.Begin);
                    return ms.ToArray();
                }
            }
        }

        public static async Task<byte[]> GetDefaultPhotoBytesAsync(string photoPath)
        {
            using (var image = Image.Load(photoPath))
            using (var ms = new MemoryStream())
            {
                image.Save(ms, image.Metadata.DecodedImageFormat);
                return ms.ToArray();
            }
        }

        public static async Task<string> UploadImageToFolder(IFormFile photo, string fileName, string uploadsFolderPath)
        {
            if (!Directory.Exists(uploadsFolderPath))
            {
                Directory.CreateDirectory(uploadsFolderPath);
            }
            if (string.IsNullOrEmpty(fileName))
            {
                var uniqueFileName = Guid.NewGuid().ToString() + Path.GetExtension(photo.FileName);
                var filePath = Path.Combine(uploadsFolderPath, uniqueFileName);

                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await photo.CopyToAsync(fileStream);
                }

                return uniqueFileName;
            }
            else
            {
                var filePath = Path.Combine(uploadsFolderPath, fileName);

                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await photo.CopyToAsync(fileStream);
                }

                return fileName;

            }
            
        }

        public static async Task<string> UploadImageToFolder(byte[] photo, string fileName, string uploadsFolderPath)
        {
            if (!Directory.Exists(uploadsFolderPath))
            {
                Directory.CreateDirectory(uploadsFolderPath);
            }

            if (string.IsNullOrEmpty(fileName))
            {
                var uniqueFileName = Guid.NewGuid().ToString() + Path.GetExtension(".png");
                var filePath = Path.Combine(uploadsFolderPath, uniqueFileName);
                using (var memoryStream = new MemoryStream(photo))
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await memoryStream.CopyToAsync(fileStream);
                }

                return uniqueFileName;
            }
            else
            {

                var filePath = Path.Combine(uploadsFolderPath, fileName);
                using (var memoryStream = new MemoryStream(photo))
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await memoryStream.CopyToAsync(fileStream);
                }

                return fileName;
            }

        }

        public static async Task<string> FindImageAndConvertToBase64String(string filePath)
        {
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException("File not found.", filePath);
            }

            byte[] fileBytes = await File.ReadAllBytesAsync(filePath);
            return Convert.ToBase64String(fileBytes);
        }

        //public static async Task<IFormFile> FindImageAndConvertToIFormFile(string filePath)
        //{
        //    if (!File.Exists(filePath))
        //    {
        //        throw new FileNotFoundException("File not found.", filePath);
        //    }

        //    var fileBytes = await File.ReadAllBytesAsync(filePath);
        //    var fileName = Path.GetFileName(filePath);

        //    return new FormFile(fileBytes, fileName, GetContentType(filePath));
        //}

        private static string GetContentType(string path)
        {
            var types = GetMimeTypes();
            var ext = Path.GetExtension(path).ToLowerInvariant();
            return types.ContainsKey(ext) ? types[ext] : "application/octet-stream";
        }

        private static Dictionary<string, string> GetMimeTypes()
        {
            return new Dictionary<string, string>
        {
            { ".txt", "text/plain" },
            { ".pdf", "application/pdf" },
            { ".doc", "application/vnd.ms-word" },
            { ".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document" },
            { ".xls", "application/vnd.ms-excel" },
            { ".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" },
            { ".png", "image/png" },
            { ".jpg", "image/jpeg" },
            { ".jpeg", "image/jpeg" },
            { ".gif", "image/gif" },
            { ".bmp", "image/bmp" },
            { ".zip", "application/zip" },
            { ".rar", "application/x-rar-compressed" }
        };
        }
    }
}
