﻿using Microsoft.AspNetCore.Authorization;

namespace Enquiry.Blazor.Helpers
{
    public class PolicyRequirement: IAuthorizationRequirement
    {
        public string Department { get; }
        public string Role { get; }

        public PolicyRequirement(string department, string role)
        {
            Department = department;
            Role = role;
        }
    }
}
