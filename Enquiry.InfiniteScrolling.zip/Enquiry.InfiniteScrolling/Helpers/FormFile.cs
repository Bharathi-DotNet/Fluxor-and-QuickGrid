﻿namespace Enquiry.Blazor.Helpers
{
    public class FormFile : IFormFile
    {
        private readonly Stream _stream;

        public FormFile(byte[] fileBytes, string fileName, string contentType = null)
        {
            _stream = new MemoryStream(fileBytes);
            FileName = fileName;
            ContentType = contentType ?? "application/octet-stream";
            Length = fileBytes.Length;
            Headers = new HeaderDictionary();
            ContentDisposition = $"form-data; name=\"{fileName}\"; filename=\"{fileName}\"";
        }

        public Stream OpenReadStream()
        {
            _stream.Position = 0;
            return _stream;
        }

        public void CopyTo(Stream target)
        {
            _stream.CopyTo(target);
        }

        public async Task CopyToAsync(Stream target, CancellationToken cancellationToken = default)
        {
            await _stream.CopyToAsync(target, cancellationToken);
        }

        public string ContentType { get; }
        public string ContentDisposition { get; }
        public IHeaderDictionary Headers { get; }
        public long Length { get; }
        public string Name { get; }
        public string FileName { get; }
    }
}
