﻿using Enquiry.Blazor.Models;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace Enquiry.Blazor.Helpers
{
    public class UniqueAttribute : ValidationAttribute
    {
        private readonly string _tableName;
        private readonly string _columnName;
        private readonly string _idColumnName;

        public UniqueAttribute(string tableName, string columnName, string idColumnName)
        {
            _tableName = tableName;
            _columnName = columnName;
            _idColumnName = idColumnName;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null)
            {
                return ValidationResult.Success;
            }
            var dbContext = (ApplicationDbContext)validationContext.GetService(typeof(ApplicationDbContext));
            var entityType = validationContext.ObjectInstance.GetType();
            var idProperty = entityType.GetProperty(_idColumnName);
            var currentId = idProperty.GetValue(validationContext.ObjectInstance);

            var query = dbContext.Set<DbContext>()
            .FromSqlRaw($"SELECT * FROM {_tableName} WHERE {_columnName} = @p0 AND {_idColumnName} <> @p1", value.ToString(), currentId)
            .AsNoTracking();

            if (query.Any())
            {
                return new ValidationResult($"{_columnName} must be unique.");
            }

            return ValidationResult.Success;
        }
    }
}
