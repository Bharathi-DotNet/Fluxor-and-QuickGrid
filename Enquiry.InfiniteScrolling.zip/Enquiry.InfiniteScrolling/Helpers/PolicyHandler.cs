﻿using Microsoft.AspNetCore.Authorization;

namespace Enquiry.Blazor.Helpers
{
    public class PolicyHandler: AuthorizationHandler<PolicyRequirement>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, PolicyRequirement requirement)
        {
            // Check if the user has the required role
            if (!context.User.IsInRole(requirement.Role))
            {
                return Task.CompletedTask;
            }

            // Check if the user has the required department claim
            var departmentClaim = context.User.Claims.FirstOrDefault(c => c.Type == "Dept");
            if (departmentClaim != null && departmentClaim.Value == requirement.Department)
            {
                context.Succeed(requirement);
            }

            return Task.CompletedTask;
        }
    }
}
