﻿namespace Enquiry.Blazor.Helpers
{
    public class ImageFormatHelper
    {
        private static readonly Dictionary<byte[], string> ImageFormats = new Dictionary<byte[], string>(new ByteArrayComparer())
    {
        { new byte[] { 0xFF, 0xD8, 0xFF }, ".jpg" },
        { new byte[] { 0x89, 0x50, 0x4E, 0x47 }, ".png" },
        { new byte[] { 0x47, 0x49, 0x46, 0x38 }, ".gif" },
        { new byte[] { 0x42, 0x4D }, ".bmp" },
        { new byte[] { 0x49, 0x49, 0x2A, 0x00 }, ".tiff" },
        { new byte[] { 0x4D, 0x4D, 0x00, 0x2A }, ".tiff" },
        // Add more image formats and their signatures as needed
    };

        public static string GetImageExtension(byte[] bytes)
        {
            foreach (var format in ImageFormats)
            {
                if (bytes.Length >= format.Key.Length)
                {
                    var fileHeader = new byte[format.Key.Length];
                    Array.Copy(bytes, fileHeader, fileHeader.Length);

                    if (AreEqual(fileHeader, format.Key))
                    {
                        return format.Value;
                    }
                }
            }

            return null; // Unknown image format
        }

        private static bool AreEqual(byte[] a, byte[] b)
        {
            if (a.Length != b.Length)
                return false;

            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] != b[i])
                    return false;
            }

            return true;
        }

        private class ByteArrayComparer : IEqualityComparer<byte[]>
        {
            public bool Equals(byte[] x, byte[] y)
            {
                return AreEqual(x, y);
            }

            public int GetHashCode(byte[] obj)
            {
                unchecked
                {
                    if (obj == null)
                        return 0;

                    int hash = 17;
                    foreach (var b in obj)
                    {
                        hash = hash * 31 + b;
                    }
                    return hash;
                }
            }
        }
    }
}
