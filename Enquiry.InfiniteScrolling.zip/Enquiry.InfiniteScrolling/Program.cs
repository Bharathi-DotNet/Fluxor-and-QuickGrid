using Enquiry.Blazor.Components;
using Enquiry.Blazor.Models;
using Enquiry.Blazor.Services.Interface;
using Enquiry.Blazor.Services;
using Microsoft.EntityFrameworkCore;
using SlackNet.AspNetCore;
using Enquiry.Blazor.Extensions;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc.Routing;
using Fluxor;
using Fluxor.Blazor.Web.ReduxDevTools;
using Enquiry.Blazor.StateManagement.Enquiry;

var builder = WebApplication.CreateBuilder(args);

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<ApplicationDbContext>(options =>
{
    options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));
});

builder.Services.Configure<SlackConfig>(builder.Configuration.GetSection("SlackConfig"));
builder.Services.Configure<FtpConfig>(builder.Configuration.GetSection("FtpConfig"));
builder.Services.Configure<AssignTime>(builder.Configuration.GetSection("AssignTime"));
builder.Services.Configure<GoogleAuthConfig>(builder.Configuration.GetSection("GoogleAuth"));
builder.Services.Configure<ImapMailConfig>(builder.Configuration.GetSection("ImapMailConfig"));
builder.Services.Configure<IpConfig>(builder.Configuration.GetSection("IpConfig"));
var slackConfig = builder.Configuration.GetSection("SlackConfig").Get<SlackConfig>();
builder.Services.AddSlackNet(c => c
    .UseApiToken(slackConfig.ApiToken)
    .UseSigningSecret(slackConfig.SigningSecret));

builder.Services.AddAsymmetricAuthentication();
//builder.Services.AddTransient<IDatabaseInitializer, DBInitializer>();
builder.Services.AddScoped<IClient, Client>();
builder.Services.AddScoped<IEmployee, Employee>();
builder.Services.AddScoped<IProject, Project>();
builder.Services.AddScoped<IPublication, Enquiry.Blazor.Services.Publication>();
builder.Services.AddScoped<IVisitor, VisitorService>();
builder.Services.AddScoped<AuthenticationService>();
builder.Services.AddScoped<UserService>();
builder.Services.AddScoped<TokenService>();
builder.Services.AddScoped<UserRepository>();
builder.Services.AddScoped<IHomeService, HomeService>();
builder.Services.AddScoped<IReport, ReportService>();
builder.Services.AddScoped<ISlack, SlackService>();
builder.Services.AddScoped<IPlagiarismService, PlagiarismService>();
builder.Services.AddScoped<IEmail, EmailService>();
builder.Services.AddScoped<IGoogleAuthService, GoogleAuthService>();
builder.Services.AddScoped<IMcube, MCubeService>();
builder.Services.AddSingleton<ClientState>();
builder.Services.AddAutoMapper(typeof(Program));
builder.Services.AddFluxor(options =>
{
    options.ScanAssemblies(typeof(Program).Assembly);
    options.UseReduxDevTools(); // Add this line to enable Redux DevTools
});

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();
//builder.Services.AddSingleton<HttpClient>(new HttpClient { BaseAddress = new Uri("https://localhost:7197") });

builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(opts =>
{
    opts.IdleTimeout = TimeSpan.FromHours(25);
    opts.Cookie.IsEssential = true; // make the session cookie Essential
});

builder.Services.Configure<CookiePolicyOptions>(options =>
{
    options.CheckConsentNeeded = context => true; // consent required
    options.MinimumSameSitePolicy = SameSiteMode.Lax;
});

builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

builder.Services.Configure<FormOptions>(options =>
{
    options.MultipartBodyLengthLimit = 1_000_000_000; // Set the limit to 1 GB (in bytes)
});

builder.Services.AddHttpClient();

builder.Services.AddSingleton<IUrlHelperFactory, UrlHelperFactory>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseSlackNet();
app.UseHttpsRedirection();
app.UseCookiePolicy();
app.UseSession();
app.UseAntiforgery();
app.UseAuthentication();
app.UseAuthorization();
app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
