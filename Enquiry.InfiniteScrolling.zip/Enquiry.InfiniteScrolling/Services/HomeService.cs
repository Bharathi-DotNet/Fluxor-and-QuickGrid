﻿using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Enum;
using Enquiry.Blazor.Models;
using Enquiry.Blazor.Services.Interface;
using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Hosting;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using static Enquiry.Blazor.Dtos.DashboardDto;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace Enquiry.Blazor.Services
{
    public class HomeService : IHomeService
    {
        private readonly ApplicationDbContext _context;
        readonly IProject _project;
        public HomeService(ApplicationDbContext context, IProject project)
        {
            _context = context;
            _project = project;
        }
        public async Task<IList<DiscussionPendingDto>> EnquiryPendingDiscussionAsync()
        {
            return await _context.Clients.Where(x => x.IsTechAppoinment == true && x.Registered == false
            && x.AppoinmentDate <= DateTime.Now.AddHours(-5)).Select(x => new DiscussionPendingDto
            {
                ClientName = x.ClientName.Substring(0, 25),
                EnquiryId = x.EnquiryId,
                TechName = x.TechEmployee != null ? x.TechEmployee.EmployeeName.Substring(0, 10) : "Not Assigned",
                BDAName = x.BDAEmployee != null ? x.BDAEmployee.EmployeeName.Substring(0, 10) : "Not Assigned",
                AppointmentDate = x.AppoinmentDate
            }).ToListAsync();
        }

        public async Task<IList<AssignedPhaseDto>> ProductionAssignedPhaseAsync()
        {
            var phaseList = new List<AssignedPhaseDto>();
            try
            {
                var query = _context.Projects.Include(x => x.Phase)
                    .Include(x => x.Clients).Include(x => x.Clients).ThenInclude(x => x.TechTLEmployee).ToList();
                var phase = query.Select(x => x.Phase.LastOrDefault()).Where(x=>(x.Status == (int)Enum.WorkStatus.Assigned && x.TechExpert == null) 
                || (x.Status == (int)Enum.WorkStatus.Progress && x.Programmer == null && x.IsProgrammerNeeded)).OrderBy(dto => dto.DeadLine);
                foreach (var item in phase)
                {
                    if (item != null
                        && item.DeadLineCount > 0 && DateTime.Now > item.AssignedDate.Value.AddDays(item.DeadLineCount.Value))
                    {
                        var obj = new AssignedPhaseDto()
                        {
                            ClientName = item.Projects.Clients.ClientName,
                            ProjectId = item.Projects.ProjectId,
                            EnquiryId = item.Projects.Clients.EnquiryId,
                            PhaseName = item.PhaseName,
                            IsTechEnabled = item.IsTechNeeded,
                            IsPgmEnabled = item.IsProgrammerNeeded,
                            DeadLine = item.DeadLine,
                            ProjectRef = item.Projects.ProjectRef,
                            TechTl = item.Projects.Clients.TechTLEmployee?.EmployeeName
                        };
                        phaseList.Add(obj);
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            return phaseList;
        }

        public async Task<IList<DueDateExceededDto>> ProductionDeadLineAsync()
        {
            try
            {
                var phases = _context.Projects.Include(x => x.Clients).Include(x => x.Phase).ThenInclude(x => x.Employees)
                    .Include(x => x.Phase).ThenInclude(x => x.Projects).ThenInclude(x => x.Clients)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees1)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees2)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees3)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees4)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees5)
                    .Select(x => x.Phase.OrderBy(y => y.PhaseId).LastOrDefault()) // Flatten phases for all projects
                    .Where(y => y.Status == 2 && y.DeadLine < DateTime.Now).ToList() // Filter phases by status
                    .GroupBy(y => y.ProjectId).Select(g => new
                    {
                        ProjectId = g.Key,
                        Phase = g.Select(x => new DueDateExceededDto
                        {
                            ClientName = x.Projects.Clients.ClientName,
                            ProjectId = x.Projects.ProjectId,
                            EnquiryId = x.Projects.Clients.EnquiryId,
                            Deadline = x.DeadLine,
                            ProjectRef = x.Projects.ProjectRef,
                            TechName = x.Employees != null ? x.Employees.EmployeeName : "",
                            TechName1 = x.Employees1 != null ? x.Employees1.EmployeeName : "",
                            TechName2 = x.Employees2 != null ? x.Employees2.EmployeeName : "",
                            TechName3 = x.Employees3 != null ? x.Employees3.EmployeeName : "",
                            Programmer = x.Employees4 != null ? x.Employees4.EmployeeName : "",
                            Programmer1 = x.Employees5 != null ? x.Employees5.EmployeeName : "",
                        }).ToList()
                    });

                var groupedPhases = phases.SelectMany(x => x.Phase).ToList();
                return groupedPhases.OrderBy(x => x.Deadline).ToList();
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public async Task<IList<DueDateExceededDto>> ProductionDueDateExceededAsync()
        {
            try
            {
                var employees = await _context.Employees.Where(x=> x.IsActive == true).ToListAsync();
                var result = await GetCurrentPhaseLists();

                if (result.Succeeded)
                {
                    var allPhases = result.phase;
                    var groupedPhases = new List<DueDateExceededDto>();

                    foreach (var employee in employees)
                    {
                        var filteredPhasesForEmployee = allPhases.Where(phase => (phase.Status == 2 || phase.Status == 1) &&
                             (
                                 (phase.TechExpert == employee.EmpId && phase.DemoDate < DateTime.Now) ||
                                 (phase.TechExpert1 == employee.EmpId && phase.DemoDate1 < DateTime.Now) ||
                                 (phase.TechExpert2 == employee.EmpId && phase.DemoDate2 < DateTime.Now) ||
                                 (phase.TechExpert3 == employee.EmpId && phase.DemoDate4 < DateTime.Now) ||
                                 (phase.Programmer == employee.EmpId && phase.DemoDate3 < DateTime.Now) ||
                                 (phase.Programmer1 == employee.EmpId && phase.DemoDate5 < DateTime.Now)
                             ))
                           .Select(phase =>
                           {
                               var clientName = phase.Projects?.Clients?.ClientName ?? "Unknown";
                               var phaseName = phase.PhaseName;
                               var projectId = phase.Projects.ProjectId;
                               var enquiryId = phase.Projects.EnquiryId;
                               if (phase.TechExpert == employee.EmpId && phase.DemoDate < DateTime.Now)
                               {
                                   return new DueDateExceededDto { Tech = phase.TechExpert, DemoDate = phase.DemoDate, ClientName = clientName, PhaseName = phaseName, ProjectRef = phase.Projects.ProjectRef,ProjectId = projectId,EnquiryId = enquiryId };
                               }

                               if (phase.TechExpert1 == employee.EmpId && phase.DemoDate1 < DateTime.Now)
                               {
                                   return new DueDateExceededDto { Tech = phase.TechExpert1, DemoDate = phase.DemoDate1, ClientName = clientName, PhaseName = phaseName, ProjectRef = phase.Projects.ProjectRef, ProjectId = projectId, EnquiryId = enquiryId };
                               }

                               if (phase.TechExpert2 == employee.EmpId && phase.DemoDate2 < DateTime.Now)
                               {
                                   return new DueDateExceededDto { Tech = phase.TechExpert2, DemoDate = phase.DemoDate2, ClientName = clientName, PhaseName = phaseName, ProjectRef = phase.Projects.ProjectRef, ProjectId = projectId, EnquiryId = enquiryId };
                               }

                               if (phase.TechExpert3 == employee.EmpId && phase.DemoDate4 < DateTime.Now)
                               {
                                   return new DueDateExceededDto { Tech = phase.TechExpert3, DemoDate = phase.DemoDate4, ClientName = clientName, PhaseName = phaseName, ProjectRef = phase.Projects.ProjectRef, ProjectId = projectId, EnquiryId = enquiryId };
                               }

                               if (phase.Programmer == employee.EmpId && phase.DemoDate3 < DateTime.Now)
                               {
                                   return new DueDateExceededDto { Tech = phase.Programmer, DemoDate = phase.DemoDate3, ClientName = clientName, PhaseName = phaseName, ProjectRef = phase.Projects.ProjectRef, ProjectId = projectId, EnquiryId = enquiryId };
                               }

                               if (phase.Programmer1 == employee.EmpId && phase.DemoDate5 < DateTime.Now)
                               {
                                   return new DueDateExceededDto { Tech = phase.Programmer1, DemoDate = phase.DemoDate5, ClientName = clientName, PhaseName = phaseName, ProjectRef = phase.Projects.ProjectRef, ProjectId = projectId, EnquiryId = enquiryId };
                               }

                               return null;
                           })
                           .Where(result => result != null)
                           .ToList();

                        groupedPhases.AddRange(filteredPhasesForEmployee);
                    }

                    // Group by Tech and aggregate client names and demo dates for each tech
                    var groupedByTech = groupedPhases.GroupBy(dto => dto.Tech)
                        .Select(group =>
                        {
                            var tech = group.Key;
                            var techName = employees.FirstOrDefault(e => e.EmpId == tech)?.EmployeeName;
                            var projectIds = group.Select(dto => dto.ProjectId).ToList();
                            var enquiryIds = group.Select(dto => dto.EnquiryId).ToList();
                            var clientNames = group.Select(dto => new ClientName
                            {
                                Name = $"{dto.ClientName}  <b>{dto.ProjectRef.Substring(7)}</b> {dto.PhaseName}",
                                EnquiryId = dto.EnquiryId,
                                ProjectId = dto.ProjectId
                            }).ToList();
                            var demoDates = group.Select(dto => dto.DemoDate).ToList();
                            //var phaseNames = group.Select(dto => dto.PhaseName).ToList();
                            return new DueDateExceededDto
                            {
                                Tech = tech,
                                TechName = techName,
                                ClientNames = clientNames,
                                DemoDates = demoDates,
                                //PhaseNames = phaseNames
                            };
                        })
                        .ToList();

                    return groupedByTech;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<IList<PublicationDeadLineDto>> PublicationDeadLineAsync()
        {
            try
            {
                var publications = _context.Projects.Include(x => x.Publication).ThenInclude(x => x.Projects)
                    .Include(x => x.Publication).ThenInclude(x => x.Projects).ThenInclude(x => x.Clients)
                    .Include(x => x.Publication).ThenInclude(x => x.Projects).ThenInclude(x => x.Phase)
                    .Select(x => x.Publication.OrderBy(y => y.PublicationId).LastOrDefault()) // Flatten phases for all projects
                    .Where(y => y.Status == 1 || y.Status == 2 || y.Status == 3 || y.Status == 4 || y.Status == 5 || y.Status == 6 || y.Status == 7 || y.Status == 8 || y.Status == 9).ToList();
                var datas = new List<PublicationDeadLineDto>();
                if (publications != null)
                {
                    foreach (var pub in publications)
                    {
                        var exists = _context.Publication.Any(x => x.ProjectId == pub.ProjectId && (x.Status == 5 || x.Status == 6 || x.Status == 10));
                        if (!exists && pub.Projects.Phase.LastOrDefault(x => x.Status == 4).DeadLine < DateTime.Now)
                        {
                            var data = new PublicationDeadLineDto
                            {
                                ClientName = pub.Projects.Clients.ClientName,
                                ProjectId = pub.Projects.ProjectId,
                                EnquiryId = pub.Projects.Clients.EnquiryId,
                                Deadline = pub.Projects.Phase.LastOrDefault(x => x.Status == 4).DeadLine,
                                ProjectRef = pub.Projects.ProjectRef,
                                PhaseName = pub.Projects.Phase.LastOrDefault(x => x.Status == 4).PhaseName,
                                Submitted = _context.Publication.Count(x => x.ProjectId == pub.ProjectId && x.Status == (int)Enum.JournalStatus.Submitted),
                                Rejected = _context.Publication.Count(x => x.ProjectId == pub.ProjectId && x.Status == (int)Enum.JournalStatus.Rejected),
                                Major = _context.Publication.Count(x => x.ProjectId == pub.ProjectId && x.Status == (int)Enum.JournalStatus.Major),
                                Minor = _context.Publication.Count(x => x.ProjectId == pub.ProjectId && x.Status == (int)Enum.JournalStatus.Minor),
                                //Accepted = _context.Publication.Count(x => x.ProjectId == pub.ProjectId && x.Status == (int)Enum.JournalStatus.Accepted),
                                //Published = _context.Publication.Count(x => x.ProjectId == pub.ProjectId && x.Status == (int)Enum.JournalStatus.Published),
                            };
                            datas.Add(data);
                        }

                    }
                }

                return datas.OrderBy(x => x.Deadline).ToList();
                //return null;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public async Task<IList<JournalSubmit>> JournalNotInFiveAsync()
        {
            try
            {
                var phase = new List<JournalSubmit>();
                var ProjectIds = new List<int>();
                var query = _context.Projects.Include(x => x.Phase)
   .Include(x => x.Clients).ToList();
                var ProjectList = query.Select(x => x.Phase.LastOrDefault()).Where(x => x.Status == (int)Enum.WorkStatus.Publication).Select(x => x.ProjectId).ToList();
                var pubStatus1 = _context.Publication.Where(x => (x.Status == (int)Enum.JournalStatus.Submitted
                || x.Status == (int)Enum.JournalStatus.Rejected
                || x.Status == (int)Enum.JournalStatus.MailAccount
                || x.Status == (int)Enum.JournalStatus.ToApply) && ProjectList.Contains(x.ProjectId)
                 && !_context.Publication.Any(p => p.ProjectId == x.ProjectId && p.Status == (int)Enum.JournalStatus.Terminated)
                 ).OrderBy(x => x.ProjectId).ToList();

                foreach (var item in pubStatus1.GroupBy(x => x.ProjectId))
                {
                    var check = _context.Publication.Where(x => x.ProjectId == item.Key &&
                    (x.Status == (int)Enum.JournalStatus.Major
                || x.Status == (int)Enum.JournalStatus.Minor || x.Status == (int)Enum.JournalStatus.Accepted
                || x.Status == (int)Enum.JournalStatus.Published
                || x.Status == (int)Enum.JournalStatus.ClientWithdraw)).ToList();
                    if (check.Count() == 0)
                    {
                        var grp = pubStatus1.Count(x => x.ProjectId == item.Key
                        && x.Status == (int)Enum.JournalStatus.Submitted);
                        if (grp < 4)
                        {
                            ProjectIds.Add((int)item.Key);
                        }
                        else if (grp >= 4)
                        {
                            continue;
                        }
                        else
                        {
                            ProjectIds.Add((int)item.Key);
                        }

                    }
                }
                foreach (var item in ProjectIds)
                {
                    var res = await _context.Phase.Include(x => x.Projects)
                        .Include(x => x.Projects).ThenInclude(x => x.Clients)
                        .Where(x => x.ProjectId == item && x.Status == 4)
                        .OrderBy(x => x.ProjectId).LastOrDefaultAsync();
                    if (res != null)
                    {
                        var dto = new JournalSubmit()
                        {
                            ClientName = res.Projects.Clients.ClientName,
                            ProjectName = res.Projects.ProjectName,
                            ProjectId = res.Projects.ProjectId,
                            EnquiryId = res.Projects.Clients.EnquiryId,
                            PhaseName = res.PhaseName,
                            ProjectRef = res.Projects.ProjectRef,
                            Submitted = _context.Publication.Count(x => x.ProjectId == item && x.Status == (int)Enum.JournalStatus.Submitted),
                            Rejected = _context.Publication.Count(x => x.ProjectId == item && x.Status == (int)Enum.JournalStatus.Rejected),
                            Major = _context.Publication.Count(x => x.ProjectId == item && x.Status == (int)Enum.JournalStatus.Major),
                            Minor = _context.Publication.Count(x => x.ProjectId == item && x.Status == (int)Enum.JournalStatus.Minor),
                            Accepted = _context.Publication.Count(x => x.ProjectId == item && x.Status == (int)Enum.JournalStatus.Accepted),
                            Published = _context.Publication.Count(x => x.ProjectId == item && x.Status == (int)Enum.JournalStatus.Published),
                        };
                        phase.Add(dto);
                    }
                }
                return phase;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<IList<AssignedPhaseDto>> PublicationPendingAsync()
        {

            var query = await _context.Phase.Join(
        _context.Publication,
        phase => phase.ProjectId,
        pub => pub.ProjectId,
        (ps, pu) => new { phase = ps, pub = pu }).Select(x => x.pub.ProjectId).ToListAsync();

            var phase = _context.Phase.Include(x => x.Projects)
                .Include(x => x.Projects).ThenInclude(x => x.Clients)
                .Where(x => x.Status == (int)Enum.WorkStatus.Publication && !query.Contains(x.ProjectId) && x.AssignedDate < DateTime.Now.AddDays(-15)).Select(t => new AssignedPhaseDto()
                {
                    ClientName = t.Projects.Clients.ClientName,
                    ProjectId = t.Projects.ProjectId,
                    EnquiryId = t.Projects.Clients.EnquiryId,
                    PhaseName = t.PhaseName,
                    ProjectRef = t.Projects.ProjectRef,
                    DeadLine = t.AssignedDate
                }).ToList();
            return phase;
        }

        public Task<DashboardDto.AssignedPhaseDto> PublicationCountAsync()
        {
            throw new NotImplementedException();
        }

        public Task<DashboardDto.JournalPendingDto> PublicationJournalPendingAsync()
        {
            throw new NotImplementedException();
        }
        public async Task<(bool Succeeded, string[] Error, IList<ProjectNew> Data)> GetProjectDetailsAsync(int employeeId)
        {
            var filteredPhases = new List<ProjectNew>();
            var result = await GetCurrentPhaseLists();

            if (result.Succeeded)
            {
                var allPhases = result.phase;

                // Filter the phases based on the assigned tech fields
                filteredPhases = allPhases
                    .Where(phase => ((phase.TechExpert == employeeId && phase.TechStatus == false) ||
                                    (phase.TechExpert1 == employeeId && phase.TechStatus1 == false) ||
                                    (phase.TechExpert2 == employeeId && phase.TechStatus2 == false) ||
                                    (phase.TechExpert3 == employeeId && phase.TechStatus3 == false) ||
                                    (phase.Programmer == employeeId && phase.ProgrammerStatus == false) ||
                                    (phase.Programmer1 == employeeId && phase.ProgrammerStatus1 == false)) && phase.Status == 2)
                    .Select(phase => new ProjectNew
                    {
                        clientName = phase.Projects.Clients.ClientName,
                        projectName = phase.Projects.ProjectName,
                        phaseName = phase.PhaseName,
                        comment = phase.Comment,
                        nextAppoinment = phase.NextAppoinment?.ToString("yyyy-MM-dd"),
                        deadLine = phase.DeadLine?.ToString("yyyy-MM-dd"),
                        status = phase.WorkStatus.WorkStatusName,
                        enquiryRef = phase.Projects.ProjectRef,
                        contact = phase.Projects.Clients.Contact,
                        enquiryId = phase.Projects.Clients.EnquiryId,
                        projectId = phase.ProjectId,
                        demoDate = (employeeId) switch
                        {
                            _ when phase.TechExpert == employeeId => phase.DemoDate?.ToString("yyyy-MM-dd"),
                            _ when phase.TechExpert1 == employeeId => phase.DemoDate1?.ToString("yyyy-MM-dd"),
                            _ when phase.TechExpert2 == employeeId => phase.DemoDate2?.ToString("yyyy-MM-dd"),
                            _ when phase.TechExpert3 == employeeId => phase.DemoDate4?.ToString("yyyy-MM-dd"),
                            _ when phase.Programmer == employeeId => phase.DemoDate3?.ToString("yyyy-MM-dd"),
                            _ when phase.Programmer1 == employeeId => phase.DemoDate5?.ToString("yyyy-MM-dd"),
                            _ => null
                        },
                        phaseId = phase.PhaseId,
                        priority = (employeeId) switch
                        {
                            _ when phase.TechExpert == employeeId => phase.TechPriority,
                            _ when phase.TechExpert1 == employeeId => phase.TechPriority1,
                            _ when phase.TechExpert2 == employeeId => phase.TechPriority2,
                            _ when phase.TechExpert3 == employeeId => phase.TechPriority3,
                            _ when phase.Programmer == employeeId => phase.ProgrammerPriority,
                            _ when phase.Programmer1 == employeeId => phase.ProgrammerPriority1,
                            _ => null
                        }
                    })
                    .OrderBy(phase => phase.deadLine)
                    .ToList();

                return (true, Array.Empty<string>(), filteredPhases);
            }
            else
            {
                return (false, result.Error, null);
            }
        }

        public async Task<(bool Succeeded, string[] Error, IList<EmployeeTreeDto> Data)> GetSuperiorListAsync()
        {
            try
            {
                var employees = await _context.Employees.Where(x => (x.DeptId == (int)Enum.Department.Programming || x.DeptId == (int)Enum.Department.Tech) && (x.RoleId != (int)Enum.Roles.Manager)&& x.IsActive == true).ToListAsync();
                IEnumerable<Phase> phase;

                var project = await GetCurrentPhaseLists();
                phase = project.phase;
                var superiorList = employees
        .Where(e => e.SuperiorId != null && e.IsActive)
        .Select(e => new EmployeeTreeDto
        {
            EmpId = e.EmpId,
            EmployeeName = e.EmployeeName,
            SuperiorId = e.SuperiorId,
            IsActive = e.IsActive,
            SubordinateWorkCount = new List<int>()
        })
        .ToList();
                int? supervisorId = 0;
                List<int> intList = new List<int>();
                foreach (var employee in superiorList)
                {
                    var superior = employees.FirstOrDefault(e => e.EmpId == employee.SuperiorId);
                    if (superior != null)
                    {

                        if (supervisorId != employee.SuperiorId)
                        {
                            int Count = phase
          .Count(phase => ((phase.TechExpert == superior.EmpId && phase.TechStatus == false) ||
                          (phase.TechExpert1 == superior.EmpId && phase.TechStatus1 == false) ||
                          (phase.TechExpert2 == superior.EmpId && phase.TechStatus2 == false) ||
                          (phase.TechExpert3 == superior.EmpId && phase.TechStatus3 == false) ||
                          (phase.Programmer == superior.EmpId && phase.ProgrammerStatus == false) ||
                          (phase.Programmer1 == superior.EmpId && phase.ProgrammerStatus1 == false)) && phase.Status == 2);

                            employee.SuperiorWorkCount = Count;
                        }
                        employee.SuperiorName = superior.EmployeeName;


                        var subordinates = employees
                            .Where(e => e.SuperiorId == superior.EmpId)
                            .Select(e => new { Name = e.EmployeeName, Id = e.EmpId })
                            .ToList();


                        foreach (var subordinate in subordinates)
                        {
                            if (intList.Contains(subordinate.Id))
                            {
                                continue;
                            }
                            else
                            {
                                int subordinateWorkCount = phase
             .Count(phase => ((phase.TechExpert == subordinate.Id && phase.TechStatus == false) ||
                             (phase.TechExpert1 == subordinate.Id && phase.TechStatus1 == false) ||
                             (phase.TechExpert2 == subordinate.Id && phase.TechStatus2 == false) ||
                             (phase.TechExpert3 == subordinate.Id && phase.TechStatus3 == false) ||
                             (phase.Programmer == subordinate.Id && phase.ProgrammerStatus == false) ||
                             (phase.Programmer1 == subordinate.Id && phase.ProgrammerStatus1 == false)) && phase.Status == 2);
                                employee.SubordinateWorkCount.Add(subordinateWorkCount);
                                intList.Add(subordinate.Id);
                            }
                        }
                        employee.SubordinateNames = subordinates.Select(s => s.Name).ToList();
                        employee.SubordinateIds = subordinates.Select(s => s.Id).ToList();
                        supervisorId = employee.SuperiorId;
                    }

                }
                return (true, new string[] { }, superiorList);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Error, IEnumerable<Phase> phase)> GetCurrentPhaseLists()
        {
            try
            {
                var projects = await _context.Projects
                    .Include(x => x.Phase).ThenInclude(x => x.Employees)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees1)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees2)
                    .Include(x => x.Phase).ThenInclude(x => x.WorkStatus)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees3)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees4)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees5)
                    .Include(x => x.Clients).ThenInclude(x => x.BDAEmployee)
                    .Include(x => x.Clients).ThenInclude(x => x.TechEmployee)
                    .ToListAsync();

                var phases = projects.Where(x => x.Phase.Count() > 0).Select(x => x.Phase.OrderByDescending(x => x.ProjectId).LastOrDefault());


                return (true, new string[0], phases);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<IList<ManagerApprovalDto>> ProductionManagerApprovalAsync()
        {
            var phaseList = new List<ManagerApprovalDto>();
            try
            {
                var query = _context.Projects.Include(x => x.Phase)
                    .Include(x => x.Clients).ToList();
                var phase = query.Select(x => x.Phase.LastOrDefault()).Where(x => x.Status == (int)Enum.WorkStatus.Assigned &&
                ((x.TechTL.HasValue && x.PgmTL.HasValue && x.TechTLStatus && x.PgmTLStatus) ||
                (!x.TechTL.HasValue && x.PgmTL.HasValue && !x.TechTLStatus && x.PgmTLStatus) ||
                (x.TechTL.HasValue && !x.PgmTL.HasValue && x.TechTLStatus && !x.PgmTLStatus))
                ).OrderBy(dto => dto.DeadLine);
                foreach (var item in phase)
                {
                    if (item != null
                        && item.DeadLineCount > -9999999 && DateTime.Now > item.AssignedDate.Value.AddDays(item.DeadLineCount.Value))
                    {
                        var obj = new ManagerApprovalDto()
                        {
                            ClientName = item.Projects.Clients.ClientName,
                            ProjectId = item.Projects.ProjectId,
                            EnquiryId = item.Projects.Clients.EnquiryId,
                            PhaseName = item.PhaseName,
                            IsTechEnabled = item.IsTechNeeded,
                            IsPgmEnabled = item.IsProgrammerNeeded,
                            DeadLine = item.DeadLine,
                            ProjectRef = item.Projects.ProjectRef,
                        };
                        phaseList.Add(obj);
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            return phaseList;
        }
    }
}
