﻿using AutoMapper;
using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Helpers;
using Enquiry.Blazor.Models;
using Enquiry.Blazor.Services.Interface;
using Microsoft.EntityFrameworkCore;



namespace Enquiry.Blazor.Services;

public class Employee : IEmployee
{
    readonly ApplicationDbContext _context;
    readonly IMapper _mapper;
    private readonly ISession _session;
    IList<EmployeeTreeDto> EmployeeTree = new List<EmployeeTreeDto>();
    private readonly IWebHostEnvironment _environment;
    public Employee(ApplicationDbContext context, IMapper mapper, IHttpContextAccessor httpContextAccessor, IWebHostEnvironment environment) 
    { 
        _context = context; 
        _mapper = mapper;
        _session = httpContextAccessor.HttpContext.Session;
        _environment = environment;
    }

    public async Task<(bool Succeeded, string[] Error, IList<Roles> Data)> GetRolesAsync()
    {
        try
        {
            var data = await _context.Roles.Where(x => x.IsActive == true).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }

    public async Task<(bool Succeeded, string[] Error, IList<Department> Data)> GetDepartmentAsync()
    {
        try
        {
            var data = await _context.Department.Where(x => x.IsActive == true).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }

    public async Task<(bool Succeeded, string[] Error, IList<EmployeeListDto> Data)> GetEmployeeAsync()
    {
        try
        {
            var result = new List<EmployeeListDto>();

            var data = await _context.Employees.Where(x => x.IsActive == true)
                .Include(x => x.Roles).Include(x => x.Department).ToListAsync();

            result = data.Select(x => new EmployeeListDto()
            {
                EmpId = x.EmpId,
                IdentityNo = x.IdentityNo,
                EmployeeName = x.EmployeeName,
                ContactNo = x.ContactNo,
                IsActive = x.IsActive,
                EmailId = x.EmailId,
                Address = x.Address,
                RoleName = x.Roles.RoleName,
                DeptName = x.Department.DeptName,
                SuperiorId=x.SuperiorId,
                IsPasswordChanges= x.IsPasswordChanged,
                MemberId = x.MemberId,
                SuperiorName = _context.Employees
                    .Where(e => e.EmpId == x.SuperiorId && e.IsActive)
                    .Select(e => e.EmployeeName)
                    .FirstOrDefault()
            }).OrderByDescending(x=>x.EmpId).ToList();

            return (true, new string[] { }, result);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }

    public async Task<(bool Succeeded, string[] Error, Employees Data)> GetEmployeeDetailAsync(int empId)
    {
        try
        {

            var data = await _context.Employees.Where(x => x.IsActive == true && x.EmpId == empId)
                .Include(x => x.Roles).Include(x => x.Department).FirstOrDefaultAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error, IList<EmployeeListDto> Data)> GetInactiveEmployeeAsync()
    {
        try
        {
            var result = new List<EmployeeListDto>();

            var data = await _context.Employees.Where(x => x.IsActive == false)
                .Include(x => x.Roles).Include(x => x.Department).ToListAsync();

            result = data.Select(x => new EmployeeListDto()
            {
                EmpId = x.EmpId,
                IdentityNo = x.IdentityNo,
                EmployeeName = x.EmployeeName,
                ContactNo = x.ContactNo,
                EmailId = x.EmailId,
                Address = x.Address,
                IsActive = x.IsActive,
                RoleName = x.Roles.RoleName,
                DeptName = x.Department.DeptName,
                SuperiorId = x.SuperiorId,
                SuperiorName = _context.Employees
                    .Where(e => e.EmpId == x.SuperiorId && e.IsActive)
                    .Select(e => e.EmployeeName)
                    .FirstOrDefault()
            }).OrderByDescending(x => x.EmpId).ToList();

            return (true, new string[] { }, result);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }

    public async Task<(bool Succeeded, string[] Error)> CreateEmployeeAsync(CreateEmployeeDto dto)
    {
        try
        {
            string photoName = string.Empty;

            if (dto.EmployeePhotos == null || dto.EmployeePhotos.Length == 0)
            {
                string imagePath = Path.Combine(_environment.WebRootPath, "images", "Profile.png");
                byte[] img = await StreamCompression.GetDefaultPhotoBytesAsync(imagePath);
                string uploadPath = Path.Combine(_environment.WebRootPath, "images", "employees");
                photoName = await StreamCompression.UploadImageToFolder(img, string.Empty, uploadPath);
            }
            else
            {
                string uploadPath = Path.Combine(_environment.WebRootPath, "images", "employees");
                photoName = await StreamCompression.UploadImageToFolder(dto.EmployeePhotos, string.Empty, uploadPath);
            }
            var map = _mapper.Map<Employees>(dto);
            map.SuperiorId = dto.Superior;
            map.EmployeePhotoUrl = photoName;
            map.IsEnquiry = dto.IsEnquiry;
            await _context.AddAsync(map);
            int result = await _context.SaveChangesAsync().ConfigureAwait(false);
            if (result > 0)
            {
                var id = map.EmpId.ToString().PadLeft(4, '0');
                map.IdentityNo = $"KF" + id;
                _context.Update(map);
                await _context.SaveChangesAsync().ConfigureAwait(false);
            }
            return (true, new string[] { "Employee successfully created" });
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message });
        }

    }

    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetBDAAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && x.DeptId == 1).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }

    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetTechExpertAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && x.DeptId == 2).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }

    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetProgrammerAsync()
    {
        try
        {
            var data = new List<Employees>();
            if (_session.GetString("Role") == Enum.Roles.Manager.ToString())
            {
                data = await _context.Employees.Where(x => x.IsActive == true && x.DeptId == 3 ).ToListAsync();
            }
            else
            {
                data = await _context.Employees.Where(x => x.IsActive == true 
                && x.DeptId == 3 && x.SuperiorId == _session.GetInt32("CurrentUserId")).ToListAsync();
            }
            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetTechExpertExecutiveAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && x.DeptId == 2 && x.RoleId == 3).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }

    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetTechExpertTLAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && (x.DeptId == 2 && (x.RoleId ==2 || x.IsEnquiry == true))).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetProgramTLAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && (x.DeptId == 3 && (x.RoleId == 2 || x.IsEnquiry == true))).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetTechExpertEnquiryAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && ((x.DeptId == 2 && x.RoleId != 3) || (x.IsEnquiry == true && x.DeptId == 2))).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }

    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> ManagerReportViewAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetTechExpertManagerAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && x.DeptId == 2 && x.RoleId == 1).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetProgrammerExecutiveAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && x.DeptId == 3 && x.RoleId == 3).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetProgrammerTLAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && x.DeptId == 3 && x.RoleId == 2).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetTechTLAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && x.DeptId == 2 && x.RoleId == 2).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetProgrammerManagerAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && x.DeptId == 3 && x.RoleId == 1).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetBDAExecutiveAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && x.DeptId == 1 && x.RoleId == 3).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }
    }
        public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetBDATeamLeaderAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && x.DeptId == 1 && x.RoleId == 2).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetBDAManagerAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && x.DeptId == 1 && x.RoleId == 1).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetPublicationExecutiveAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && x.DeptId == 4 && x.RoleId == 3).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetPublicationTLAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && x.DeptId == 4 && x.RoleId == 2).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetPublicationManagerAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && x.DeptId == 4 && x.RoleId == 1).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetManagerAsync()
    {
        try
        {
            var data = await _context.Employees.Where(x => x.IsActive == true && (x.DeptId == 1 || x.DeptId == 2|| x.DeptId == 3|| x.DeptId == 4) && x.RoleId <= 2).ToListAsync();

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }

    public async Task<(bool Succeeded, string[] Error, IList<EmployeeTreeDto> Data)> GetEmployeeSuperiorWiseTree()
    {
        try
        {
            var userId = Int32.Parse(_session.GetInt32("CurrentUserId").ToString());
            var data = await _context.Employees
                .Where(x => x.IsActive == true && x.SuperiorId == userId).ToListAsync();
            var map = _mapper.Map<List<EmployeeTreeDto>>(data);
            while (map.Any(z=>z.Checked == false))
            {
                var Employee = new List<EmployeeTreeDto>();
                foreach (var employee in map)
                {
                    if (!employee.Checked)
                    {
                        var res = CheckSuperiorExists(employee);
                        employee.Checked = true;
                        Employee.AddRange(await res);
                    }
                }
                map.AddRange(Employee);
            }
            return (true, new string[] { }, map);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }

    private async Task<List<EmployeeTreeDto>> CheckSuperiorExists(EmployeeTreeDto data)
    {
        var Employee = new List<EmployeeTreeDto>();
        while (!data.Checked)
        {
            var empExists = await _context.Employees
                .Where(x => x.IsActive == true && x.SuperiorId == data.EmpId).ToListAsync();
            if (empExists != null)
            {
                var map = _mapper.Map<List<EmployeeTreeDto>>(empExists);
                Employee.AddRange(map);
            }
        }
        return Employee;
    }

    public async Task<(bool Succeeded, string[] Error, IList<OrganizationTreeDto> Data)> GetOrganizationChartAsync()
    {
        try
        {
            var employees = await _context.Employees.Where(x => x.IsActive == true).OrderBy(x => x.IdentityNo).ToListAsync();
            var users = employees.Select(x=> new OrganizationTreeDto()
            {
                Id = x.IdentityNo,
                Name = x.EmployeeName,
                Parent = (string)null,
                SuperiorId = x.SuperiorId
            });

            var Employee = new List<OrganizationTreeDto>();

            foreach (var user in users)
            {
                if (!user.Checked)
                {
                    if (user.SuperiorId != null && user.SuperiorId > 0)
                    {
                        var superiorEmployee = employees.FirstOrDefault(x => x.EmpId == user.SuperiorId);
                        if (superiorEmployee != null)
                        {
                            var emp = new OrganizationTreeDto()
                            {
                                Id = user.Id,
                                Name = user.Name,
                                Parent = superiorEmployee.IdentityNo,
                                Checked = true
                            };
                            Employee.Add(emp);
                        }
                    }
                    else
                    {
                        user.Checked = true;
                        Employee.Add(user);
                    }
                }
            }
            return (true, new string[] { }, Employee);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error, EditEmployeeDto employee)> EditEmployeeAsync(int EmpId)
    {
        try
        {
            var result = await _context.Employees.FindAsync(EmpId);
            var map = _mapper.Map<EditEmployeeDto>(result);
            if (!string.IsNullOrEmpty(result.EmployeePhotoUrl))
            {
                string url = Path.Combine(_environment.WebRootPath, "images", "employees", result.EmployeePhotoUrl);
                if (System.IO.File.Exists(url))
                {
                    map.EmployeePhotos = await StreamCompression.FindImageAndConvertToBase64String(url);
                }
                else
                {
                    map.EmployeePhotos = null;
                }
            }
            return (true, new string[] { }, map);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error)> UpdateEmployeeAsync(EditEmployeeDto edit)
    {
        try
        {
            var employee = await _context.Employees.FindAsync(edit.EmpId);
            employee.EmployeeName = edit.EmployeeName;
            employee.Designation = edit.Designation;
            employee.Address = edit.Address;
            employee.DOJ = edit.DOJ;
            employee.ContactNo = edit.ContactNo;
            employee.EmailId = edit.EmailId;
            employee.DOB = edit.DOB;
            employee.IsEnquiry = edit.IsEnquiry;

            if (edit.EmployeeImageUpload == null && (edit.EmployeePhotos == null || edit.EmployeePhotos == ""))
            {
                string imagePath = Path.Combine(_environment.WebRootPath, "images", "Profile.png");
                byte[] img = await StreamCompression.GetDefaultPhotoBytesAsync(imagePath);
                string uploadPath = Path.Combine(_environment.WebRootPath, "images", "employees");
                employee.EmployeePhotoUrl = await StreamCompression.UploadImageToFolder(img, employee.EmployeePhotoUrl, uploadPath);
            }
            else if (edit.EmployeeImageUpload != null && edit.EmployeeImageUpload.Length > 0)
            {
                string uploadPath = Path.Combine(_environment.WebRootPath, "images", "employees");
                employee.EmployeePhotoUrl = await StreamCompression.UploadImageToFolder(edit.EmployeeImageUpload, employee.EmployeePhotoUrl, uploadPath);
            }
            _context.Update(employee);
            await _context.SaveChangesAsync();

            return (true, new string[] { "Employee Details updated successfully" });
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message });
        }
    }
    public async Task<(bool Succeeded, string[] Error)> ResetEmployeePasswordAsync(int empId)
    {
        try
        {
            var contactNo = await _context.Employees
                                          .Where(x => x.EmpId == empId)
                                          .Select(y => y.ContactNo)
                                          .FirstOrDefaultAsync();

            var employee = await _context.Employees.FindAsync(empId);
            if (employee != null)
            {
                employee.Password = contactNo;
                employee.IsPasswordChanged = false;

                _context.Update(employee);
                await _context.SaveChangesAsync();

                return (true, new string[] { "Employee details updated successfully" });
            }
            else
            {
                return (false, new string[] { "Employee not found" });
            }
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message });
        }
    }

    public async Task<(bool Succeeded, string[] Error, IList<FeedbackDto> feedback)> GetEmployeeFeedbackAsync(int EmpId)
    {
        try
        {
            var result = new List<FeedbackDto>();

            var data = await _context.Feedback.Where(x => x.EmployeeId == EmpId).ToListAsync();

            result = data.Select(x => new FeedbackDto()
            {
                EmployeeId = x.EmployeeId,
                Scenario = x.Scenario,
                Feedbacks = x.Feedbacks,
            }).ToList();

            return (true, new string[] { }, result);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error)> CreateFeedbackFormAsync(FeedbackDto feedbackDto)
    {
        try
        {
            var feedback = _mapper.Map<Feedback>(feedbackDto);
            _context.Feedback.Add(feedback);
            await _context.SaveChangesAsync();

            return (true, null);
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message });
        }

    }
    public async Task<(bool Succeeded, string[] Error, IList<FeedbackDto> feedbackdetail)> GetFeedbackDetailsAsync()
    {
        try
        {
            //var user = _session.GetString("CurrentUserName");
            //var userId = Int32.Parse(_session.GetInt32("CurrentUserId").ToString());
            var feedbackDetails = await _context.Feedback
           .Include(x => x.Employees).ToListAsync();

            var details = feedbackDetails.Select(x => new FeedbackDto
            {
                FeedbackId = x.FeedbackId,
                EmployeeId = x.EmployeeId,
                EmployeeName = x.Employees.EmployeeName,
                Scenario = x.Scenario,
                EmpFeedback = x.EmpFeedback,
                Feedbacks = x.Feedbacks,
                CreatedOn= x.CreatedDate,
            }).OrderBy(x => x.EmployeeName)
           .ToList();
            //if (user != "KF0003")
            //{
            //    details = details.Where(x => x.EmployeeId == userId).ToList();
            //}
            return (true, null, details);
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error)> UpdateFeedbackFormAsync(int feedbackId, int employeeId, string empFeedback)
    {
        try
        {
                var updatefeedback = await _context.Feedback.FindAsync(feedbackId);

                if (updatefeedback != null)
                {
                    updatefeedback.EmpFeedback = empFeedback;
                    _context.Feedback.Update(updatefeedback);
                    _context.SaveChanges();

                }
            return (true, new string[] { "Feedback Updated Successfully." });
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message });
        }
    }

    public async Task<(bool Succeeded, string[] Error, IList<Employees> birthday)> GetEmployeeBirthdayAsync()
    {
        try
        {
            var today = DateTime.Today;
            var week = today.AddDays(7);

            var query = @"
                        SELECT *
                        FROM Employees
                        WHERE IsActive = 1
                        AND (
                            (MONTH(DOB) = MONTH(CURDATE()) AND DAY(DOB) >= DAY(CURDATE()))
                            OR 
                            (MONTH(DOB) = MONTH(DATE_ADD(CURDATE(), INTERVAL 7 DAY)) AND DAY(DOB) <= DAY(DATE_ADD(CURDATE(), INTERVAL 7 DAY)))
                            OR
                            (MONTH(CURDATE()) = 12 AND MONTH(DATE_ADD(CURDATE(), INTERVAL 7 DAY)) = 1 AND MONTH(DOB) = 1 AND DAY(DOB) <= DAY(DATE_ADD(CURDATE(), INTERVAL 7 DAY)))
                        )
                        AND (
                            (DATE(CONCAT(YEAR(CURDATE()), '-', MONTH(DOB), '-', DAY(DOB))) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY))
                            OR
                            (DATE(CONCAT(YEAR(CURDATE()) + 1, '-', MONTH(DOB), '-', DAY(DOB))) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY))
                        );
                    ";

            var birthday = await _context.Employees.FromSqlRaw(query).ToListAsync();
            if (birthday.Count() > 0)
            {
                foreach (var item in birthday)
                {
                    if (!string.IsNullOrEmpty(item.BirthdayPhotoUrl))
                    {
                        string url = Path.Combine(_environment.WebRootPath, "images", "birthday", item.BirthdayPhotoUrl);
                        if (System.IO.File.Exists(url))
                        {
                            item.BirthdayPhotoUrl = await StreamCompression.FindImageAndConvertToBase64String(url);
                        }
                        else
                        {
                            item.BirthdayPhotoUrl = null;
                        }
                    }
                }
            }

            return (true, null, birthday);
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message }, null);
        }
    }

    public async Task<(bool Succeeded, string[] Error, IList<Employees> anniversary)> GetEmployeeAnniversaryAsync()
    {
        try
        {
            var today = DateTime.Today;
            var lastWeek = today.AddDays(7);

            var query = @"
                        SELECT *
                        FROM Employees
                        WHERE IsActive = 1
                        AND (
                            (MONTH(DOJ) = MONTH(CURDATE()) AND DAY(DOJ) >= DAY(CURDATE()))
                            OR 
                            (MONTH(DOJ) = MONTH(DATE_ADD(CURDATE(), INTERVAL 7 DAY)) AND DAY(DOJ) <= DAY(DATE_ADD(CURDATE(), INTERVAL 7 DAY)))
                            OR
                            (MONTH(CURDATE()) = 12 AND MONTH(DATE_ADD(CURDATE(), INTERVAL 7 DAY)) = 1 AND MONTH(DOJ) = 1 AND DAY(DOJ) <= DAY(DATE_ADD(CURDATE(), INTERVAL 7 DAY)))
                        )
                        AND (
                            (DATE(CONCAT(YEAR(CURDATE()), '-', MONTH(DOJ), '-', DAY(DOJ))) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY))
                            OR
                            (DATE(CONCAT(YEAR(CURDATE()) + 1, '-', MONTH(DOJ), '-', DAY(DOJ))) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY))
                        );
                    ";

            var anniversary = await _context.Employees.FromSqlRaw(query).ToListAsync();
            if (anniversary.Count() > 0)
            {
                foreach (var item in anniversary)
                {
                    if (!string.IsNullOrEmpty(item.AnniversaryPhotoUrl))
                    {
                        string url = Path.Combine(_environment.WebRootPath, "images", "anniversary", item.AnniversaryPhotoUrl);
                        if (System.IO.File.Exists(url))
                        {
                            item.AnniversaryPhotoUrl = await StreamCompression.FindImageAndConvertToBase64String(url);
                        }
                        else
                        {
                            item.AnniversaryPhotoUrl = null;
                        }
                    }
                }
            }

            return (true, null, anniversary);
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message }, null);
        }
    }

    public async Task<(bool Succeeded, string[] Error)> UpdateEmployeeAnniversaryAsync(IFormFile file, int empId)
    {
        try
        {
            var uploads = Path.Combine(_environment.WebRootPath, "images", "anniversary");
            if (!Directory.Exists(uploads))
                Directory.CreateDirectory(uploads);

            var filePath = Path.Combine(uploads, file.FileName);

            var result = await _context.Employees.FindAsync(empId);

            if (result != null)
            {
                if (!string.IsNullOrEmpty(result.AnniversaryPhotoUrl))
                {
                    string url = Path.Combine(_environment.WebRootPath, "images", "anniversary", result.AnniversaryPhotoUrl);
                    if (System.IO.File.Exists(url))
                    {
                        System.IO.File.Delete(url);
                    }
                }
                result.AnniversaryPhotoUrl = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
                _context.Employees.Update(result);
                var data = await _context.SaveChangesAsync();
                if(data > 0)
                {
                    await StreamCompression.UploadImageToFolder(file, result.AnniversaryPhotoUrl, uploads);
                }

            }
            return (true, new string[] { "Image uploaded Successfully." });
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message });
        }
    }

    public async Task<(bool Succeeded, string[] Error)> UploadEmployeeBirthdayImageAsync(IFormFile file, int empId)
    {
        try
        {
            var uploads = Path.Combine(_environment.WebRootPath, "images", "birthday");
            if (!Directory.Exists(uploads))
                Directory.CreateDirectory(uploads);

            var filePath = Path.Combine(uploads, file.FileName);

            var result = await _context.Employees.FindAsync(empId);

            if (result != null)
            {
                if (!string.IsNullOrEmpty(result.BirthdayPhotoUrl))
                {
                    string url = Path.Combine(_environment.WebRootPath, "images", "birthday", result.BirthdayPhotoUrl);
                    if (System.IO.File.Exists(url))
                    {
                        System.IO.File.Delete(url);
                    }
                }
                result.BirthdayPhotoUrl = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
                _context.Employees.Update(result);
                var data = await _context.SaveChangesAsync();
                if (data > 0)
                {
                    await StreamCompression.UploadImageToFolder(file, result.BirthdayPhotoUrl, uploads);
                }

            }
            return (true, new string[] { "Image uploaded Successfully." });
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message });
        }
    }

    public async Task<(bool Succeeded, string[] Error, EmployeeSalaryInfo salary)> CalculateSalaryAsync(int totalAmount)
    {
        try
        {
            int basicPercentage = 75;
            int hraPercentage = 25;
            int employerPFPercentage = 13;
            int employeePFPercentage = 12;
            double employerESIPercentage = 3.25;
            double employeeESIPercentage = 0.75;

            var cal = new EmployeeSalaryInfo();
            cal.TotalAmount = totalAmount;
            cal.BasicSalary = totalAmount * basicPercentage / 100;
            cal.HRA = totalAmount * hraPercentage / 100;

            if (cal.BasicSalary > 15000)
            {
                cal.EmployerPF = 15000 * employerPFPercentage / 100;
                cal.EmployeePF = 15000 * employeePFPercentage / 100;
                cal.TotalPF = cal.EmployerPF + cal.EmployeePF;
            }
            else
            {
                cal.EmployerPF = cal.BasicSalary * employerPFPercentage / 100;
                cal.EmployeePF = cal.BasicSalary * employeePFPercentage / 100;
                cal.TotalPF = cal.EmployerPF + cal.EmployeePF;
            }

            if (cal.TotalAmount < 21000)
            {
                cal.EmployerEsi = cal.TotalAmount * employerESIPercentage / 100;
                cal.EmployeeEsi = cal.TotalAmount * employeeESIPercentage / 100;
                cal.TotalEsi = cal.EmployerEsi + cal.EmployeeEsi;
            }
            cal.TakeHome = (cal.TotalAmount - (cal.EmployeePF + cal.EmployeeEsi));
            cal.GrossSalary = (cal.TotalAmount + (cal.EmployeePF + cal.EmployeeEsi));
            cal.CTC = (cal.GrossSalary + (cal.EmployerPF + cal.EmployerEsi));

            return (true, null, cal);
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message }, null);
        }
    }

    public async Task<(bool Succeeded, string[] Error, IList<Employees> employees)> GetPlagiarismEmployeeAsync()
    {
        try
        {
            var emp = await _context.Employees.Where(x=>x.IsPlagiarismChecker == true && x.IsActive == true).OrderBy(x=>x.PlagiarismUpdatedDate).ToListAsync();
            return (true, new string[] { }, emp);
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message }, null);
        }
    }

    public async Task<(bool Succeeded, string[] Error, IList<Employees> employees)> GetNoPlagiarismEmployeeAsync()
    {
        try
        {
            var emp = await _context.Employees.Where(x => x.IsPlagiarismChecker == false && x.IsActive == true).ToListAsync();
            return (true, new string[] { }, emp);
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message }, null);
        }
    }

    public async Task<(bool Succeeded, string[] Error, Employees employees)> GetPlagiarismEnabledForEmployeeAsync(int userId)
    {
        try
        {
            var emp = await _context.Employees.FirstOrDefaultAsync(x => x.IsPlagiarismChecker == true && x.IsActive == true && x.EmpId == userId);
            return (true, new string[] { }, emp);
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message }, null);
        }
    }

    public async Task<(bool Succeeded, string[] Error)> UpdatePlagiarismEmployeeAsync(int EmployeeId, bool IsPlagiarism)
    {
        try
        {
            var emp = await _context.Employees.FindAsync(EmployeeId);
            if(emp != null)
            {
                emp.IsPlagiarismChecker = IsPlagiarism;
                emp.PlagiarismUpdatedDate = DateTime.Now;
                _context.Update(emp);
                await _context.SaveChangesAsync();
            }
            return (true, new string[] { "Successfully updated"});
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message });
        }
    }
    public async Task<(bool Succeeded, string[] Error, IList<Employees> employees)> GetEmailEmployeeAsync()
    {
        try
        {
            var emp = await _context.Employees.Where(x => x.IsEmailChecker == true && x.IsActive == true).OrderBy(x => x.EmailUpdatedDate).ToListAsync();
            return (true, new string[] { }, emp);
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message }, null);
        }
    }

    public async Task<(bool Succeeded, string[] Error, IList<Employees> employees)> GetNoEmailEmployeeAsync()
    {
        try
        {
            var emp = await _context.Employees.Where(x => x.IsEmailChecker == false && x.IsActive == true).ToListAsync();
            return (true, new string[] { }, emp);
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message }, null);
        }
    }
    public async Task<(bool Succeeded, string[] Error)> UpdateEmailEmployeeAsync(int EmployeeId, bool IsEmail)
    {
        try
        {
            var emp = await _context.Employees.FindAsync(EmployeeId);
            if (emp != null)
            {
                emp.IsEmailChecker = IsEmail;
                emp.EmailUpdatedDate = DateTime.Now;
                _context.Update(emp);
                await _context.SaveChangesAsync();
            }
            return (true, new string[] { "Successfully updated" });
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message });
        }
    }
    public async Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetPublicationExecutiveWithProjectAssignedAsync()
    {
        try
        {
            var data = await _context.Employees
            .Where(x => x.IsActive && x.DeptId == 4 && x.RoleId == 3)
            .Select(x => new Employees
            {
                EmpId = x.EmpId,
                EmployeeName = $"{x.EmployeeName} : " +
                    _context.Clients
                        .Include(y => y.Projects)
                        .ThenInclude(y => y.Phase)
                        .Where(z => z.PublicationEmpId == x.EmpId &&
                                    z.Projects.OrderBy(z=> z.ProjectId).LastOrDefault().Phase.OrderBy(z=> z.PhaseId).LastOrDefault().Status != (int)Enum.WorkStatus.Completed)
                        .Count()
            })
            .ToListAsync();
            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
}

