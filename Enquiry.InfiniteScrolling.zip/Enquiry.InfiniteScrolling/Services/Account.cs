﻿using Enquiry.Blazor.Models;
using Enquiry.Blazor.Services.Interface;

namespace Enquiry.Blazor.Services
{
    public class Account : IAccount
    {
        readonly ApplicationDbContext _context;

        public Account(ApplicationDbContext context) { _context = context; }
    }
}
