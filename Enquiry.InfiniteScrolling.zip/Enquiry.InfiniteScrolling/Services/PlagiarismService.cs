﻿using AutoMapper;
using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Models;
using Enquiry.Blazor.Services.Interface;
using Microsoft.EntityFrameworkCore;

namespace Enquiry.Blazor.Services
{
    public class PlagiarismService: IPlagiarismService
    {
        readonly ApplicationDbContext _context;
        readonly IMapper _mapper;
        private readonly ISession _session;

        public PlagiarismService(ApplicationDbContext context, IMapper mapper, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _mapper = mapper;
            _session = httpContextAccessor.HttpContext.Session;
        }

        public async Task<(bool Succeeded, string[] Error, bool value)> IsPlagiarismEnabledForEmployee()
        {
            try
            {
                int user = (int)_session.GetInt32("CurrentUserId");
                bool result = await _context.Plagiarism.AnyAsync(p => p.PlagiarismRecipients.Any(pr => pr.EmployeeId == user && pr.IsDownloaded && !pr.SentToSlack));
                return (true, new string[] { }, result);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, false);
            }

        }

        public async Task<(bool Succeeded, string[] Error, bool value)> CheckPlagiarismIsDownloaded(int plagiarismRecipientId)
        {
            try
            {
                var plagiarisms = await _context.PlagiarismRecipient.FirstOrDefaultAsync(x => x.PlagiarismRecipientId == plagiarismRecipientId);
                if (plagiarisms != null)
                {
                    var plag = await _context.Plagiarism.FirstOrDefaultAsync(x => x.PlagiarismId == plagiarisms.PlagiarismId);
                    if (plag.IsDownloaded)
                    {
                        return (true, new string[] {"File is downloaded by other employee"}, true);
                    }
                }
                return (true, new string[] { }, false);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, false);
            }

        }

        public async Task<(bool Succeeded, string[] Error)> UpdatePlagiarismIsDownloaded(int plagiarismRecipientId, int empId)
        {
            try
            {
                var plagiarisms = await _context.PlagiarismRecipient.FirstOrDefaultAsync(x => x.PlagiarismRecipientId == plagiarismRecipientId && x.EmployeeId == empId);
                if(plagiarisms != null)
                {
                    plagiarisms.IsDownloaded = true;
                    _context.Update(plagiarisms);
                    var result = await _context.SaveChangesAsync();
                    if(result > 0)
                    {
                        var plag = await _context.Plagiarism.Where(x => x.PlagiarismId == plagiarisms.PlagiarismId).FirstOrDefaultAsync();
                        if(plag != null)
                        {
                            plag.IsDownloaded = true;
                            _context.Update(plag);
                            await _context.SaveChangesAsync();
                        }
                    }
                }
                return (true, new string[] { });
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message });
            }

        }

        public async Task<(bool Succeeded, string[] Error, IList<PlagiarismListDto> files)> PlagiarismForEmployeeAsync()
        {
            try
            {
                int user = (int)_session.GetInt32("CurrentUserId");
                var result = await _context.PlagiarismRecipient.Include(x=>x.Plagiarism).Include(x => x.Employees)
                    .Include(x => x.Plagiarism).ThenInclude(x => x.Employees).ToListAsync();
                var files = result.Where(pr => pr.EmployeeId == user && pr.IsDownloaded && !pr.SentToSlack).Select(x => new PlagiarismListDto()
                {
                    PhaseId = x.Plagiarism.PhaseId,
                    EnquiryId = x.Plagiarism.EnquiryId,
                    PlagiarismId = x.Plagiarism.PlagiarismId,
                    PlagiarismRecipientId = x.PlagiarismRecipientId,
                    UploadedEmployeeMemberId = x.Plagiarism.Employees?.MemberId,
                    UploadedEmployeeName = x.Plagiarism.Employees?.EmployeeName,
                    DownloadedEmployeeName = x.Employees?.EmployeeName,
                    FileName = x.Plagiarism.UploadedFileName,
                    FilePath = x.Plagiarism.UploadedFilePath
                }).ToList();
                return (true, new string[] { }, files);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        public async Task<(bool Succeeded, string[] Error, Plagiarism plagiarism)> CreatePlagiarismFileAsync(string fileName, string filePath, int? PhaseId, int? EnquiryId)
        {
            try
            {
                var lastClass = await _context.Plagiarism.OrderByDescending(r => r.PlagiarismId).FirstOrDefaultAsync();
                string className = lastClass?.ClassName ?? "A0";
                char lastLetter = className[0];
                int lastNumber = int.Parse(className.Substring(1));
                int user = (int)_session.GetInt32("CurrentUserId");

                string newName;

                if (lastLetter == 'D' && lastNumber == 20)
                {
                    // If the last class name is "D10", restart from "A0"
                    newName = "A1";
                }
                else if (lastNumber < 20)
                {
                    // Increment the number if it's less than 10
                    newName = $"{lastLetter}{lastNumber + 1}";
                }
                else
                {
                    // Move to the next letter and reset the number to 1
                    char nextLetter = (char)(lastLetter + 1);
                    newName = $"{nextLetter}1";
                }

                var plagiarisms = new Plagiarism()
                {
                    UploadedEmpId = user,
                    UploadedFileName = fileName,
                    UploadedFilePath = filePath,
                    ClassName = newName,
                    PhaseId = PhaseId,
                    EnquiryId = EnquiryId,
                };

                await _context.AddAsync(plagiarisms);
                await _context.SaveChangesAsync();
                return (true, new string[] { }, plagiarisms);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }


        public async Task<(bool Succeeded, string[] Error, PlagiarismRecipient plagiarismRecipient)> CreatePlagiarismRecipientAsync(int plagiarismId, int empId)
        {
            try
            {
                int user = (int)_session.GetInt32("CurrentUserId");
                var rPlagiarisms = new PlagiarismRecipient()
                {
                    PlagiarismId = plagiarismId,
                    EmployeeId = empId
                };
                await _context.AddAsync(rPlagiarisms);
                await _context.SaveChangesAsync();
                return (true, new string[] { }, rPlagiarisms);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        public async Task<(bool Succeeded, string[] Error, PlagiarismRecipient plagiarismRecipient)> CreatePlagiarismRecipientForUploadEmployeeAsync(PlagiarismRecipient recp)
        {
            try
            {
                var rPlagiarisms = new PlagiarismRecipient();
                rPlagiarisms = recp;
                await _context.AddAsync(rPlagiarisms);
                await _context.SaveChangesAsync();
                return (true, new string[] { }, rPlagiarisms);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }
        public async Task<(bool Succeeded, string[] Error, PlagiarismPhaseDetailsDto PlagiarismPhaseDetailsDto)> GetPhaseDetailsAsync(int PhaseId)
        {
            try
            {
                var phaseDetails = _context.Phase
                                    .Where(x => x.PhaseId == PhaseId)
                                     .Include(x => x.Projects)
                                    .Select(x => new PlagiarismPhaseDetailsDto
                                    {
                                        PhaseId = x.PhaseId,
                                        PhaseName = x.PhaseName,
                                        ProjectRef = x.Projects.ProjectRef 
                                    })
                                    .FirstOrDefault();

                return (true, new string[] { }, phaseDetails);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }
        public async Task<(bool Succeeded, string[] Errors)> DeletePlagiarismAsync(int PlagiarismId)
        {
            try
            {
                var plagPath = _context.Plagiarism.Where(x => x.PlagiarismId == PlagiarismId)
                                                  .Select(x => x.UploadedFilePath)
                                                  .FirstOrDefault();
                var folderPath = Path.GetDirectoryName(plagPath);
                if (Directory.Exists(folderPath))
                {
                    Directory.Delete(folderPath, true);
                    if (Directory.Exists(folderPath))
                    {
                        return (false, new string[] { $"Plagiarism folder at path {folderPath} could not be deleted." });
                    }
                }
                else
                {
                    return (false, new string[] { "Plagiarism folder does not exist." });
                }

                return (true, new string[] { "Plagiarism folder deleted successfully." });
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message });
            }
        }

    }
}
