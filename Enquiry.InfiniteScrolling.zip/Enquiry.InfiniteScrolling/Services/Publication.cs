﻿using AutoMapper;
using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Extensions;
using Enquiry.Blazor.Models;
using Enquiry.Blazor.Services.Interface;
using Microsoft.EntityFrameworkCore;
using System.Threading;

namespace Enquiry.Blazor.Services
{
    public class Publication : IPublication
    {
        readonly ApplicationDbContext _context;
        readonly IMapper _mapper;
        private readonly ISession _session;

        public Publication(ApplicationDbContext context, IMapper mapper, IHttpContextAccessor httpContextAccessor)
        { _context = context; _mapper = mapper; _session = httpContextAccessor.HttpContext.Session; }

        public async Task<(bool Succeeded, string[] Error, IList<PublicationListDto> Publication)> GetPublicationListAsync(char chkValue)
        {
            try
            {
                var publications = await _context.Phase.Where(x => x.Status == (int)Enum.WorkStatus.Publication)
                    .Include(x => x.WorkStatus)
                    .Include(x => x.Projects).ThenInclude(x => x.Clients)
                    .Include(x => x.Projects).ThenInclude(x => x.Publication)
                    .Include(x => x.Projects).ThenInclude(x => x.Publication).ThenInclude(x => x.JournalStatus)
                    .Include(x => x.Projects).ThenInclude(x => x.Publication).ThenInclude(x => x.Employees).ToListAsync();


                if (chkValue.Equals('A'))
                {   // ALL
                    publications = publications.ToList();
                }
                else if (chkValue.Equals('B'))
                {
                    publications = publications
                       .Where(x => x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.ToApply)).ToList();
                }
                else if (chkValue.Equals('O'))
                {
                    publications = publications
                       .Where(x => x.Projects.Phase.Any(x => x.IsPublicationApproval == true)).ToList();
                }
                else if (chkValue.Equals('S'))
                {   // Submit/Rejected
                    publications = publications
                        .Where(x => (x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.Submitted || p.Status == (int)Enum.JournalStatus.Rejected) &&
                                    x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Major) == 0 &&
                                    x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Minor) == 0 &&
                                    x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Accepted) == 0 &&
                                    x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Published) == 0 &&
                                    x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Terminated) == 0 ||
                                   (x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Submitted) == 0 &&
                                    x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Rejected) == 0 &&
                                    x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Major) == 0 &&
                                    x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Minor) == 0 &&
                                    x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Accepted) == 0 &&
                                    x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Published) == 0 &&
                                    x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Terminated) == 0))
                                    && x.Projects.Phase.Any(x => x.IsPublicationApproval == false))
                        .ToList();
                }
                else if (chkValue.Equals('M'))
                {   // Major/Minor
                    publications = publications
                        .Where(x => (x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.Submitted) ||
                                     x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.Rejected)) &&
                                    (x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.Major) ||
                                     x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.Minor)) &&
                                     x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Accepted) == 0 &&
                                     x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Published) == 0 &&
                                     x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Terminated) == 0)
                        .ToList();

                }
                else if (chkValue.Equals('C'))
                {   // Accepted
                    publications = publications
                         .Where(x => (x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.Submitted) ||
                                      x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.Rejected) ||
                                      x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.Major) ||
                                      x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.Minor)) &&
                                      x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.Accepted) &&
                                      x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Published) == 0 &&
                                      x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Terminated) == 0)
                         .ToList();

                }
                else if (chkValue.Equals('P'))
                {  // Published
                    publications = publications
                         .Where(x =>
                             (x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.Submitted) ||
                              x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.Rejected) ||
                              x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.Major) ||
                              x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.Minor) ||
                              x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.Accepted)) &&
                              x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.Published &&
                              x.Projects.Publication.Count(p => p.Status == (int)Enum.JournalStatus.Terminated) == 0))
                         .ToList();
                }
                else if (chkValue.Equals('T'))
                {  // Terminated
                    publications = publications
                     .Where(x => x.Projects.Publication.Any(p => p.Status == (int)Enum.JournalStatus.Terminated))
                     .ToList();

                }

                var allPhases = await _context.Phase
                               .Where(p => publications.Select(fp => fp.ProjectId).Contains(p.ProjectId))
                               .Include(p => p.WorkStatus)
                               .ToListAsync();

                var lastPhases = allPhases
                            .GroupBy(p => p.ProjectId)
                            .Select(g => g.OrderByDescending(p => p.PhaseId).FirstOrDefault())
                            .Select(p => new
                            {
                                ProjectId = p.ProjectId,
                                WorkStatusName = p.WorkStatus.WorkStatusName
                            })
                            .ToList();

                var map = _mapper.Map<IList<PublicationListDto>>(publications).Select(dto =>
                            {
                                var lastPhase = lastPhases.FirstOrDefault(p => p.ProjectId == dto.ProjectId);
                                if (lastPhase != null)
                                {
                                    dto.WorkStatusName = lastPhase.WorkStatusName;
                                }
                                return dto;
                            })
                            .ToList();
                return (true, new string[] { }, map.GroupBy(x => x.ProjectId).Select(g => g.LastOrDefault())
                    .OrderBy(x => x.RemainderDate).ToList());
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        public async Task<(bool Succeeded, string[] Error, JournalPhaseFileDetailDto Data, bool PublicationApproval, int PhaseId)> GetJournalListAsync(int projectId)
        {
            try
            {
                var jrl = await _context.Publication.Where(x => x.ProjectId == projectId).ToListAsync();
                var map = _mapper.Map<IList<JournalDetailDto>>(jrl);
                var orderList = map.OrderBy(x => x.Status == (int)Enum.JournalStatus.MailAccount)
                    .OrderBy(x => x.Status == (int)Enum.JournalStatus.ToApply)
                    .OrderBy(x => x.Status == (int)Enum.JournalStatus.Published)
                    .OrderBy(x => x.Status == (int)Enum.JournalStatus.Accepted)
                    .OrderBy(x => x.Status == (int)Enum.JournalStatus.Minor)
                    .OrderBy(x => x.Status == (int)Enum.JournalStatus.Major)
                    .OrderBy(x => x.Status == (int)Enum.JournalStatus.Submitted)
                    .OrderBy(x => x.Status == (int)Enum.JournalStatus.ClientWithdraw)
                    .OrderBy(x => x.Status == (int)Enum.JournalStatus.Rejected).ToList();
                var project = await _context.Projects.Where(x => x.ProjectId == projectId).Include(x => x.Payments)
          .Include(x => x.Phase).ThenInclude(x => x.PhaseFiles).FirstOrDefaultAsync();

                var phaseFilesDto = project.Phase
                    .SelectMany(t => t.PhaseFiles.Select(x => new PhaseFilesDto
                    {
                        FileName = x.FileName,
                        FilePath = x.FilePath,
                        PhaseFileId = x.PhaseFileId,
                        PhaseId = x.PhaseId,
                        IsPublication = x.IsPublication,
                    })).ToList();
                var emailQuery = _context.Emails
                 .Where(x => x.IsPublication && x.ProjectId.Equals(projectId))
                 .Include(x => x.EmailAttachmentsFiles)
                 .Include(x => x.Clients).Include(x => x.Projects).AsQueryable();
                if ((_session.GetString("Dept") == Enum.Department.Tech.ToString() || _session.GetString("Dept") == Enum.Department.Programming.ToString()) && _session.GetString("Role") != Enum.Roles.Manager.ToString())
                {
                    emailQuery = emailQuery.Where(x => !x.Visibility && x.IsPublication);
                }
                emailQuery = emailQuery.Where(x => x.IsPublication);
                var emailDetails = await emailQuery.Select(x => new EmailDto
                {
                    EmailId = x.EmailId,
                    FromAddress = x.FromAddress,
                    ToAddress = x.ToAddress,
                    ClientName = x.IsSender ? x.ClientName : x.Projects.Clients.ClientName,
                    Subject = x.Subject,
                    Body = x.UpdatedMessage,
                    EnquiryId = x.EnquiryId,
                    ProjectId = x.ProjectId != null && !x.IsPublication ? x.ProjectId : null,
                    PublicationProjectId = x.ProjectId != null && x.IsPublication ? x.ProjectId : null,
                    ReceivedDate = x.ReceivedDate,
                    EmailAttachmentDto = x.EmailAttachmentsFiles.Where(x => x.IsSelected).Select(a => new EmailAttachmentDto
                    {
                        AttachmentFilePath = a.AttachmentFilePath,
                        AttachmentFileName = a.AttachmentFileName
                    }).ToList()
                }).OrderByDescending(x => x.ReceivedDate)
                    .ToListAsync();
                var PublicationDetails = _context.Projects.Include(x => x.Clients).ThenInclude(x => x.PublicationEmployee).Where(x => x.ProjectId == projectId).Select(x => new
                {
                    PublicationEmpName = x.Clients.PublicationEmpId.HasValue ? x.Clients.PublicationEmployee.EmployeeName : null,
                    PublicationEmpId = x.Clients.PublicationEmpId.HasValue ? x.Clients.PublicationEmpId : null,
                    EnquiryRef = x.Clients.EnquiryRef,
                    EnquiryId = x.Clients.EnquiryId,
                }).FirstOrDefault();
                var result = new JournalPhaseFileDetailDto
                {
                    PhaseFilesDto = phaseFilesDto,
                    JournalDetailDto = orderList,
                    EmailDto = emailDetails,
                    EnquiryRef = PublicationDetails.EnquiryRef,
                    PublicationEmpId = PublicationDetails.PublicationEmpId,
                    PublicationEmpName = PublicationDetails.PublicationEmpName,
                    EnquiryId = PublicationDetails.EnquiryId,
                };
                var publicationApproval = _context.Phase
                                        .Where(x => x.ProjectId == projectId && x.Status == (int)Enum.WorkStatus.Publication)
                                        .OrderBy(x => x.PhaseId)
                                        .Select(x => new { x.IsPublicationApproval, x.PhaseId }).LastOrDefault();

                return (true, new string[] { }, result, publicationApproval.IsPublicationApproval, publicationApproval.PhaseId);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null, false, 0);
            }

        }

        public async Task<(bool Succeeded, string[] Error, JournalDetailDto Data)> GetJournalAsync(int publicationid)
        {
            try
            {
                var jrl = await _context.Publication.Include(x => x.PublicationHistory)
                    .Include(x => x.PublicationHistory).ThenInclude(x => x.Employees)
                    .Include(x => x.PublicationHistory).ThenInclude(x => x.JournalStatus)
                    .Where(x => x.PublicationId == publicationid).FirstOrDefaultAsync();
                var map = _mapper.Map<JournalDetailDto>(jrl);
                foreach (var item in jrl.PublicationHistory)
                {
                    var val = new PublicationHistoryDto()
                    {
                        HistoryId = item.HistoryId,
                        EmployeeName = item.Employees.EmployeeName,
                        Status = item.JournalStatus.Name,
                        Comments = item.Comments,
                        CreatedDate = item.CreatedDate
                    };
                    map.PublicationHistoryDto.Add(val);
                }
                return (true, new string[] { }, map);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }
        public async Task<(bool Succeeded, string[] Error)> GetJournalHistoryAsync(JournalDetailDto journalHistory, int PublicationId)
        {
            try
            {
                var lastPublicationId = await _context.PublicationHistory
            .Where(ph => ph.PublicationId == PublicationId)
            .OrderBy(ph => ph.HistoryId)
            .LastOrDefaultAsync();

                var userId = _session.GetInt32("CurrentUserId") ?? 0;
                if (lastPublicationId == null || lastPublicationId.Status != journalHistory.Status)
                {
                    var newPublication = new PublicationHistory
                    {
                        EmpId = userId,
                        PublicationId = PublicationId,
                        Status = journalHistory.Status,
                        Comments = journalHistory.Reason
                    };
                    _context.PublicationHistory.Add(newPublication);
                    await _context.SaveChangesAsync();
                }


                return (true, new string[] { });
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message });
            }

        }


        public List<IGrouping<(DateTime? VerifiedDate, string JournelName), AllJournalDto>> GetAllJournalsAsync()
        {
            var list = _context.JournalList
                .Select(x => new AllJournalDto()
                {
                    JournalId = x.JournalId,
                    Link = x.Link,
                    JournalName = x.JournalName,
                    Publisher = x.Publisher,
                    Domain = x.Domain,
                    Index = x.Index,
                    Paid = x.Paid,
                    VerifiedDate = x.VerifiedDate > new DateTime(0001, 01, 01) ? x.VerifiedDate : null,
                })
                .AsEnumerable()
                .GroupBy(x => (x.VerifiedDate, x.JournalName))
                .OrderBy(ph => ph.Key.VerifiedDate)
                .ToList();

            return list;
        }

        public async Task<(bool Succeeded, string[] Error)> UpdateJournalAsync(OldJournalDto oldJournal, UpdatedJournalDto updatedJournal)
        {
            try
            {
                var journalExists = await _context.JournalList.Where(x => x.Publisher.ToLower().Trim() == oldJournal.Publisher.ToLower().Trim()
                && x.JournalName.ToLower().Trim() == oldJournal.JournalName.ToLower().Trim()).ToListAsync();
                var Publicationjournal = await _context.Publication.Where(x => x.Publisher.ToLower().Trim() == oldJournal.Publisher.ToLower().Trim()
                && x.JournelName.ToLower().Trim() == oldJournal.JournalName.ToLower().Trim()).ToListAsync();
                if (journalExists.Count() > 0)
                {
                    foreach (var journal in journalExists)
                    {
                        if (journal.Publisher != updatedJournal.Publisher)
                            journal.Publisher = updatedJournal.Publisher;

                        if (journal.JournalName != updatedJournal.JournalName)
                            journal.JournalName = updatedJournal.JournalName;

                        if (journal.Domain != updatedJournal.Domain)
                            journal.Domain = updatedJournal.Domain;

                        if (journal.Index != updatedJournal.Index)
                            journal.Index = updatedJournal.Index;

                        if (journal.Link != updatedJournal.Link)
                            journal.Link = updatedJournal.Link;

                        if (journal.Paid != updatedJournal.Paid)
                            journal.Paid = updatedJournal.Paid;

                        journal.VerifiedDate = DateTime.Now;
                        journal.VerifiedBy = _session.GetInt32("CurrentUserId") ?? 0;
                        _context.Update(journal);
                    }
                    await _context.SaveChangesAsync();
                }
                if (journalExists.Count() > 0)
                {
                    foreach (var publicationJournal in Publicationjournal)
                    {
                        if (publicationJournal.Publisher != updatedJournal.Publisher)
                            publicationJournal.Publisher = updatedJournal.Publisher;

                        if (publicationJournal.JournelName != updatedJournal.JournalName)
                            publicationJournal.JournelName = updatedJournal.JournalName;
                        if (publicationJournal.Link != updatedJournal.Link)
                            publicationJournal.Link = updatedJournal.Link;

                        _context.Update(publicationJournal);
                    }
                    await _context.SaveChangesAsync();
                }

                return (true, new string[] { });
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message });
            }

        }
        public async Task<(bool Succeeded, string[] Error, AllJournalDto journaldto)> CreateJournalAsync(AllJournalDto journaldto)
        {
            try
            {
                if (journaldto.JournalId == null)
                {
                    var journal = new JournalList
                    {
                        IsActive = true,
                        JournalName = journaldto.JournalName,
                        Publisher = journaldto.Publisher,
                        Link = journaldto.Link,
                        Index = journaldto.Index,
                        Paid = journaldto.Paid,
                        Domain = journaldto.Domain,
                        VerifiedDate = DateTime.Now,
                        VerifiedBy = _session.GetInt32("CurrentUserId") ?? 0
                    };

                    _context.JournalList.Add(journal);
                }
                else
                {
                    var journalExists = await _context.JournalList.FirstOrDefaultAsync(x => x.JournalId == journaldto.JournalId);

                    if (journalExists != null)
                    {
                        journalExists.JournalName = journaldto.JournalName;
                        journalExists.Publisher = journaldto.Publisher;
                        journalExists.Link = journaldto.Link;
                        journalExists.Index = journaldto.Index;
                        journalExists.Paid = journaldto.Paid;
                        journalExists.Domain = journaldto.Domain;
                        journalExists.VerifiedDate = DateTime.Now;
                        journalExists.VerifiedBy = _session.GetInt32("CurrentUserId") ?? 0;
                    }
                    else
                    {
                        // Handle the case where the journal with the given ID does not exist
                        return (false, new[] { "Journal not found" }, null);
                    }
                }

                await _context.SaveChangesAsync();

                return (true, null, journaldto);
            }
            catch (Exception ex)
            {
                // Handle any errors here
                return (false, new[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Error, IList<UpdatedJournalDto> journal)> GetJournalListAsync()
        {
            try
            {
                var journalList = await _context.JournalList.Select(journal => new UpdatedJournalDto
                {
                    JournalId = journal.JournalId,
                    Publisher = journal.Publisher,
                    JournalName = journal.JournalName
                }).ToListAsync();

                return (true, new string[] { }, journalList);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }
        public async Task<(bool Succeeded, string[] Error, OldJournalDto journal)> GetJournalDetailAsync(int JournalId)
        {
            try
            {
                var journalList = _context.JournalList.Select(journal => new OldJournalDto
                {
                    JournalId = journal.JournalId,
                    JournalName = journal.JournalName,
                    Link = journal.Link,
                    Index = journal.Index,
                    Publisher = journal.Publisher,
                    Domain = journal.Domain,
                    Paid = journal.Paid
                }).Where(journal => journal.JournalId == JournalId).FirstOrDefault();

                return (true, new string[] { }, journalList);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }
        public async Task<bool> DeleteJournalAsync(int PublicationId)
        {
            try
            {
                var publication = await _context.Publication
                    .FirstOrDefaultAsync(p => p.PublicationId == PublicationId);

                if (publication != null)
                {
                    _context.Publication.Remove(publication);
                    await _context.SaveChangesAsync();
                    return true;
                }
                else
                {

                    return false;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while deleting the Journal.", ex);
            }
        }
        public async Task<bool> DeleteJournalTopicAsync(int JournalId)
        {
            try
            {
                var DeleteJournal = await _context.JournalList.FindAsync(JournalId);
                if (DeleteJournal != null)
                {
                    _context.JournalList.Remove(DeleteJournal);
                    await _context.SaveChangesAsync();
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while deleting the Journal.", ex);
            }
        }
        public async Task<(bool Succeeded, string[] Error, List<GetJournalDetailsClient> client)> GetJournalDetailOfClientAsync(string JournalName)
        {
            try
            {
                var publications = _context.Projects
                  .Include(x => x.Publication)
                 .ThenInclude(p => p.Projects)
                 .ThenInclude(pr => pr.Clients)
                 .Include(p => p.Publication)
                 .ThenInclude(pub => pub.JournalStatus)
                 .Where(p => p.Publication.Any(pub => pub.JournelName == JournalName))
                 .Select(p => p.Publication
                     .Where(pub => pub.JournelName == JournalName)
                     .OrderBy(pub => pub.PublicationId)
                     .LastOrDefault())
                 .ToList();

                var clientDetails = publications
                    .Where(pub => pub != null)
                    .Select(pub => new GetJournalDetailsClient
                    {
                        ClientName = pub.Projects.Clients.ClientName,
                        ProjectRef = pub.Projects.ProjectRef,
                        Domain = pub.Projects.Clients.Domain,
                        Status = pub.JournalStatus.Name,
                        Reason = pub.Reason,
                    })
                    .ToList();

                return (true, new string[] { }, clientDetails);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }
        public async Task<(bool Succeeded, string[] Errors)> UpdateIsPublicationApprovalAsync(int phaseId)
        {
            try
            {
                var phase = await _context.Phase.FindAsync(phaseId);
                phase.IsPublicationApproval = false;
                _context.Phase.Update(phase);
                await _context.SaveChangesAsync();

                return (true, new string[] { "Files added successfully" });
            }
            catch (Exception ex)
            {
                return (false, new string[] { "An error occurred: " + ex.Message });
            }
        }

        public async Task<(bool Succeeded, string[] Errors, IList<PhaseForPublicationDto> phase)> GetPublicationPhaseListAsync()
        {
            try
            {
                var phaseList = await _context.PhaseStatus.Where(x => x.SpecialDeadline && x.IsActive).Select(x => new PhaseForPublicationDto()
                {
                    PhaseId = x.Id,
                    Name = x.PhaseName
                }).ToListAsync();

                return (true, Array.Empty<string>(), phaseList);
            }
            catch (Exception ex)
            {
                return (false, new[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Error)> UpdatePublicationEmpInClientAsync(AssignPublicationDto assignPub)
        {
            try
            {
                var client = await _context.Clients.FindAsync(assignPub.EnquiryId);
                client.PublicationEmpId = assignPub.PublicationEmpId;
                _context.Clients.Update(client);
                await _context.SaveChangesAsync();
                return (true, new string[] { });
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message });
            }
        }
    }
}


