﻿namespace Enquiry.Blazor.Services.Interface
{
    public interface ISlack
    {
        Task SendMessage(string text, string channel);
        Task SendMessageWithAttachment(string text, string channel, string title, string fileName, byte[] imageUrl, string extension);
    }
}
