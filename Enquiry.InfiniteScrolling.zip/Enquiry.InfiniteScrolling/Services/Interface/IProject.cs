﻿using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Enquiry.Blazor.Services.Interface
{
    public interface IProject
    {
        Task<(bool Succeeded, string[] Error, IList<ProjectListDto> Data)> GetPhaseAsync();
        Task<(bool Succeeded, string[] Error, Projects Project)> CreateProjectAsync(CreateProjectDto projectDto);
        Task<(bool Succeeded, string[] Error, Phase Phase)> CreatePhaseAsync(CreatePhaseDto phaseDto, int projectId);
        Task<(bool Succeeded, string[] Error, Payments Phase)> CreatePaymentAsync(CreatePayment payment, int projectId);
        Task<(bool Succeeded, string[] Error, Models.Publication Publication)> CreateJournalAsync(JournalDetailDto journal, int projectId, int? empId);
        Task<(bool Succeeded, string[] Error, Models.Publication Publication)> UpdateJournalAsync(JournalDetailDto journal, int projectId);
        Task<(bool Succeeded, string[] Error, RegisteredClientDetailDto Client)> GetRegisteredClientDetailAsync(int enquiryId);
        Task<(bool Succeeded, string[] Error, ProjectDetailDto Project)> GetProjectDetailAsync(int projectId);
        Task<(bool Succeeded, string[] Error, EditPhaseDto Phase)> GetPhaseAsync(int phaseId);
        Task<(bool Succeeded, string[] Error, Phase Phase)> GetPhaseForFileUploadAsync(int phaseId);
        Task<(bool Succeeded, string[] Error, Phase Phase)> UpdatePhaseAsync(EditPhaseDto phaseDto);
        Task<(bool Succeeded, string[] Error, Phase Phase)> UpdatePhaseOnHoldAsync(EditPhaseOnHoldDto phaseDto, int phaseId);
        Task<(bool Succeeded, string[] Error, Phase Phase)> CreatePhaseDemoAsync(int phaseId, PhaseDemoDto demo);
        Task<(bool Succeeded, string[] Error, EditPhaseOnHoldDto Phase)> EditProjectOnHoldFormAsync(int phaseId);
        Task<(bool Succeeded, string[] Error, PhaseDemoDto Demo)> GetPhaseDemoFormAsync(int phaseId);
        Task<(bool Succeeded, string[] Error, IList<PhaseDemoListDto> Demo)> GetPhaseDemoAsync(string status);
        Task<(bool Succeeded, string[] Error, Phase Phase)> UpdateProgressAsync(int progressId, int phaseId, int value);
        Task<(bool Succeeded, string[] Error, IList<ProjectListDto> Data)> GetGlobalSearchAsync(string searchString);
        Task<(bool Succeeded, string[] Error, Phase phase)> UpdatePhasePriorityAsync(PhasePriority priority);
        Task<(bool Succeeded, string[] Error, Phase phase)> EditPhaseFormPriorityAsync(PhasePriority priority);
        Task<(bool Succeeded, string[] Error, Phase Phase)> ReassignedPhaseAsync(string reassignedPhase, int projectId, DateTime deadline, DateTime AssignedDate, string reason);
        Task<(bool Succeeded, string[] Error, IList<PhaseStatusDto> Data)> GetPhaseStatusAsync();
        Task<(bool Succeeded, string[] Error, IList<PhaseStatusDto> Data)> GetPhaseDetailsAsync(string phaseId);
        Task<(bool Succeeded, string[] Error, PhaseStatusDto Phasestatus)> GetPhaseListAsync(int phaseId);
        Task<(bool Succeeded, string[] Error, PhaseStatus Phasestatus)> CreateNewPhaseAsync(PhaseStatusDto phaseStatusDto);
        Task<(bool Succeeded, string[] Error, PhaseStatus Phasestatus)> UpdatePhaseListAsync(int phaseId, PhaseStatusDto phaseStatusDto);
        Task<(bool Succeeded, string[] Error, IList<PhaseStatus> Data)> GetTechWorkTypeAsync();
        Task<(bool Succeeded, string[] Error, IList<PhaseStatus> Data)> GetProgrammersWorkTypeAsync();
        Task<(bool Succeeded, string[] Error, IList<PhaseStatusDto> Data)> GetPhaseStatusDropdownAsync();
        Task<(bool Succeeded, string[] Error, IList<(string EmployeeName, int EmpId, bool IsDisabled)> Data)> GetTechAssignDropDownAsync();
        Task<bool> DeleteAssignedWorkAsync(int phaseId, string techType, int techId, string remark);
        Task<(bool Succeeded, string[] Error)> PhaseExecutionAsync(EditPhaseDto phaseDto, int status);
        Task<(bool Succeeded, string[] Error)> UpdateFeedbackFormAsync(int phaseId, int userId, UpdatePhaseDemoListDto feedback);
        Task<(bool Succeeded, string[] Error)> CreateClientFeedbackByTLAsync(int PhaseId, int UserId, string Link, UpdatePhaseDemoListDto TLfeedback);
        Task<(bool Succeeded, string[] Errors, EditTotalPaymentDetailDto Payment)> EditPaymentDetailsAsync(int ProjectId);
        Task<(bool Succeeded, string[] Errors)> UpdatePaymentDetailsAsync(EditTotalPaymentDetailDto payment);
        Task<(bool Succeeded, string[] Error, IList<ProjectStatusDto> Data)> GetProjectStatusAsync();
        Task<(bool Succeeded, string[] Error, ProjectStatus Projectstatus)> CreateNewProjectAsync(ProjectStatusDto projectStatusDto);
        Task<(bool Succeeded, string[] Error, ProjectStatusDto Projectstatus)> GetProjectStatusListAsync(int projectStatusId);
        Task<(bool Succeeded, string[] Error, ProjectStatus projectStatus)> UpdateProjectStatusListAsync(ProjectStatusDto projectStatusDto);
        Task<bool> DeleteProjectStatusAsync(int projectStatusId);
        Task<(bool Succeeded, string[] Error, IList<ProjectStatusDto> Data)> GetProjectStatusDropdownAsync();
        Task<(bool Succeeded, string[] Errors, IList<SelectListItem> WorkTypes)> GetWorkTypesByProjectNameAsync(string projectName);
        Task<(bool Succeeded, string[] Errors, double payment)> GetPaymentProjectStatusAsync(int EnquiryId, string ProjectName, string WorkType);
        Task<(bool Succeeded, string[] Errors)> UpdatePaymentRemarkAsync(ApprovalDto approval);
        Task<(bool Succeeded, string[] Errors)> UpdateTLAsync(ChangeTlInActive changeTL);
        Task<(bool Succeeded, string[] Errors)> CreatePhaseFileAsync(PhaseFiles file);
        Task<(bool Succeeded, string[] Errors)> DeletePhaseFileAsync(int phaseFileId);
        Task<(bool Succeeded, string[] Errors, bool hasFile)> GetPhaseFileDetailsAsync(int projectId);
        Task<(bool Succeeded, string[] Error, IList<PhaseStatusDto> Data)> GetPhaseStatusDropdownDaysOnlyAsync();
        Task<(bool Succeeded, string[] Errors)> UpdatePhaseFileAsync(PhaseFiles file, int PhaseFileId);
        Task<(bool Succeeded, string[] Errors)> UpdateTLOrManagerPhaseFileAsync(PhaseFiles file, IList<int?> FileIds, string FolderName, bool IsPublication);
        Task<(bool Succeeded, string[] Errors, PlagiarismRecipient plag)> GetPlagiarismRecipientDetailsAsync(int plagiarismRecipientId);
        Task<(bool Succeeded, string[] Errors)> StoreFileIdInPlagiarismRecipientAsync(int plagiarismRecipientId, string fileId);

    }
}
