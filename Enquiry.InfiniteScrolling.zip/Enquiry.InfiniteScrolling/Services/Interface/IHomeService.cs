﻿using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Models;
using System.Threading.Tasks;
using static Enquiry.Blazor.Dtos.DashboardDto;

namespace Enquiry.Blazor.Services.Interface
{
    public interface IHomeService
    {
        Task<IList<DiscussionPendingDto>> EnquiryPendingDiscussionAsync();
        Task<IList<AssignedPhaseDto>> ProductionAssignedPhaseAsync();
        Task<IList<DueDateExceededDto>> ProductionDueDateExceededAsync();
        Task<IList<DueDateExceededDto>> ProductionDeadLineAsync();
        Task<JournalPendingDto> PublicationJournalPendingAsync();
        Task<AssignedPhaseDto> PublicationCountAsync();
        Task<IList<JournalSubmit>> JournalNotInFiveAsync();
        Task<IList<AssignedPhaseDto>> PublicationPendingAsync();
        Task<(bool Succeeded, string[] Error, IList<ProjectNew> Data)> GetProjectDetailsAsync(int employeeId);
        Task<(bool Succeeded, string[] Error, IList<EmployeeTreeDto> Data)> GetSuperiorListAsync();
        Task<IList<PublicationDeadLineDto>> PublicationDeadLineAsync();
        Task<(bool Succeeded, string[] Error, IEnumerable<Phase> phase)> GetCurrentPhaseLists();
        Task<IList<ManagerApprovalDto>> ProductionManagerApprovalAsync();
    }
}
