﻿using Enquiry.Blazor.Dtos;
using MimeKit;

namespace Enquiry.Blazor.Services.Interface
{
    public interface IEmail
    {
        Task<(bool Succeeded, string[] Errors)> CreateEmailDetailsAsync(MimeMessage message, uint uid);
        Task<(bool Succeeded, string[] Errors, IList<EmailDto> Emails, bool IsMemberId, string Designation)> GetEmailDetailsAsync(char chkValue);
        Task<(bool Succeeded, string[] Errors, IList<EnquiryDropdown> Enquiry, IList<ProjectDropdown> Project, IList<PublicationDropdown> Publication)> GetDropdownListAsync(string Email);
        Task<(bool Succeeded, string[] Errors)> UpdateEmailAsync(int? EnquiryId,int? ProjectId,bool IsRead, int EmailId,int? PublicationProjectId);
        Task<(bool Succeeded, string[] Errors, EmailDto Emails)> GetEmailFormAsync(int EmailId);
        Task<(bool Succeeded, string[] Errors)> UpdateAttachmentAsync(int AttachmentFileId, bool IsSelected);
        Task<(bool Succeeded, string[] Errors)> UpdateEmailMessageAsync(EmailDto email);
        Task<(bool Succeeded, string[] Errors)> UpdateDeletedEmailAsync(int EmailId);
        Task<(bool Succeeded, string[] Errors)> UpdateEmailCloseEmailFormAsync(int EmailId);
        Task<(bool Succeeded, string[] Errors)> UpdatePermanentDeletedEmailAsync(int EmailId);
    }
}
