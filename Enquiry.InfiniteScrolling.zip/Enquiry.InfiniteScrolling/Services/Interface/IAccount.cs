﻿namespace Enquiry.Blazor.Services.Interface
{
    public interface IAccount
    {
    }
}
