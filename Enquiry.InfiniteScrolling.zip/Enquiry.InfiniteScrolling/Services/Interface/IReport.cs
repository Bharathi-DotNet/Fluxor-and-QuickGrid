﻿using Enquiry.Blazor.Dtos;

namespace Enquiry.Blazor.Services.Interface
{
    public interface IReport
    {
        Task<(bool Succeeded, string[] Error, IList<EnquiryWisePaymentDto> Data)> GetEnquiryPaymentListAsync(int EmpId, DateTime startDate, DateTime endDate, bool regType);
        Task<(bool Succeeded, string[] Error, ScoreDto Data)> GetBDAScoreListAsync(DateTime startDate, DateTime endDate);
        Task<(bool Succeeded, string[] Error, ScoreTechDto Data)> GetTechScoreListAsync(DateTime startDate, DateTime endDate);
        Task<(bool Succeeded, string[] Error, ScoreProgrammingDto Data)> GetProgrammingScoreListAsync(DateTime startDate, DateTime endDate);
        Task<(bool Succeeded, string[] Error, List<EnquiryDetailDto> Data)> GetEnquiryDetailsAsync(DateTime startDate, DateTime endDate, int EmployId, string EnquiryType);
        Task<(bool Succeeded, string[] Error, List<BDARegistrationDto> Data)> GetBDARegistrationAsync(DateTime startDate, DateTime endDate, int EmployId, string RegistrationType);
        Task<(bool Succeeded, string[] Error, List<TechRegistrationDto> Data)> GetTechRegistrationAsync(DateTime startDate, DateTime endDate, int EmployId, string RegistrationType);
        Task<(bool Succeeded, string[] Error, List<ProgrammerRegistrationDto> Data)> GetProgrammerRegistrationAsync(DateTime startDate, DateTime endDate, int EmployId, string RegistrationType);
        Task<(bool Succeeded, string[] Error, ScorePublicationDto Data)> GetPublicationScoreListAsync(DateTime startDate, DateTime endDate);
        Task<(bool Succeeded, string[] Error, List<EmpPointsDto> Data)> GetTechPointsAsync(DateTime startDate, DateTime endDate, int EmployId, string Type);
        Task<(bool Succeeded, string[] Error, List<EmpPointsDto> Data)> GetProgrammerPointsAsync(DateTime startDate, DateTime endDate, int EmployId, string Type);
        Task<(bool Succeeded, string[] Error, List<PublicationDto> Data)> GetPublicationScoreDetailsAsync(DateTime startDate, DateTime endDate, int EmployId, int journalStatus, int journalStatus1);
    }
}
