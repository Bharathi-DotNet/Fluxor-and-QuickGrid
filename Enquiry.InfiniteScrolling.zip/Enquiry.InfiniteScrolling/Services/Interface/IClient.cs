﻿using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Models;

namespace Enquiry.Blazor.Services.Interface
{
    public interface IClient
    {
        Task<(bool Succeeded, string[] Error, IList<ClientListDto> Data)> GetClientsAsync(char chkValue);
        Task<(bool Succeeded, string[] Error, VirtualizeResponse<ClientListDto> Data)> GetVirtualizeClientsAsync(char chkValue, ClientListParameters clientParams);
        Task<(bool Succeeded, string[] Error, IList<IndividualClientListDto> Data)> GetContactBasedClientsAsync(string username);
        Task<(bool Succeeded, string[] Error)> CreateClientAsync(CreateClientDto dto);
        Task<(bool Succeeded, string[] Error, ClientDetailDto Data)> GetClientDetailAsync(int enquiryId);
        Task<(bool Succeeded, string[] Error, EditClientDto data)> EditClientFormAsync(int enquiryId);
        Task<(bool Succeeded, string[] Error)> EditClientAsync(EditClientDto dto);
        Task<(bool Succeeded, string[] Error)> DeleteClientAsync(int enquiryId);
        Task<(bool Succeeded, string[] Error)> UpdateBDAForClientAsync(int bdaId, int enquiryId);
        Task<(bool Succeeded, string[] Error)> UpdateTechExpertForClientAsync(int techId, int enquiryId);
        Task<(bool Succeeded, string[] Error, IList<ClientActivityDto> Data)> GetClientActivityAsync(int enquiryId, bool isComment);
        Task<(bool Succeeded, string[] Error)> UpdatePaymentRemarksAsync(int enquiryId, string remarks, bool isRegsitered);
        Task AddEnquiryActivity(int enquiryId, int empId, string comment, bool isComment);
        Task<(bool Succeeded, string[] Error)> UpdateAppoinmentDateAsync(DateTime appoinmentDate, int enquiryId);
        Task<(bool Succeeded, string[] Error)> UpdateAsTechAppoinmentAsync(bool ChkValue, int enquiryId);
        Task<(bool Succeeded, string[] Error)> UpdateIsEmailedAsync(int enquiryId, bool isEmailed);
        Task<(bool Succeeded, string[] Error, Clients Clients)> IsRegisteredAsync(int enquiryId, bool isRegsitered);
        Task<(bool Succeeded, string[] Error)> UpdateBackToEnquiryAsync(int enquiryId);
        Task<(bool Succeeded, string[] Error)> UpdateProgrammerForClientAsync(int pgmId, int enquiryId);
        Task<bool> ClientFormAsync(string token, int enquiryid);
        Task<(bool Succeeded, string[] Error, ClientformDto clientform)> GetClientFormDetailsAsync(string token);
        Task<bool> UpdateClientFormAsync(ClientformDto formdto);
        Task<(bool Succeeded, string[] Error)> CreateClientDataAsync(DataDto data);
        Task<(bool Succeeded, string[] Error, DataDto data)> GetClientDetailAsync(string PhoneNo);
        Task<(bool Succeeded, string[] Error, DataCount dataCount)> GetDataCountAsync();
        Task<(bool Succeeded, string[] Errors)> CreateEnquiryFileAsync(EnquiryFiles file);
        Task<(bool Succeeded, string[] Error, ComposedEmailDto compose)> GetClientEmailIdAsync(int? enquiryId, int? projectId, bool IsPublication);
        Task<(bool Succeeded, string[] Error, ComposedEmailDto reply)> GetClientReplyEmailAsync(int? enquiryId, int emailId,int? projectId, bool IsPublication);
        Task<(bool Succeeded, string[] Errors, List<dynamic> Attachments)> CreateSentEmailAsync(ComposedEmailDto composedMail, string SenderName, string SenderEmail);
        bool SetUrlToEmailAttachmentAsync(string OriginalUrl, string ShortUrl, int AttachmentId);
        Task<string> GetOriginalUrlAsync(string ShortUrl);
        Task<string> GetOriginalFilePathAsync(string shortUrl);
    }
}
