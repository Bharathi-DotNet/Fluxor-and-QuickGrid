﻿using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Models;

namespace Enquiry.Blazor.Services.Interface;

public interface IPublication
{
    Task<(bool Succeeded, string[] Error, IList<PublicationListDto> Publication)> GetPublicationListAsync(char chkValue);
    Task<(bool Succeeded, string[] Error, JournalPhaseFileDetailDto Data, bool PublicationApproval, int PhaseId)> GetJournalListAsync(int projectId);
    Task<(bool Succeeded, string[] Error, JournalDetailDto Data)> GetJournalAsync(int publicationid);
    Task<(bool Succeeded, string[] Error)> GetJournalHistoryAsync(JournalDetailDto journalHistory, int PublicationId);
    List<IGrouping<(DateTime? VerifiedDate, string JournelName), AllJournalDto>> GetAllJournalsAsync();
    Task<(bool Succeeded, string[] Error)> UpdateJournalAsync(OldJournalDto oldJournal, UpdatedJournalDto updatedJournal);
    Task<(bool Succeeded, string[] Error, AllJournalDto journaldto)> CreateJournalAsync(AllJournalDto journaldto);
    Task<(bool Succeeded, string[] Error, IList<UpdatedJournalDto> journal)> GetJournalListAsync();
    Task<(bool Succeeded, string[] Error, OldJournalDto journal)> GetJournalDetailAsync(int JournalId);
    Task<bool> DeleteJournalAsync(int PublicationId);
    Task<bool> DeleteJournalTopicAsync(int JournalId);
    Task<(bool Succeeded, string[] Error, List<GetJournalDetailsClient> client)> GetJournalDetailOfClientAsync(string JournalName);
    Task<(bool Succeeded, string[] Errors)> UpdateIsPublicationApprovalAsync(int phaseId);
    Task<(bool Succeeded, string[] Errors, IList<PhaseForPublicationDto> phase)> GetPublicationPhaseListAsync();
    Task<(bool Succeeded, string[] Error)> UpdatePublicationEmpInClientAsync(AssignPublicationDto assignPub);
 }
