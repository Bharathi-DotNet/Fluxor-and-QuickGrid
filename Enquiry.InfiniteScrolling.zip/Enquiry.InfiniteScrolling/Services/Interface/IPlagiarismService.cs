﻿using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Models;

namespace Enquiry.Blazor.Services.Interface
{
    public interface IPlagiarismService
    {
        Task<(bool Succeeded, string[] Error, bool value)> IsPlagiarismEnabledForEmployee();
        Task<(bool Succeeded, string[] Error, IList<PlagiarismListDto> files)> PlagiarismForEmployeeAsync();
        Task<(bool Succeeded, string[] Error, Plagiarism plagiarism)> CreatePlagiarismFileAsync(string fileName, string filePath,int? PhaseId,int? EnquiryId);
        Task<(bool Succeeded, string[] Error, PlagiarismRecipient plagiarismRecipient)> CreatePlagiarismRecipientAsync(int plagiarismId, int empId);
        Task<(bool Succeeded, string[] Error)> UpdatePlagiarismIsDownloaded(int plagiarismRecipientId, int empId);
        Task<(bool Succeeded, string[] Error, bool value)> CheckPlagiarismIsDownloaded(int plagiarismRecipientId);
        Task<(bool Succeeded, string[] Error, PlagiarismRecipient plagiarismRecipient)> CreatePlagiarismRecipientForUploadEmployeeAsync(PlagiarismRecipient recp);
        Task<(bool Succeeded, string[] Error, PlagiarismPhaseDetailsDto PlagiarismPhaseDetailsDto)> GetPhaseDetailsAsync(int PhaseId);
        Task<(bool Succeeded, string[] Errors)> DeletePlagiarismAsync(int PlagiarismId);
    }
}
