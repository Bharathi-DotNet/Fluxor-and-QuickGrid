﻿using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Models;

namespace Enquiry.Blazor.Services.Interface;

public interface IEmployee
{
    Task<(bool Succeeded, string[] Error, IList<Roles> Data)> GetRolesAsync();
    Task<(bool Succeeded, string[] Error, IList<Department> Data)> GetDepartmentAsync();
    Task<(bool Succeeded, string[] Error, IList<EmployeeListDto> Data)> GetEmployeeAsync();
    Task<(bool Succeeded, string[] Error)> CreateEmployeeAsync(CreateEmployeeDto dto);
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetBDAAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetTechExpertAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetProgrammerAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetTechExpertExecutiveAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetTechExpertTLAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetTechExpertManagerAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetProgrammerExecutiveAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetProgrammerTLAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetProgrammerManagerAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetBDAExecutiveAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetBDATeamLeaderAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetBDAManagerAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetPublicationExecutiveAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetPublicationTLAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetPublicationManagerAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetManagerAsync();
    Task<(bool Succeeded, string[] Error, IList<EmployeeTreeDto> Data)> GetEmployeeSuperiorWiseTree();
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> ManagerReportViewAsync();
    Task<(bool Succeeded, string[] Error, IList<OrganizationTreeDto> Data)> GetOrganizationChartAsync();
    Task<(bool Succeeded, string[] Error, IList<EmployeeListDto> Data)> GetInactiveEmployeeAsync();
    Task<(bool Succeeded, string[] Error, EditEmployeeDto employee)> EditEmployeeAsync(int EmpId);
    Task<(bool Succeeded, string[] Error)> UpdateEmployeeAsync(EditEmployeeDto editEmployee);
    Task<(bool Succeeded, string[] Error)> ResetEmployeePasswordAsync(int EmpId);
    Task<(bool Succeeded, string[] Error, IList<FeedbackDto> feedback)> GetEmployeeFeedbackAsync(int EmpId);
    Task<(bool Succeeded, string[] Error)> CreateFeedbackFormAsync(FeedbackDto feedbackDto);
    Task<(bool Succeeded, string[] Error, IList<FeedbackDto> feedbackdetail)> GetFeedbackDetailsAsync();
    Task<(bool Succeeded, string[] Error)> UpdateFeedbackFormAsync(int feedbackId, int employeeId, string empFeedback);
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetTechExpertEnquiryAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> birthday)> GetEmployeeBirthdayAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> anniversary)> GetEmployeeAnniversaryAsync();
    Task<(bool Succeeded, string[] Error)> UpdateEmployeeAnniversaryAsync(IFormFile file, int empId);
    Task<(bool Succeeded, string[] Error)> UploadEmployeeBirthdayImageAsync(IFormFile file, int empId);
    Task<(bool Succeeded, string[] Error, EmployeeSalaryInfo salary)> CalculateSalaryAsync(int totalAmount);
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetProgramTLAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetTechTLAsync();
    Task<(bool Succeeded, string[] Error, Employees Data)> GetEmployeeDetailAsync(int empId);
    Task<(bool Succeeded, string[] Error, IList<Employees> employees)> GetPlagiarismEmployeeAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> employees)> GetNoPlagiarismEmployeeAsync();
    Task<(bool Succeeded, string[] Error)> UpdatePlagiarismEmployeeAsync(int EmployeeId, bool IsPlagiarism);
    Task<(bool Succeeded, string[] Error, Employees employees)> GetPlagiarismEnabledForEmployeeAsync(int userId);
    Task<(bool Succeeded, string[] Error, IList<Employees> employees)> GetEmailEmployeeAsync();
    Task<(bool Succeeded, string[] Error, IList<Employees> employees)> GetNoEmailEmployeeAsync();
    Task<(bool Succeeded, string[] Error)> UpdateEmailEmployeeAsync(int EmployeeId, bool IsEmail);
    Task<(bool Succeeded, string[] Error, IList<Employees> Data)> GetPublicationExecutiveWithProjectAssignedAsync();
}
