﻿using Enquiry.Blazor.Dtos;

namespace Enquiry.Blazor.Services.Interface
{
    public interface IMcube
    {
        Task<(bool Succeeded, string[] Error)> AddMCubeInboundCall(McubeInboundCallData dto);
    }
}
