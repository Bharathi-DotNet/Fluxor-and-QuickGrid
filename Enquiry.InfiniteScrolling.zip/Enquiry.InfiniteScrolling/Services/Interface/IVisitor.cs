﻿using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Models;

namespace Enquiry.Blazor.Services.Interface
{
    public interface IVisitor
    {
        Task<(bool Succeeded, string[] Error, IList<VisitorsListDto> Data)> GetVisitorAsync();
    }
}
