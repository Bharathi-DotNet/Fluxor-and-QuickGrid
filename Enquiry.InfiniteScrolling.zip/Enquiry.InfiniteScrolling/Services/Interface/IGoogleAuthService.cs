﻿using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Models;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Auth.OAuth2.Responses;
using Google.Apis.Drive.v3;
using Google.Apis.Upload;
using static Google.Apis.Drive.v3.FilesResource;

namespace Enquiry.Blazor.Services.Interface
{
    public interface IGoogleAuthService
    {
        string GetGoogleAuthUrl();
        Task<TokenResponse> GetUserCredential(string code);
        UserCredential GetGoogleCredential(string accessToken);
        Task<GoogleCredential> RefreshTokenAsync(string refreshToken);
        Task<UserCredential> GetUserCredentialFromGoogleCredential(GoogleCredential googleCredential, string refreshToken);
        Task<string> GetGoogleDocsEditUrlAsync(string fileId, UserCredential credential, string fileName);
        Task<Google.Apis.Drive.v3.Data.File> GetFileMetadataFromDrive(UserCredential credential, string fileId);
        Task DeleteFileFromDrive(UserCredential credential, string fileId);
        Task DownloadFileFromDrive(UserCredential credential, string destinationFilePath, bool sendOnSlack, int plagiarismRecipientId);
        Task<StoreGoogleTokens> CreateGoogleToken(StoreGoogleTokens token);
        Task<StoreGoogleTokens> GetGoogleToken(int userId);
        Task<StoreGoogleTokens> UpdateGoogleToken(StoreGoogleTokens token);
        Task<bool> EnsureGoogleAuthAsync(int userId);
        Task<(IUploadProgress uploadProgress, CreateMediaUpload mediaUpload)> AddFileToDrive(UserCredential credential, string filename, string filePath);
    }
}
