﻿using AutoMapper;
using AutoMapper.Execution;
using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Extensions;
using Enquiry.Blazor.Models;
using Enquiry.Blazor.Services.Interface;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using SlackNet;
using SlackNet.Events;
using SlackNet.WebApi;
using System.IO;
using System.Numerics;
using System.Reactive.Joins;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace Enquiry.Blazor.Services
{
    public class Project : IProject
    {
        readonly ApplicationDbContext _context;
        readonly IMapper _mapper;
        private readonly ISession _session;
        readonly IEmployee _employee;
        readonly ISlack _slack;
        private readonly SlackConfig _slackConfig;
        public Project(ApplicationDbContext context, IMapper mapper, IHttpContextAccessor httpContextAccessor, IEmployee employee, ISlack slack, IOptions<SlackConfig> slackConfig = null)
        {
            _context = context; _mapper = mapper; _session = httpContextAccessor.HttpContext.Session; _employee = employee;
            _slack = slack;
            _slackConfig = slackConfig.Value;
        }

        public async Task<(bool Succeeded, string[] Error, IList<ProjectListDto> Data)> GetPhaseAsync()
        {
            try
            {
                IEnumerable<Phase> phase;

                var project = await _context.Projects
                    .Include(x => x.Phase).ThenInclude(x => x.Employees)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees1)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees2)
                    .Include(x => x.Phase).ThenInclude(x => x.WorkStatus)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees3)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees4)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees5)
                    .Include(x => x.Clients).ThenInclude(x => x.BDAEmployee)
                    .Include(x => x.Clients).ThenInclude(x => x.TechEmployee)
                    .Include(x => x.Clients).ThenInclude(x => x.TechTLEmployee)
                    .Include(x => x.Clients).ThenInclude(x => x.ProgrammerTLEmployee).ToListAsync();

                if (_session.GetString("Role") == Enum.Roles.Manager.ToString())
                {
                    phase = project.Where(x => x.Phase.Count() > 0).Select(x => x.Phase.OrderByDescending(x => x.ProjectId).LastOrDefault());
                }
                else if (_session.GetString("Dept") == Enum.Department.BDA.ToString())
                {
                    phase = project.Where(x => x.Phase.Count() > 0).Select(x => x.Phase.OrderByDescending(x => x.ProjectId).LastOrDefault());
                }
                else
                {
                    var currentUserId = Int32.Parse(_session.GetInt32("CurrentUserId").ToString());

                    if (_session.GetString("Role") == EnumerationDescription.GetDescription(Enum.Roles.TeamLead) && _session.GetString("Dept") == Enum.Department.Tech.ToString())
                    {
                        var enquiryId = _context.Clients.Where(x => x.TechTL == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) || x.ProgrammerTL == Int32.Parse(_session.GetInt32("CurrentUserId").ToString())).Select(x => x.EnquiryId).ToList();
                        var projectId = _context.Projects
                            .Where(project => enquiryId.Contains(project.EnquiryId))
                            .Select(project => project.ProjectId)
                            .ToList();
                        phase = project.Where(x => x.Phase.Count() > 0 &&
                            ((x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees != null && y.Employees.EmpId == currentUserId)) ||
                                (x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees1 != null && y.Employees1.EmpId == currentUserId)) ||
                                (x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees2 != null && y.Employees2.EmpId == currentUserId)) ||
                                (x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees3 != null && y.Employees3.EmpId == currentUserId)) ||
                                (x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees4 != null && y.Employees4.EmpId == currentUserId)) ||
                                (x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees5 != null && y.Employees5.EmpId == currentUserId)) || projectId.Contains(x.ProjectId))
                                ).Select(x => x.Phase.OrderByDescending(x => x.ProjectId).LastOrDefault());

                        phase = phase.Where(phasetmp => phasetmp.Status == (int)Enum.WorkStatus.Publication ||
                                phasetmp.TechExpert == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) ||
                                phasetmp.TechExpert1 == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) ||
                                phasetmp.TechExpert2 == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) ||
                                phasetmp.TechExpert3 == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) ||
                                phasetmp.Programmer == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) ||
                                phasetmp.Programmer1 == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) ||
                              (phasetmp.Projects.Clients.TechTL == _session.GetInt32("CurrentUserId") && phasetmp.Status <= 2
                               && phasetmp.IsTechNeeded && phasetmp.TechExpert == null &&
                              phasetmp.TechTLStatus == false && phasetmp.PgmTLStatus == false)

                            );
                    }
                    else if (_session.GetString("Role") == EnumerationDescription.GetDescription(Enum.Roles.TeamLead) && _session.GetString("Dept") == Enum.Department.Programming.ToString())
                    {
                        var enquiryId = _context.Clients.Where(x => x.TechTL == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) || x.ProgrammerTL == Int32.Parse(_session.GetInt32("CurrentUserId").ToString())).Select(x => x.EnquiryId).ToList();
                        var projectId = _context.Projects
                            .Where(project => enquiryId.Contains(project.EnquiryId))
                            .Select(project => project.ProjectId)
                            .ToList();
                        phase = project.Where(x => x.Phase.Count() > 0 &&
                            ((x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees != null && y.Employees.EmpId == currentUserId)) ||
                                (x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees1 != null && y.Employees1.EmpId == currentUserId)) ||
                                (x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees2 != null && y.Employees2.EmpId == currentUserId)) ||
                                (x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees3 != null && y.Employees3.EmpId == currentUserId)) ||
                                (x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees4 != null && y.Employees4.EmpId == currentUserId)) ||
                                (x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees5 != null && y.Employees5.EmpId == currentUserId)) || projectId.Contains(x.ProjectId))
                                ).Select(x => x.Phase.OrderByDescending(x => x.ProjectId).LastOrDefault());

                        phase = phase.Where(phasetmp => phasetmp.Status == (int)Enum.WorkStatus.Publication ||
                                phasetmp.TechExpert == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) ||
                                phasetmp.TechExpert1 == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) ||
                                phasetmp.TechExpert2 == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) ||
                                phasetmp.TechExpert3 == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) ||
                                phasetmp.Programmer == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) ||
                                phasetmp.Programmer1 == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) ||
                               (phasetmp.Projects.Clients.ProgrammerTL == _session.GetInt32("CurrentUserId") && phasetmp.Status <= 2
                               && phasetmp.IsProgrammerNeeded && phasetmp.Programmer == null && phasetmp.TechTLStatus == false && phasetmp.PgmTLStatus == false)
                            );
                    }
                    else
                    {
                        phase = project.Where(x => x.Phase.Count() > 0 &&
                            ((x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees != null && y.Employees.EmpId == currentUserId)) ||
                                (x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees1 != null && y.Employees1.EmpId == currentUserId)) ||
                                (x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees2 != null && y.Employees2.EmpId == currentUserId)) ||
                                (x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees3 != null && y.Employees3.EmpId == currentUserId)) ||
                                (x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees4 != null && y.Employees4.EmpId == currentUserId)) ||
                                (x.Phase != null && x.Phase.OrderByDescending(p => p.PhaseId).Take(2).Any(y => y.Employees5 != null && y.Employees5.EmpId == currentUserId)))
                                ).Select(x => x.Phase.OrderByDescending(x => x.ProjectId).LastOrDefault());

                        phase = phase.Where(phasetmp => phasetmp.Status == (int)Enum.WorkStatus.Publication ||
                                phasetmp.TechExpert == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) ||
                                phasetmp.TechExpert1 == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) ||
                                phasetmp.TechExpert2 == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) ||
                                phasetmp.TechExpert3 == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) ||
                                phasetmp.Programmer == Int32.Parse(_session.GetInt32("CurrentUserId").ToString()) ||
                                phasetmp.Programmer1 == Int32.Parse(_session.GetInt32("CurrentUserId").ToString())
                            );
                    }                    
                }


                List<String> lstCustomSort = new List<String>() { "Publication", "Completed", "Published" };
                var user = Int32.Parse(_session.GetInt32("CurrentUserId").ToString());
                var result = phase.Select(t => new ProjectListDto()
                {
                    EnquiryId = t.Projects.Clients.EnquiryId,
                    PhaseId = t.PhaseId,
                    ProjectId = t.ProjectId,
                    ClientName = t.Projects.Clients.ClientName,
                    ProjectName = t.Projects.ProjectName,
                    PhaseName = t.PhaseName,
                    EnquiryRef = t.Projects.ProjectRef,
                    Contact = t.Projects.Clients.Contact,
                    Domain = t.Projects.Clients.Domain,
                    DeadLine = t.DeadLine,
                    NextAppoinment = t.NextAppoinment,
                    // DemoDate =  t.DemoDate,
                    //DemoDate = t.NextAppoinment <  t.DemoDate  ? t.NextAppoinment : t.DemoDate,
                    // DemoDate = t.NextAppoinment != null ? t.NextAppoinment : t.DemoDate,
                    DemoDate = t.Status == (int)Enum.WorkStatus.Hold ? t.NextAppoinment : t.DemoDate,
                    DemoDate3 = t.Status == (int)Enum.WorkStatus.Hold ? t.NextAppoinment : t.DemoDate3,
                    DemoDate1 = t.DemoDate1,
                    DemoDate2 = t.DemoDate2,
                    DemoDate4 = t.DemoDate4,
                    DemoDate5 = t.DemoDate5,
                    Status = (t.Projects.Clients.ProgrammerTL == _session.GetInt32("CurrentUserId") && t.IsProgrammerNeeded && t.Status == 2 &&
                              t.Programmer == null && t.TechTLStatus == false && t.PgmTLStatus == false)
                              ? "Assigned"
                              : (t.Projects.PaymentApproval ? "Approval" : t.WorkStatus.WorkStatusName),
                    //Status = t.WorkStatus.WorkStatusName,
                    StatusId = t.Status,
                    AssignedTech = t.Employees == null ? "" : t.Employees.EmployeeName,
                    AssignedTech1 = t.Employees1 == null ? "" : t.Employees1.EmployeeName,
                    AssignedTech2 = t.Employees2 == null ? "" : t.Employees2.EmployeeName,
                    AssignedTech3 = t.Employees3 == null ? "" : t.Employees3.EmployeeName,
                    AssignedTech4 = t.Employees4 == null ? "" : t.Employees4.EmployeeName,
                    AssignedTech5 = t.Employees5 == null ? "" : t.Employees5.EmployeeName,
                    WorkCountTech = t.TechExpert.HasValue ? GetEmployeesInProgressAsync(t.TechExpert.Value) : 0,
                    WorkCountTech1 = t.TechExpert1.HasValue ? GetEmployeesInProgressAsync(t.TechExpert1.Value) : 0,
                    WorkCountTech2 = t.TechExpert2.HasValue ? GetEmployeesInProgressAsync(t.TechExpert2.Value) : 0,
                    WorkCountTech3 = t.TechExpert3.HasValue ? GetEmployeesInProgressAsync(t.TechExpert3.Value) : 0,
                    WorkCountTech4 = t.Programmer.HasValue ? GetEmployeesInProgressAsync(t.Programmer.Value) : 0,
                    WorkCountTech5 = t.Programmer1.HasValue ? GetEmployeesInProgressAsync(t.Programmer1.Value) : 0,
                    Comment = t.Comment,
                    TechExpert = t.TechExpert,
                    TechExpert1 = t.TechExpert1,
                    TechExpert2 = t.TechExpert2,
                    TechExpert3 = t.TechExpert3,
                    Programmer = t.Programmer,
                    Programmer1 = t.Programmer1,
                    TechPriority = t.TechPriority,
                    TechPriority1 = t.TechPriority1,
                    TechPriority2 = t.TechPriority2,
                    TechPriority3 = t.TechPriority3,
                    ProgrammerPriority = t.ProgrammerPriority,
                    ProgrammerPriority1 = t.ProgrammerPriority1,
                    TechStatus = t.TechStatus == true && t.TechExpert.HasValue && t.TechExpert == _session.GetInt32("CurrentUserId") ? true : false,
                    TechStatus1 = t.TechStatus1 == true && t.TechExpert1.HasValue && t.TechExpert1 == _session.GetInt32("CurrentUserId") ? true : false,
                    TechStatus2 = t.TechStatus2 == true && t.TechExpert2.HasValue && t.TechExpert2 == _session.GetInt32("CurrentUserId") ? true : false,
                    TechStatus3 = t.TechStatus3 == true && t.TechExpert3.HasValue && t.TechExpert3 == _session.GetInt32("CurrentUserId") ? true : false,
                    ProgrammerStatus = t.ProgrammerStatus == true && t.Programmer.HasValue && t.Programmer == _session.GetInt32("CurrentUserId") ? true : false,
                    ProgrammerStatus1 = t.ProgrammerStatus1 == true && t.Programmer1.HasValue && t.Programmer1 == _session.GetInt32("CurrentUserId") ? true : false,
                    TechTLStatus = t.TechTLStatus == false && t.TechTL.HasValue && t.TechTL == _session.GetInt32("CurrentUserId") ? true : false,
                    PgmTLStatus = t.PgmTLStatus == false && t.PgmTL.HasValue && t.PgmTL == _session.GetInt32("CurrentUserId") ? true : false,
                    TechTL = t.TechTL,
                    PgmTL = t.PgmTL,
                    IsProgrammerNeeded = t.IsProgrammerNeeded ? "Pgm.Enabled" : null,
                    IsTechNeeded = t.IsTechNeeded ? "Tech.Enabled" : null,
                    IsTechPgmDisabled = (!t.IsProgrammerNeeded && !t.IsTechNeeded) ? t.Projects.Clients.TechTLEmployee.EmployeeName: null,
                    TechTLStatus1 = t.TechTLStatus,
                    PgmTLStatus1 = t.PgmTLStatus,
                    TechStatusAny = ((t.TechStatus && t.TechExpert.HasValue) || (t.TechStatus1 && t.TechExpert1.HasValue)
                        || (t.TechStatus2 && t.TechExpert2.HasValue) || (t.TechStatus3 && t.TechExpert3.HasValue)) ? true : false,
                    PgmStatusAny = ((t.ProgrammerStatus && t.Programmer.HasValue) || (t.ProgrammerStatus1 && t.Programmer1.HasValue)) ? true : false,
                    Priority = (user) switch
                    {
                        _ when t.TechExpert == user => t.TechPriority,
                        _ when t.TechExpert1 == user => t.TechPriority1,
                        _ when t.TechExpert2 == user => t.TechPriority2,
                        _ when t.TechExpert3 == user => t.TechPriority3,
                        _ when t.Programmer == user => t.ProgrammerPriority,
                        _ when t.Programmer1 == user => t.ProgrammerPriority1,
                        _ => null
                    },
                    ManagerPriority = (1) switch
                    {
                        _ when t.TechPriority == 1 => t.TechPriority,
                        _ when t.TechPriority1 == 1 => t.TechPriority1,
                        _ when t.TechPriority2 == 1 => t.TechPriority2,
                        _ when t.TechPriority3 == 1 => t.TechPriority3,
                        _ when t.ProgrammerPriority == 1 => t.ProgrammerPriority,
                        _ when t.ProgrammerPriority1 == 1 => t.ProgrammerPriority1,
                        _ => null
                    },
                }).OrderBy(x => x.StatusId).ThenBy(x => x.DeadLine).ToList();

                if (_session.GetString("Dept") == Enum.Department.Tech.ToString() || _session.GetString("Dept") == Enum.Department.Programming.ToString())
                {
                    if (_session.GetString("Role") == "Team Lead")
                    {
                        var superiorData = await GetSuperiorPhaseAsync();
                        foreach (var projectDto in result)
                        {
                            projectDto.SubordinatesProjectListDto = superiorData;
                        }
                    }
                }

                return (true, new string[] { }, result);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }
        public async Task<(bool Succeeded, string[] Error, Projects Project)> CreateProjectAsync(CreateProjectDto projectDto)
        {
            try
            {
                var clientDetail = _context.Clients.Where(y => y.EnquiryId == projectDto.ClientDetailsDto.EnquiryId).FirstOrDefault();
                var projectStatus = await _context.ProjectStatus
                    .Where(x => x.ProjectName == projectDto.ProjectName && x.WorkType == projectDto.WorkType)
                    .Select(x => new
                    {
                        x.NormalPayment,
                        x.AgentPayment
                    })
                    .FirstOrDefaultAsync();
                var map = _mapper.Map<Projects>(projectDto);
                
                map.EnquiryId = projectDto.ClientDetailsDto.EnquiryId;
                map.ProjectName = $"{projectDto.ProjectName}_{projectDto.WorkType}({projectDto.ProjectRemark})";
                await _context.AddAsync(map);
                int result = await _context.SaveChangesAsync().ConfigureAwait(false);
                if (result > 0)
                {
                    var client = await _context.Clients.Where(x => x.EnquiryRef == projectDto.ClientDetailsDto.EnquiryRef &&
                                                                x.EnquiryId == projectDto.ClientDetailsDto.EnquiryId)
                        .Include(x => x.Projects).Include(x => x.TechEmployee).Include(x => x.ProgrammerEmployee).ToListAsync();
                    var projects = await _context.Projects.Where(y => y.ProjectRef.StartsWith($"{projectDto.ClientDetailsDto.EnquiryRef}-")).ToListAsync();
                    map.ProjectRef = $"{client[0].EnquiryRef}-{projects.Count() + 1}";
                    if (projectStatus != null &&
                    ((clientDetail.IsAgent == true && projectStatus.AgentPayment != projectDto.TotalPayment)
                    || (clientDetail.IsAgent == false && projectStatus.NormalPayment != projectDto.TotalPayment)))
                    {
                        IList<string> members = _slackConfig.FeeApproval.ToList();
                        string approvalMessage = "";
                        if ((clientDetail.IsAgent == true && projectStatus.AgentPayment > projectDto.TotalPayment)
                        || (clientDetail.IsAgent == false && projectStatus.NormalPayment > projectDto.TotalPayment))
                        {
                            approvalMessage = $"Reduced Fee Registration: Kindly check and approve the Project ID :{map.ProjectRef} and Name :{clientDetail.ClientName}";
                        }
                        else if ((clientDetail.IsAgent == true && projectStatus.AgentPayment < projectDto.TotalPayment)
                        || (clientDetail.IsAgent == false && projectStatus.NormalPayment < projectDto.TotalPayment))
                        {
                            approvalMessage = $"Increased Fee Registration: Kindly check and approve the Project ID :{map.ProjectRef} and Name :{clientDetail.ClientName}";
                        }
                        foreach (var item in members)
                        {
                            await _slack.SendMessage(approvalMessage, item);
                        }
                        map.PaymentApproval = true;
                    }
                    _context.Update(map);
                    await _context.SaveChangesAsync().ConfigureAwait(false);
                    string message = $"Registration: {client[0].ClientName}{map.ProjectRef.Substring(7)} was registered with us for {map.ProjectName}";
                    if (client[0].TechExpert.HasValue)
                    {
                        await _slack.SendMessage(message, client[0].TechEmployee.MemberId);
                    }
                    if (client[0].Programmer.HasValue)
                    {
                        await _slack.SendMessage(message, client[0].ProgrammerEmployee.MemberId);
                    }
                }
                return (true, new string[] { "Project added sucessfully" }, map);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        public async Task<(bool Succeeded, string[] Error, Phase Phase)> CreatePhaseAsync(CreatePhaseDto phaseDto, int projectId)
        {
            try
            {
                var map = _mapper.Map<Phase>(phaseDto);
                var phaseStatus = await _context.PhaseStatus.FirstOrDefaultAsync(ps => ps.Id == phaseDto.PhaseName && ps.IsActive);
                if (phaseStatus != null)
                {
                    map.PhaseName = phaseStatus.PhaseName; // Set the StatusName property
                    map.ProjectId = projectId;

                    if (phaseDto.IsPublication)
                    {
                        var projectDetail = await _context.Projects
                                .Where(p => p.ProjectId == projectId)
                                .Select(p => new
                                {
                                    ProjectRef = p.ProjectRef,
                                    ClientName = _context.Clients
                                        .Where(c => c.EnquiryId == p.EnquiryId)
                                        .Select(c => c.ClientName)
                                        .FirstOrDefault()
                                })
                                .FirstOrDefaultAsync();
                        /*var pub = new List<Models.Publication>();*/
                        map.Status = (int)Enum.WorkStatus.Publication;
                        map.IsPublicationApproval = true;
                        IList<string> members = _slackConfig.PublicationApproval.ToList();
                        string message = $"The project with ID {projectDetail.ProjectRef} and client {projectDetail.ClientName} needs to begin the publication process. Kindly review the manuscript on the publication approval page of our portal.";
                        foreach (var item in members)
                        {
                            await _slack.SendMessage(message, item);
                        }
                        /*var subPub = new Models.Publication();
                        {
                            ProjectId = projectId;
                        }
                        pub.Add(subPub);*/

                        /*for (int i = 0; i <= 30; i++)
                        {
                            var subPub = new Models.Publication()
                            {
                                ProjectId = projectId
                            };
                            pub.Add(subPub);
                        }*/
                        /* await _context.Publication.AddRangeAsync(pub);
                         await _context.SaveChangesAsync();*/
                    }
                    map.PhaseRemark = phaseDto.PhaseRemark;
                    map.DeadLineCount = (int)Math.Round((phaseDto.DeadLine - map.AssignedDate).Value.TotalDays) / 1.5;
                    await _context.AddAsync(map);
                    int result = await _context.SaveChangesAsync().ConfigureAwait(false);
                    return (true, new string[] { "Project added sucessfully" }, map);
                }
                else
                {
                    return (false, new string[] { "Phase status is empty" }, null);
                }
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        public async Task<(bool Succeeded, string[] Error, Phase Phase)> UpdatePhaseAsync(EditPhaseDto phaseDto)
        {
            try
            {
                var phase = await _context.Phase.Include(x => x.Employees).Include(x => x.Employees1).Include(x => x.Employees2)
                    .Include(x => x.Employees3).Include(x => x.Employees4).Include(x => x.Employees5).Include(x => x.Projects)
                    .Include(x => x.Projects).ThenInclude(x => x.Clients).Where(x => x.PhaseId == phaseDto.PhaseId).FirstOrDefaultAsync();
                var map = _mapper.Map<EditPhaseDto, Phase>(phaseDto, phase);
                if (map.DemoDate.HasValue) map.Status = (int)Enum.WorkStatus.Progress;
                else if (map.DemoDate3.HasValue) map.Status = (int)Enum.WorkStatus.Progress;
                else map.Status = (int)Enum.WorkStatus.Assigned;
                _context.Update(map);
                int result = await _context.SaveChangesAsync().ConfigureAwait(false);
                if (result > 0)
                {
                    string message = $"Phase: {map.PhaseName} of {phase.Projects.Clients.ClientName} was assigned";
                    if (phase.Employees is null && phaseDto.TechExpert.HasValue)
                    {
                        var employee = await _context.Employees.FindAsync(phaseDto.TechExpert.Value);
                        await _slack.SendMessage(message, employee.MemberId);
                    }
                    if (phase.Employees1 is null && phaseDto.TechExpert1.HasValue)
                    {
                        var employee = await _context.Employees.FindAsync(phaseDto.TechExpert1.Value);
                        await _slack.SendMessage(message, employee.MemberId);
                    }
                    if (phase.Employees2 is null && phaseDto.TechExpert2.HasValue)
                    {
                        var employee = await _context.Employees.FindAsync(phaseDto.TechExpert2.Value);
                        await _slack.SendMessage(message, employee.MemberId);
                    }
                    if (phase.Employees3 is null && phaseDto.TechExpert3.HasValue)
                    {
                        var employee = await _context.Employees.FindAsync(phaseDto.TechExpert3.Value);
                        await _slack.SendMessage(message, employee.MemberId);
                    }
                    if (phase.Employees4 is null && phaseDto.Programmer.HasValue)
                    {
                        var employee = await _context.Employees.FindAsync(phaseDto.Programmer.Value);
                        await _slack.SendMessage(message, employee.MemberId);
                    }
                    if (phase.Employees5 is null && phaseDto.Programmer1.HasValue)
                    {
                        var employee = await _context.Employees.FindAsync(phaseDto.Programmer1.Value);
                        await _slack.SendMessage(message, employee.MemberId);
                    }
                }
                return (true, new string[] { "Project updated sucessfully" }, map);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        public async Task<(bool Succeeded, string[] Error, Payments Phase)> CreatePaymentAsync(CreatePayment payment, int projectId)
        {
            try
            {
                var map = _mapper.Map<Payments>(payment);
                map.ProjectId = projectId;
                await _context.AddAsync(map);
                int result = await _context.SaveChangesAsync().ConfigureAwait(false);
                return (true, new string[] { "Payment added sucessfully" }, map);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        public async Task<(bool Succeeded, string[] Error, Models.Publication Publication)> CreateJournalAsync(JournalDetailDto journal, int projectId, int? empId)
        {
            try
            {
                var map = _mapper.Map<Models.Publication>(journal);
                map.ProjectId = projectId;
                map.AssignTo = empId;

                if (_session.GetInt32("CurrentUserId") is not null)
                {
                    map.CreatedBy = (int)_session.GetInt32("CurrentUserId");
                    map.UpdatedBy = (int)_session.GetInt32("CurrentUserId");
                }

                map.CreatedDate = DateTime.Now;
                map.UpdatedDate = DateTime.Now;


                await _context.AddAsync(map);
                int result = await _context.SaveChangesAsync().ConfigureAwait(false);
                return (true, new string[] { "Journal added sucessfully" }, map);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        public async Task<(bool Succeeded, string[] Error, Models.Publication Publication)> UpdateJournalAsync(JournalDetailDto dto, int projectId)
        {
            try
            {
                var jrl = await _context.Publication.FindAsync(dto.PublicationId);
                jrl.RemainderDate = dto.RemainderDate;
                jrl.JournelName = dto.JournelName;
                jrl.Link = dto.Link;
                jrl.Publisher = dto.Publisher;
                jrl.Reason = dto.Reason;
                jrl.DateOfSubmission = dto.DateOfSubmission;
                jrl.Status = (int)dto.Status;
                jrl.UserId = dto.UserId;
                jrl.Password = dto.Password;
                jrl.IsTechnicalRejected = dto.IsTechnicalRejected;

                if (_session.GetInt32("CurrentUserId") is not null)
                {
                    jrl.UpdatedBy = (int)_session.GetInt32("CurrentUserId");
                }

                jrl.UpdatedDate = DateTime.Now;

                _context.Update(jrl);
                int result = await _context.SaveChangesAsync().ConfigureAwait(false);
                if (dto.Status == (int)Enquiry.Blazor.Enum.JournalStatus.ClientWithdraw || dto.Status == (int)Enquiry.Blazor.Enum.JournalStatus.Terminated)
                {
                    var message = "";
                    var project = await _context.Projects.Include(x => x.Clients).Where(x => x.ProjectId == projectId)
                            .Select(x => new
                            {
                                x.ProjectRef,
                                x.Clients.ClientName
                            }).FirstOrDefaultAsync();
                    IList<string> members = _slackConfig.JournalStatus.ToList();
                    if (dto.Status == (int)Enquiry.Blazor.Enum.JournalStatus.Terminated)
                    {
                        message = $"Reason for Terminated for the {project.ProjectRef}, {project.ClientName} enquire with Publication team and inform to your Superior";
                    }
                    else
                    {
                        message = $"Reason for Client Withdraw for the {project.ProjectRef}, {project.ClientName} enquire with Publication team and inform to your Superior";
                    }
                    foreach (var item in members)
                    {
                        await _slack.SendMessage(message, item);
                    }
                }
                return (true, new string[] { "Journal updated sucessfully" }, jrl);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        public async Task<(bool Succeeded, string[] Error, RegisteredClientDetailDto Client)> GetRegisteredClientDetailAsync(int enquiryId)
        {
            try
            {
                var project = await _context.Clients.Where(x => x.EnquiryId == enquiryId && x.IsActive == true)

                    .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).Include(x => x.ProgrammerEmployee)
                    .Include(x => x.TechTLEmployee).Include(x => x.ProgrammerTLEmployee)
                    .Include(x => x.Projects).ThenInclude(x => x.Payments)
                    .Include(x => x.Projects).ThenInclude(x => x.Phase).FirstOrDefaultAsync();

                var map = _mapper.Map<RegisteredClientDetailDto>(project);
                map.BDAName = project.BDAEmployee.EmployeeName;

                map.TechName = project.TechEmployee?.EmployeeName;
                map.TechTL = project.TechTLEmployee?.EmployeeName;
                map.IsTechTlActive = project.TechTLEmployee?.IsActive;
                map.IsTechNameActive = project.TechEmployee?.IsActive;

                map.ProName = project.ProgrammerEmployee?.EmployeeName;
                map.PgmTL = project.ProgrammerTLEmployee?.EmployeeName;
                map.IsPgmTlActive = project.ProgrammerTLEmployee?.IsActive;
                map.IsPgmNameActive = project.ProgrammerEmployee?.IsActive;

                return (true, new string[] { }, map);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        public async Task<(bool Succeeded, string[] Error, ProjectDetailDto Project)> GetProjectDetailAsync(int projectId)
        {
            try
            {
                var user = Int32.Parse(_session.GetInt32("CurrentUserId").ToString());
                var project = await _context.Projects.Where(x => x.ProjectId == projectId).Include(x => x.Payments)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees1)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees2)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees3)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees4)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees5)
                    .Include(x => x.Phase).ThenInclude(x => x.WorkStatus)
                    .Include(x => x.Phase).ThenInclude(x => x.PhaseHistory)
                    .Include(x => x.Phase).ThenInclude(x => x.PhaseHistory).ThenInclude(x => x.Employees)
                    .Include(x => x.Phase).ThenInclude(x => x.PhaseDemo)
                    .Include(x => x.Clients).ThenInclude(x => x.TechEmployee)
                    .Include(x => x.Clients).ThenInclude(x => x.TechTLEmployee)
                    .Include(x => x.Phase).ThenInclude(x => x.PhaseFiles)
                    .Include(x => x.Phase).ThenInclude(x => x.Plagiarism).ThenInclude(x=> x.PlagiarismRecipients).FirstOrDefaultAsync();

                var map = _mapper.Map<ProjectDetailDto>(project);
                if (project != null)
                {
                    map = _mapper.Map<ProjectDetailDto>(project);
                    map.EmployIdData = project.Phase.Select(id => new EmployIdData
                    {
                        EnquiryId = project.EnquiryId,
                        TechExpertId = id.TechExpert,
                        TechExpert1Id = id.TechExpert1,
                        TechExpert2Id = id.TechExpert2,
                        TechExpert3Id = id.TechExpert3,
                        ProgrammerId = id.Programmer,
                        Programmer1Id = id.Programmer1,
                        TechAssign = _context.PhaseHistory.Where(x => x.PhaseId == id.PhaseId && x.EmpId == id.TechExpert).Any(x => x.Comments != null),
                        Tech1Assign = _context.PhaseHistory.Where(x => x.PhaseId == id.PhaseId && x.EmpId == id.TechExpert1).Any(x => x.Comments != null),
                        Tech2Assign = _context.PhaseHistory.Where(x => x.PhaseId == id.PhaseId && x.EmpId == id.TechExpert2).Any(x => x.Comments != null),
                        Tech3Assign = _context.PhaseHistory.Where(x => x.PhaseId == id.PhaseId && x.EmpId == id.TechExpert3).Any(x => x.Comments != null),
                        PgmAssign = _context.PhaseHistory.Where(x => x.PhaseId == id.PhaseId && x.EmpId == id.Programmer).Any(x => x.Comments != null),
                        Pgm1Assign = _context.PhaseHistory.Where(x => x.PhaseId == id.PhaseId && x.EmpId == id.Programmer1).Any(x => x.Comments != null),
                        Status = id.Status,
                        Priority = (user) switch
                        {
                            _ when id.TechExpert == user => id.TechPriority,
                            _ when id.TechExpert1 == user => id.TechPriority1,
                            _ when id.TechExpert2 == user => id.TechPriority2,
                            _ when id.TechExpert3 == user => id.TechPriority3,
                            _ when id.Programmer == user => id.ProgrammerPriority,
                            _ when id.Programmer1 == user => id.ProgrammerPriority1,
                            _ => null
                        },
                        WorkCountTech = id.TechExpert.HasValue ? GetEmployeesInProgressAsync(id.TechExpert.Value) : 0,
                        WorkCountTech1 = id.TechExpert1.HasValue ? GetEmployeesInProgressAsync(id.TechExpert1.Value) : 0,
                        WorkCountTech2 = id.TechExpert2.HasValue ? GetEmployeesInProgressAsync(id.TechExpert2.Value) : 0,
                        WorkCountTech3 = id.TechExpert3.HasValue ? GetEmployeesInProgressAsync(id.TechExpert3.Value) : 0,
                        WorkCountTech4 = id.Programmer.HasValue ? GetEmployeesInProgressAsync(id.Programmer.Value) : 0,
                        WorkCountTech5 = id.Programmer1.HasValue ? GetEmployeesInProgressAsync(id.Programmer1.Value) : 0,
                        TechName = _context.Employees.Where(e => e.EmpId == id.TechExpert).Select(e => e.EmployeeName).FirstOrDefault(),
                        TechName1 = _context.Employees.Where(e => e.EmpId == id.TechExpert1).Select(e => e.EmployeeName).FirstOrDefault(),
                        TechName2 = _context.Employees.Where(e => e.EmpId == id.TechExpert2).Select(e => e.EmployeeName).FirstOrDefault(),
                        TechName3 = _context.Employees.Where(e => e.EmpId == id.TechExpert3).Select(e => e.EmployeeName).FirstOrDefault(),
                        Programmer = _context.Employees.Where(e => e.EmpId == id.Programmer).Select(e => e.EmployeeName).FirstOrDefault(),
                        Programmer1 = _context.Employees.Where(e => e.EmpId == id.Programmer1).Select(e => e.EmployeeName).FirstOrDefault(),
                        TechStatus = id.TechStatus == true && id.TechExpert.HasValue && id.TechExpert == _session.GetInt32("CurrentUserId") ? true : false,
                        TechStatus1 = id.TechStatus1 == true && id.TechExpert1.HasValue && id.TechExpert1 == _session.GetInt32("CurrentUserId") ? true : false,
                        TechStatus2 = id.TechStatus2 == true && id.TechExpert2.HasValue && id.TechExpert2 == _session.GetInt32("CurrentUserId") ? true : false,
                        TechStatus3 = id.TechStatus3 == true && id.TechExpert3.HasValue && id.TechExpert3 == _session.GetInt32("CurrentUserId") ? true : false,
                        ProgrammerStatus = id.ProgrammerStatus == true && id.Programmer.HasValue && id.Programmer == _session.GetInt32("CurrentUserId") ? true : false,
                        ProgrammerStatus1 = id.ProgrammerStatus1 == true && id.Programmer1.HasValue && id.Programmer1 == _session.GetInt32("CurrentUserId") ? true : false,
                        TechTLStatus = id.TechTLStatus == false && id.TechTL.HasValue && id.TechTL == _session.GetInt32("CurrentUserId") ? true : false,
                        PgmTLStatus = id.PgmTLStatus == false && id.PgmTL.HasValue && id.PgmTL == _session.GetInt32("CurrentUserId") ? true : false,
                        TechTL = id.TechTL,
                        PgmTL = id.PgmTL,
                        TechTLStatus1 = id.TechTLStatus,
                        PgmTLStatus1 = id.PgmTLStatus,
                        TechStatusAny = ((id.TechStatus && id.TechExpert.HasValue) || (id.TechStatus1 && id.TechExpert1.HasValue)
                        || (id.TechStatus2 && id.TechExpert2.HasValue) || (id.TechStatus3 && id.TechExpert3.HasValue)) ? true : false,
                        PgmStatusAny = ((id.ProgrammerStatus && id.Programmer.HasValue) || (id.ProgrammerStatus1 && id.Programmer1.HasValue)) ? true : false,
                        IsOnDemo = id.PhaseDemo != null && id.PhaseDemo.Any(t => t.EmpId == _session.GetInt32("CurrentUserId") && t.Feedback == null),
                        DemoLink = id.PhaseDemo != null
                            ? id.PhaseDemo
                                .Where(t => t.EmpId == _session.GetInt32("CurrentUserId"))
                                .OrderBy(x => x.DemoId)
                                .Select(x => x.Link) // Selecting the link before taking the last or default
                                .LastOrDefault()
                            : string.Empty,
                        ManagerPriority = (1) switch
                        {
                            _ when id.TechPriority == 1 => id.TechPriority,
                            _ when id.TechPriority1 == 1 => id.TechPriority1,
                            _ when id.TechPriority2 == 1 => id.TechPriority2,
                            _ when id.TechPriority3 == 1 => id.TechPriority3,
                            _ when id.ProgrammerPriority == 1 => id.ProgrammerPriority,
                            _ when id.ProgrammerPriority1 == 1 => id.ProgrammerPriority1,
                            _ => null
                        },
                    }).ToList();
                    var phaseFiles = project.Phase.SelectMany(t => t.PhaseFiles.Where(x=> !x.IsPublication).Select(x => new PhaseFilesDto
                    {
                        FileName = x.FileName,
                        FilePath = x.FilePath,
                        PhaseFileId = x.PhaseFileId,
                        PhaseId = x.PhaseId,
                        IsPublication = x.IsPublication,
                        EmpId = x.EmpId
                    })).ToList();

                    var phaseFilesGrouped = phaseFiles.GroupBy(pf => pf.PhaseId).ToList();
                    map.PhasefileView = phaseFilesGrouped.Select(group => new PhasefileViewDto
                    {
                        IsPublication = group.FirstOrDefault()?.IsPublication,
                        PhaseId = group.Key,
                        ProposalDto = phaseFiles.Where(x => x.FilePath.Contains("Proposal_Manuscript_Thesis")).Select(x => new ProposalDto
                        {
                            EmpId = x.EmpId,
                            ProposalId = x.PhaseFileId,
                            Proposal = x.FileName,
                            ProposalPath = x.FilePath
                        }).ToList(),
                        VisoDto = phaseFiles.Where(x => x.FilePath.Contains("Viso")).Select(x => new VisoDto
                        {
                            EmpId = x.EmpId,
                            VisoId = x.PhaseFileId,
                            Viso = x.FileName,
                            VisoPath = x.FilePath
                        }).ToList(),
                        ReferencePaperDto = phaseFiles.Where(x => x.FilePath.Contains("ReferencePaper")).Select(x => new ReferencePaperDto
                        {
                            EmpId = x.EmpId,
                            ReferencePaperId = x.PhaseFileId,
                            ReferencePaper = x.FileName,
                            ReferencePaperPath = x.FilePath
                        }).ToList(),
                        OthersDto = phaseFiles.Where(x => x.FilePath.Contains("Others") && !x.FilePath.Contains("programming")).Select(x => new OthersDto
                        {
                            EmpId = x.EmpId,
                            OthersId = x.PhaseFileId,
                            Others = x.FileName,
                            OthersPath = x.FilePath
                        }).ToList(),
                        JournalCommentsDto = phaseFiles.Where(x => x.FilePath.Contains("journalComments")).Select(x => new JournalCommentsDto
                        {
                            EmpId = x.EmpId,
                            JournalCommentId = x.PhaseFileId,
                            JournalComment = x.FileName,
                            JournalCommentPath = x.FilePath
                        }).ToList()
                    }).ToList();

                }
                var lastPlagiarismEntries = project.Phase
                    .SelectMany(t => t.Plagiarism.Select(x => new
                    {
                        x.PhaseId,
                        x.PlagiarismId
                    }))
                    .GroupBy(x => x.PhaseId)
                    .Select(g => new
                    {
                        PhaseId = g.Key,
                        PlagiarismId = g.OrderByDescending(x => x.PlagiarismId).FirstOrDefault().PlagiarismId
                    })
                    .ToList();

                var lastPlagiarismRecipientIds = lastPlagiarismEntries.Select(p => p.PlagiarismId).ToList();
                var plagiarismRecipients = _context.PlagiarismRecipient
                    .Where(x => lastPlagiarismRecipientIds.Contains(x.PlagiarismId) && x.IsUploaded)
                    .ToList();
                var plagFiles = new List<PlagiarismfileView>();
                foreach (var plags in lastPlagiarismEntries)
                {
                    var recipients = plagiarismRecipients.Where(x => x.PlagiarismId == plags.PlagiarismId).ToList();
                    var plagFileViews = recipients.Select(x => new PlagiarismfileView
                    {
                        PlagiarismRecipientId = x.PlagiarismRecipientId,
                        PhaseId = plags.PhaseId,
                        PlagFileName = x.UploadedFileName.Contains(".docx") ? x.UploadedFileName : null,
                        PlagFilePath = x.UploadedFileName.Contains(".docx") ? x.UploadedFilePath : null,
                        AIFileName = !x.UploadedFileName.Contains(".docx") ? x.UploadedFileName : null,
                        AIFilePath = !x.UploadedFileName.Contains(".docx") ? x.UploadedFilePath : null,
                    }).ToList();

                    plagFiles.AddRange(plagFileViews);
                }

                map.PlagiarismfileView = plagFiles;

                var AssignedDate = project.Phase.Select(x => x.AssignedDate).LastOrDefault();
                var emailQuery = _context.Emails
                     .Where(x => x.ProjectId.Equals(projectId))
                     .Include(x => x.EmailAttachmentsFiles).Include(x => x.Projects)
                     .Include(x => x.Clients).AsQueryable(); 
                if ((_session.GetString("Dept") == Enum.Department.Tech.ToString() || _session.GetString("Dept") == Enum.Department.Programming.ToString()) && _session.GetString("Role") != Enum.Roles.Manager.ToString())
                {
                    emailQuery = emailQuery.Where(x => !x.Visibility && !x.IsPublication);
                }
                emailQuery = emailQuery.Where(x => !x.IsPublication);
                var role = _session.GetString("Role");
                var department = _session.GetString("Dept");
                var emailData = await emailQuery
                                .Select(x => new PhaseHistoryDto
                                {
                                    EmpName = (!string.IsNullOrEmpty(x.Projects.Clients.ClientName) && !x.IsSender)
                                    ? $"<span style='color: darkred;'>{x.Projects.Clients.ClientName}</span>"
                                    : (x.IsSender
                                        ? $"<span style='color: darkred;'>{x.ClientName}</span>"
                                        : "<span style='color: darkred;'>No Client Name</span>"),
                                    Comments = x.UpdatedMessage,
                                    CreatedDate = x.ReceivedDate,
                                    IsClient = true,
                                    EmailId = x.EmailId,
                                    EmailAttachmentDto = x.EmailAttachmentsFiles.Where(a => a.IsSelected &&
                                ((department == Enum.Department.Tech.ToString() && x.IsTechVisibility) ||
                                    (department == Enum.Department.Programming.ToString() && x.IsProgrammerVisibility) ||
                                    department == Enum.Department.BDA.ToString() || role == Enum.Roles.Manager.ToString()
                                )).Select(a => new EmailAttachmentDto
                                    {
                                        AttachmentFileId = a.EmailAttachmentId,
                                        AttachmentFilePath = a.AttachmentFilePath,
                                        AttachmentFileName = a.AttachmentFileName
                                    }).ToList(),
                                })
                                .ToListAsync();
                bool emailDataAdded = false;
                foreach (var item in map.PhaseDetailDto)
                {
                    var pHisList = new List<PhaseHistoryDto>();
                    if (!emailDataAdded)
                    {
                        pHisList.AddRange(emailData);
                        emailDataAdded = true; 
                    }
                    var pHistory = await _context.PhaseHistory.Where(x => x.PhaseId == item.PhaseId).ToListAsync();
                    var pDemo = await _context.PhaseDemo.Include(x => x.Employees).Where(x => x.PhaseId == item.PhaseId && !string.IsNullOrEmpty(x.Feedback)).ToListAsync();
                    if (pHistory.Any() || pDemo.Any())
                    {
                        
                        foreach (var item1 in pHistory)
                        {
                            var pHis = new PhaseHistoryDto()
                            {
                                Comments = item1.Comments,
                                TechExpertId = item1.Phase.TechExpert,
                                TechExpert1Id = item1.Phase.TechExpert1,
                                TechExpert2Id = item1.Phase.TechExpert2,
                                TechExpert3Id = item1.Phase.TechExpert3,
                                ProgrammerId = item1.Phase.Programmer,
                                Programmer1Id = item1.Phase.Programmer1,
                                EmpName = $"<span style='color: {(item1.Employees.DeptId == (int)Enquiry.Blazor.Enum.Department.Programming ? "#008080" : (item1.Employees.DeptId == (int)Enquiry.Blazor.Enum.Department.Tech ? "#00004B" : "black"))};'>" +
                                          $"{item1.Employees?.EmployeeName}</span>",
                                CreatedDate = item1.CreatedDate,
                                PhaseId = item1.Phase.PhaseId,
                                IsReassigned = item1.IsReassigned,
                                AssignedDate = AssignedDate <= item1.CreatedDate ? true:false,
                            };
                            pHisList.Add(pHis);
                        };
                        foreach (var item2 in pDemo)
                        {
                            var pDem = new PhaseHistoryDto()
                            {
                                Comments = item2.Feedback,
                                EmpName = item2.IsClient
                                        ? "Client": $"<span style='color: {(item2.Employees.DeptId == (int)Enquiry.Blazor.Enum.Department.Programming ? "#008080" : (item2.Employees.DeptId == (int)Enquiry.Blazor.Enum.Department.Tech ? "#00004B" : "black"))};'>" +
                                          $"{item2.Employees?.EmployeeName}</span> (<span style='color:red;'>Demo</span>)",
                                CreatedDate = item2.UpdatedDate,
                                PhaseId = item2.Phase.PhaseId,
                                AssignedDate = AssignedDate <= item2.CreatedDate ? true : false,
                            };
                            pHisList.Add(pDem);
                        };

                        map.PhaseHistoryDto.AddRange(pHisList.OrderBy(x => x.CreatedDate));
                        item.TechExpertId = pHisList.First().TechExpertId;
                        item.TechExpert1Id = pHisList.First().TechExpert1Id;
                        item.TechExpert2Id = pHisList.First().TechExpert2Id;
                        item.TechExpert3Id = pHisList.First().TechExpert3Id;
                        item.ProgrammerId = pHisList.First().ProgrammerId;
                        item.Programmer1Id = pHisList.First().Programmer1Id;
                    };
                }
                map.TechTlIsActive = project.Clients.TechTLEmployee?.IsActive;
                map.TechIsActive = project.Clients.TechEmployee?.IsActive;
                var lastPhase = project.Phase.LastOrDefault().PhaseId;
                var plagId = _context.Plagiarism.Where(x => x.PhaseId == lastPhase).OrderBy(x=> x.PlagiarismId).Select(x => x.PlagiarismId).LastOrDefault();
                bool isPlag = true;
                if (plagId != 0)
                {
                    isPlag = _context.PlagiarismRecipient.Where(x => x.PlagiarismId == plagId).OrderBy(x=> x.PlagiarismRecipientId).Select(x => x.IsUploaded).LastOrDefault();
                }
                map.IsPlag = isPlag;
                return (true, new string[] { }, map);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        public async Task<(bool Succeeded, string[] Error, EditPhaseDto Phase)> GetPhaseAsync(int phaseId)
        {
            try
            {
                var result = await _context.Phase.FindAsync(phaseId);
                var map = _mapper.Map<EditPhaseDto>(result);
                return (true, new string[] { }, map);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        public async Task<(bool Succeeded, string[] Error, Phase Phase)> GetPhaseForFileUploadAsync(int phaseId)
        {
            try
            {
                var result = await _context.Phase.Where(x => x.PhaseId == phaseId).Include(x => x.Projects)
                    .Include(x => x.Projects).ThenInclude(x => x.Clients).FirstOrDefaultAsync();
                return (true, new string[] { }, result);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        //public async Task<(bool Succeeded, string[] Error, Phase Phase)> UpdatePhaseOnHoldAsync(EditPhaseOnHoldDto phaseDto, int phaseId)
        //{
        //    try
        //    {
        //        var phase = await _context.Phase.Include(x=>x.Projects).Include(x => x.Projects).ThenInclude(x=>x.Clients)
        //            .Where(x=>x.PhaseId == phaseId).FirstOrDefaultAsync();
        //        var superiorId = await (from Phase in _context.Phase
        //                                join emp in _context.Employees
        //                                on Phase.TechExpert equals emp.EmpId
        //                                where Phase.PhaseId == phaseId
        //                                select emp.SuperiorId).FirstOrDefaultAsync();
        //        var phaseCommnet = new PhaseHistory()
        //        {
        //            PhaseId = phaseId,
        //            Comments = phaseDto.Comment,
        //            EmpId = (int)_session.GetInt32("CurrentUserId")
        //        };
        //        await _context.AddAsync(phaseCommnet);
        //        phase.Comment = $"{phaseDto.Comment} *{_session.GetString("EmployeeName")}* ";
        //        phase.NextAppoinment = phaseDto.NextAppoinment;
        //        //phase.Status = (int)Enum.WorkStatus.Hold;

        //        if (phaseDto.IsCompleted)
        //        {
        //            phase.Status = (int)Enum.WorkStatus.Completed;
        //        }
        //        if (phaseDto.IsCompletedphaseqc)
        //        {
        //            if (phase.TechExpert.HasValue && phase.TechExpert.Value == (int)_session.GetInt32("CurrentUserId"))
        //                 phase.TechStatus = true;
        //            else if (phase.TechExpert1.HasValue && phase.TechExpert1.Value == (int)_session.GetInt32("CurrentUserId"))
        //                phase.TechStatus1 = true;
        //            else if(phase.TechExpert2.HasValue && phase.TechExpert2.Value == (int)_session.GetInt32("CurrentUserId"))
        //                phase.TechStatus2 = true;
        //            else if(phase.TechExpert3.HasValue && phase.TechExpert3.Value == (int)_session.GetInt32("CurrentUserId"))
        //                phase.TechStatus3 = true;
        //            else if(phase.Programmer.HasValue && phase.Programmer.Value == (int)_session.GetInt32("CurrentUserId"))
        //                phase.ProgrammerStatus = true;
        //            else if(phase.Programmer1.HasValue && phase.Programmer1.Value == (int)_session.GetInt32("CurrentUserId"))
        //                phase.ProgrammerStatus1 = true;

        //            Dictionary<string, Dictionary<int?, bool>> fieldStatusMap = new Dictionary<string, Dictionary<int?, bool>>();

        //            // Add mappings for TechExpert, TechExpert1, TechExpert2, TechExpert3, Programmer, and Programmer1
        //            if (phase.TechExpert != null) 
        //                fieldStatusMap.Add("TechExpert", new Dictionary<int?, bool> { { phase.TechExpert, phase.TechStatus } });
        //            if (phase.TechExpert1 != null) 
        //                fieldStatusMap.Add("TechExpert1", new Dictionary<int?, bool> { { phase.TechExpert1, phase.TechStatus1 } });
        //            if (phase.TechExpert2 != null) 
        //                fieldStatusMap.Add("TechExpert2", new Dictionary<int?, bool> { { phase.TechExpert2, phase.TechStatus2 } });
        //            if (phase.TechExpert3 != null) 
        //                fieldStatusMap.Add("TechExpert3", new Dictionary<int?, bool> { { phase.TechExpert3, phase.TechStatus3 } });
        //            if (phase.Programmer != null) 
        //                fieldStatusMap.Add("Programmer", new Dictionary<int?, bool> { { phase.Programmer, phase.ProgrammerStatus } });
        //            if (phase.Programmer1 != null) 
        //                fieldStatusMap.Add("Programmer1", new Dictionary<int?, bool> { { phase.Programmer1, phase.ProgrammerStatus1 } });

        //            // Check if all fields have their corresponding status as true
        //            bool manageStatus = fieldStatusMap.All(kv => kv.Value.All(innerKv => innerKv.Key.HasValue && innerKv.Key.Value != 0 && innerKv.Value));

        //            if (manageStatus)
        //            {
        //                var techOrPgmEmployees = await _context.Phase.Include(x => x.Employees).Include(x => x.Employees1).Include(x => x.Employees2)
        //                    .Include(x => x.Employees3).Include(x => x.Employees4).Include(x => x.Employees5).Where(x => x.PhaseId == phaseId).ToListAsync();

        //                foreach (var item in techOrPgmEmployees)
        //                {
        //                    var experts = new List<(bool Status, int? Id)>
        //                    {
        //                        (item.TechStatus, item.TechExpert),
        //                        (item.TechStatus1, item.TechExpert1),
        //                        (item.TechStatus2, item.TechExpert2),
        //                        (item.TechStatus3, item.TechExpert3),
        //                        (item.ProgrammerStatus, item.Programmer),
        //                        (item.ProgrammerStatus1, item.Programmer1)
        //                    };

        //                    foreach (var expert in experts)
        //                    {
        //                        if (expert.Id.HasValue)
        //                        {
        //                            var employee = await _context.Employees
        //                                .Include(x => x.Roles)
        //                                .Include(x => x.Department)
        //                                .FirstOrDefaultAsync(x => x.EmpId == expert.Id.Value);

        //                            if (employee != null)
        //                            {
        //                                if (employee.Roles.RoleName == Enum.Roles.Executive.ToString())
        //                                {
        //                                    if (employee.Department.DeptName == Enum.Department.Tech.ToString())
        //                                    {
        //                                        phase.TechTLstatus = true;
        //                                        string message = $"Completed: {employee.EmployeeName} updated the {phase.PhaseName} of {phase.Projects.Clients.ClientName}{phase.Projects.ProjectRef.Substring(7)}";
        //                                        var superior = await _context.Employees.FirstOrDefaultAsync(x => x.EmpId == employee.SuperiorId);
        //                                        if (superior != null)
        //                                        {
        //                                            await _slack.SendMessage(message, superior.MemberId);
        //                                        }
        //                                    }
        //                                    if (employee.Department.DeptName == Enum.Department.Programming.ToString())
        //                                    {
        //                                        phase.PgmTLstatus = true;
        //                                        string message = $"Completed: {employee.EmployeeName} updated the {phase.PhaseName} of {phase.Projects.Clients.ClientName}{phase.Projects.ProjectRef.Substring(7)}";
        //                                        var superior = await _context.Employees.FirstOrDefaultAsync(x => x.EmpId == employee.SuperiorId);
        //                                        if (superior != null)
        //                                        {
        //                                            await _slack.SendMessage(message, superior.MemberId);
        //                                        }
        //                                    }
        //                                }
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //        }

        //        //want to do this portion
        //        if (phaseDto.IsCompletedphasbyTechTL || phaseDto.IsCompletedphasbyPgmTL)
        //        {
        //            if (superiorId.HasValue && superiorId.Value == (int)_session.GetInt32("CurrentUserId"))
        //                phase.TechTLstatus = true;
        //            Dictionary<string, Dictionary<int?, bool>> fieldStatusMap = new Dictionary<string, Dictionary<int?, bool>>();

        //            // Add mappings for TechExpert, TechExpert1, TechExpert2, TechExpert3, Programmer, and Programmer1
        //            if (phase.TechExpert != null)
        //                fieldStatusMap.Add("TechExpert", new Dictionary<int?, bool> { { phase.TechExpert, phase.TechStatus } });
        //            if (phase.TechExpert1 != null)
        //                fieldStatusMap.Add("TechExpert1", new Dictionary<int?, bool> { { phase.TechExpert1, phase.TechStatus1 } });
        //            if (phase.TechExpert2 != null)
        //                fieldStatusMap.Add("TechExpert2", new Dictionary<int?, bool> { { phase.TechExpert2, phase.TechStatus2 } });
        //            if (phase.TechExpert3 != null)
        //                fieldStatusMap.Add("TechExpert3", new Dictionary<int?, bool> { { phase.TechExpert3, phase.TechStatus3 } });
        //            if (phase.Programmer != null)
        //                fieldStatusMap.Add("Programmer", new Dictionary<int?, bool> { { phase.Programmer, phase.ProgrammerStatus } });
        //            if (phase.Programmer1 != null)
        //                fieldStatusMap.Add("Programmer1", new Dictionary<int?, bool> { { phase.Programmer1, phase.ProgrammerStatus1 } });
        //            if (superiorId != null)
        //                fieldStatusMap.Add("TechTl", new Dictionary<int?, bool> { { superiorId, phase.TechTLstatus } });
        //            if (superiorId != null)
        //                fieldStatusMap.Add("PgmTl", new Dictionary<int?, bool> { { superiorId, phase.PgmTLstatus } });
        //            bool manageStatus = fieldStatusMap.All(kv => kv.Value.All(innerKv => innerKv.Key.HasValue && innerKv.Key.Value != 0 && innerKv.Value));

        //            if (manageStatus)
        //            {
        //                if (phaseDto.IsPgmTL &&)
        //                {
        //                    phase.Status = (int)Enum.WorkStatus.Assigned;
        //                }
        //                var employee = await _context.Employees.FindAsync((int)_session.GetInt32("CurrentUserId"));
        //                string message = $"Completed: {employee.EmployeeName} updated the {phase.PhaseName} of {phase.Projects.Clients.ClientName}{phase.Projects.ProjectRef.Substring(7)}";
        //                await _slack.SendMessage(message, "U03E0DFQEGG");
        //            }
        //        }
        //        if (phaseDto.IsCompletedphase)
        //        {
        //            phase.Status = (int)Enum.WorkStatus.Hold;
        //            phase.TechScore = phaseDto.TechScore;
        //            phase.TechScore1 = phaseDto.TechScore1;
        //            phase.TechScore2 = phaseDto.TechScore2;
        //            phase.TechScore3 = phaseDto.TechScore3;
        //            phase.ProgrammerScore = phaseDto.ProgrammerScore;
        //            phase.ProgrammerScore1 = phaseDto.ProgrammerScore1;
        //        }
        //        _context.Update(phase);
        //        int result = await _context.SaveChangesAsync().ConfigureAwait(false);
        //        return (true, new string[] { "Project updated sucessfully" }, phase);
        //    }
        //    catch (Exception ex)
        //    {

        //        return (false, new string[] { ex.Message }, null);
        //    }

        //}

        public async Task<(bool Succeeded, string[] Error, Phase Phase)> UpdatePhaseOnHoldAsync(EditPhaseOnHoldDto phaseDto, int phaseId)
        {
            try
            {
                var phase = await _context.Phase.Include(x => x.Employees).Include(x => x.Employees1).Include(x => x.Employees2).Include(x => x.Employees3)
                    .Include(x => x.Employees4).Include(x => x.Employees5).Include(x => x.Projects).Include(x => x.Projects).ThenInclude(x => x.Clients)
                    .Where(x => x.PhaseId == phaseId).FirstOrDefaultAsync();

                var phaseCommnet = new PhaseHistory()
                {
                    PhaseId = phaseId,
                    Comments = phaseDto.Comment,
                    EmpId = (int)_session.GetInt32("CurrentUserId")
                };
                await _context.AddAsync(phaseCommnet);
                phase.Comment = $"{phaseDto.Comment} *{_session.GetString("EmployeeName")}* ";
                phase.NextAppoinment = phaseDto.NextAppoinment;
                //phase.Status = (int)Enum.WorkStatus.Hold;

                if (phaseDto.IsCompleted)
                {
                    var newPhase = new Phase
                    {
                        ProjectId = phase.ProjectId,
                        PhaseName = "Completed",
                        AssignedDate = DateTime.Now,
                        Status = (int)Enum.WorkStatus.Completed
                    };
                    _context.Phase.Add(newPhase);
                    _context.SaveChanges();
                }
                if (phaseDto.IsCompletedphaseqc)
                {
                    if (phase.TechExpert.HasValue && phase.TechExpert.Value == (int)_session.GetInt32("CurrentUserId"))
                        phase.TechStatus = true;
                    else if (phase.TechExpert1.HasValue && phase.TechExpert1.Value == (int)_session.GetInt32("CurrentUserId"))
                        phase.TechStatus1 = true;
                    else if (phase.TechExpert2.HasValue && phase.TechExpert2.Value == (int)_session.GetInt32("CurrentUserId"))
                        phase.TechStatus2 = true;
                    else if (phase.TechExpert3.HasValue && phase.TechExpert3.Value == (int)_session.GetInt32("CurrentUserId"))
                        phase.TechStatus3 = true;
                    else if (phase.Programmer.HasValue && phase.Programmer.Value == (int)_session.GetInt32("CurrentUserId"))
                        phase.ProgrammerStatus = true;
                    else if (phase.Programmer1.HasValue && phase.Programmer1.Value == (int)_session.GetInt32("CurrentUserId"))
                        phase.ProgrammerStatus1 = true;

                    Dictionary<string, Dictionary<int?, bool>> fieldStatusMap = new Dictionary<string, Dictionary<int?, bool>>();

                    // Add mappings for TechExpert, TechExpert1, TechExpert2, TechExpert3, Programmer, and Programmer1
                    if (phase.TechExpert != null)
                        fieldStatusMap.Add("TechExpert", new Dictionary<int?, bool> { { phase.TechExpert, phase.TechStatus } });
                    if (phase.TechExpert1 != null)
                        fieldStatusMap.Add("TechExpert1", new Dictionary<int?, bool> { { phase.TechExpert1, phase.TechStatus1 } });
                    if (phase.TechExpert2 != null)
                        fieldStatusMap.Add("TechExpert2", new Dictionary<int?, bool> { { phase.TechExpert2, phase.TechStatus2 } });
                    if (phase.TechExpert3 != null)
                        fieldStatusMap.Add("TechExpert3", new Dictionary<int?, bool> { { phase.TechExpert3, phase.TechStatus3 } });


                    // Check if all fields have their corresponding status as true
                    bool techStatus = fieldStatusMap.All(kv => kv.Value.All(innerKv => innerKv.Key.HasValue && innerKv.Key.Value != 0 && innerKv.Value));

                    fieldStatusMap.Clear();

                    if (phase.Programmer != null)
                        fieldStatusMap.Add("Programmer", new Dictionary<int?, bool> { { phase.Programmer, phase.ProgrammerStatus } });
                    if (phase.Programmer1 != null)
                        fieldStatusMap.Add("Programmer1", new Dictionary<int?, bool> { { phase.Programmer1, phase.ProgrammerStatus1 } });

                    bool pgmStatus = fieldStatusMap.All(kv => kv.Value.All(innerKv => innerKv.Key.HasValue && innerKv.Key.Value != 0 && innerKv.Value));

                    if (techStatus && !phase.TechTL.HasValue)
                    {
                        var experts = new List<(bool Status, int? Id, int? role)>
                            {
                                (phase.TechStatus, phase.TechExpert, phase.Employees != null ? phase.Employees.RoleId : null),
                                (phase.TechStatus1, phase.TechExpert1, phase.Employees1 != null ? phase.Employees1.RoleId : null),
                                (phase.TechStatus2, phase.TechExpert2, phase.Employees2 != null ? phase.Employees2.RoleId : null),
                                (phase.TechStatus3, phase.TechExpert3, phase.Employees3 != null ? phase.Employees3.RoleId : null)
                            };

                        foreach (var expert in experts)
                        {
                            if (expert.Id.HasValue)
                            {
                                var employee = await _context.Employees
                                    .Include(x => x.Roles)
                                    .Include(x => x.Department)
                                    .FirstOrDefaultAsync(x => x.EmpId == expert.Id.Value);

                                if (employee != null)
                                {
                                    if (employee.Roles.RoleName == Enum.Roles.Executive.ToString())
                                    {
                                        phase.TechTL = employee.SuperiorId;
                                        string message = $"Completed: {employee.EmployeeName} updated the {phase.PhaseName} of {phase.Projects.Clients.ClientName}{phase.Projects.ProjectRef.Substring(7)}";
                                        var superior = await _context.Employees.FirstOrDefaultAsync(x => x.EmpId == employee.SuperiorId);
                                        if (superior != null)
                                        {
                                            await _slack.SendMessage(message, superior.MemberId);
                                        }
                                    }
                                    bool isExecutive = experts.Any(x => x.role == (int)Enum.Roles.Executive);
                                    if (employee.Roles.RoleName == EnumerationDescription.GetDescription(Enum.Roles.TeamLead) && !isExecutive)
                                    {
                                        phase.TechTL = employee.SuperiorId;
                                        phase.TechTLStatus = true;
                                        string message = $"Completed: {employee.EmployeeName} updated the {phase.PhaseName} of {phase.Projects.Clients.ClientName}{phase.Projects.ProjectRef.Substring(7)}";
                                        var superior = await _context.Employees.FirstOrDefaultAsync(x => x.EmpId == employee.SuperiorId);
                                        if (superior != null)
                                        {
                                            await _slack.SendMessage(message, superior.MemberId);
                                        }
                                        if (techStatus && pgmStatus) phase.Status = (int)Enum.WorkStatus.Assigned;
                                    }
                                }
                            }
                        }
                    }

                    if (pgmStatus && !phase.PgmTL.HasValue)
                    {
                        var pgms = new List<(bool Status, int? Id, int? role)>
                            {
                                (phase.ProgrammerStatus, phase.Programmer, phase.Employees4 != null ? phase.Employees4.RoleId : null),
                                (phase.ProgrammerStatus1, phase.Programmer1, phase.Employees5 != null ? phase.Employees5.RoleId : null)
                            };

                        foreach (var pgm in pgms)
                        {
                            if (pgm.Id.HasValue)
                            {
                                var employee = await _context.Employees
                                    .Include(x => x.Roles)
                                    .Include(x => x.Department)
                                    .FirstOrDefaultAsync(x => x.EmpId == pgm.Id.Value);

                                if (employee != null)
                                {
                                    if (employee.Roles.RoleName == Enum.Roles.Executive.ToString())
                                    {
                                        phase.PgmTL = employee.SuperiorId;
                                        string message = $"Phase Completed: {employee.EmployeeName} updated the {phase.PhaseName} of {phase.Projects.Clients.ClientName}{phase.Projects.ProjectRef.Substring(7)}";
                                        var superior = await _context.Employees.FirstOrDefaultAsync(x => x.EmpId == employee.SuperiorId);
                                        if (superior != null)
                                        {
                                            await _slack.SendMessage(message, superior.MemberId);
                                        }
                                    }
                                    bool isExecutive = pgms.Any(x => x.role == (int)Enum.Roles.Executive);
                                    if (employee.Roles.RoleName == EnumerationDescription.GetDescription(Enum.Roles.TeamLead) && !isExecutive)
                                    {
                                        phase.PgmTL = employee.SuperiorId;
                                        phase.PgmTLStatus = true;
                                        string message = $"Phase Completed: {employee.EmployeeName} updated the {phase.PhaseName} of {phase.Projects.Clients.ClientName}{phase.Projects.ProjectRef.Substring(7)}";
                                        var superior = await _context.Employees.FirstOrDefaultAsync(x => x.EmpId == employee.SuperiorId);
                                        if (superior != null)
                                        {
                                            await _slack.SendMessage(message, superior.MemberId);
                                        }
                                        if (techStatus && pgmStatus) phase.Status = (int)Enum.WorkStatus.Assigned;
                                    }
                                }
                            }
                        }
                    }
                }
                if (phaseDto.IsCompletedphasbyTechTL || phaseDto.IsCompletedphasbyPgmTL)
                {
                    if (phase.TechTL.HasValue && phase.TechTL.Value == (int)_session.GetInt32("CurrentUserId"))
                        phase.TechTLStatus = true;
                    if (phase.PgmTL.HasValue && phase.PgmTL.Value == (int)_session.GetInt32("CurrentUserId"))
                        phase.PgmTLStatus = true;

                    Dictionary<string, Dictionary<int?, bool>> fieldStatusMap = new Dictionary<string, Dictionary<int?, bool>>();
                    if (phase.TechTL != null)
                        fieldStatusMap.Add("TechExpert", new Dictionary<int?, bool> { { phase.TechTL, phase.TechTLStatus } });
                    if (phase.PgmTL != null)
                        fieldStatusMap.Add("TechExpert1", new Dictionary<int?, bool> { { phase.PgmTL, phase.PgmTLStatus } });
                    bool manageStatus = fieldStatusMap.All(kv => kv.Value.All(innerKv => innerKv.Key.HasValue && innerKv.Key.Value != 0 && innerKv.Value));
                    if (manageStatus)
                    {
                        var tls = new List<(bool Status, int? Id)>
                            {
                                (phase.TechTLStatus, phase.TechTL),
                                (phase.PgmTLStatus, phase.PgmTL),
                            };

                        foreach (var expert in tls)
                        {
                            if (expert.Id.HasValue)
                            {
                                var employee = await _context.Employees
                                    .Include(x => x.Roles)
                                    .Include(x => x.Department)
                                    .FirstOrDefaultAsync(x => x.EmpId == expert.Id.Value);

                                if (employee != null)
                                {
                                    if (employee.Roles.RoleName == EnumerationDescription.GetDescription(Enum.Roles.TeamLead))
                                    {
                                        if (employee.Department.DeptName == Enum.Department.Tech.ToString())
                                        {
                                            string message = $"Phase Completed: {employee.EmployeeName} updated the {phase.PhaseName} of {phase.Projects.Clients.ClientName}{phase.Projects.ProjectRef.Substring(7)}";
                                            var superior = await _context.Employees.FirstOrDefaultAsync(x => x.EmpId == employee.SuperiorId);
                                            if (superior != null)
                                            {
                                                await _slack.SendMessage(message, superior.MemberId);
                                            }
                                        }
                                        if (employee.Department.DeptName == Enum.Department.Programming.ToString())
                                        {
                                            string message = $"Phase Completed: {employee.EmployeeName} updated the {phase.PhaseName} of {phase.Projects.Clients.ClientName}{phase.Projects.ProjectRef.Substring(7)}";
                                            var superior = await _context.Employees.FirstOrDefaultAsync(x => x.EmpId == employee.SuperiorId);
                                            if (superior != null)
                                            {
                                                await _slack.SendMessage(message, superior.MemberId);
                                            }
                                        }
                                    }
                                }
                            }
                            if (manageStatus)
                                phase.Status = (int)Enum.WorkStatus.Assigned;
                        }
                    }
                }
                if (phaseDto.IsCompletedphase)
                {
                    phase.Status = (int)Enum.WorkStatus.Hold;
                    phase.TechScore = phaseDto.TechScore;
                    phase.TechScore1 = phaseDto.TechScore1;
                    phase.TechScore2 = phaseDto.TechScore2;
                    phase.TechScore3 = phaseDto.TechScore3;
                    phase.ProgrammerScore = phaseDto.ProgrammerScore;
                    phase.ProgrammerScore1 = phaseDto.ProgrammerScore1;
                    if (phaseDto.IsPublication)
                    {
                        var lastPublication = _context.Phase
                            .Where(x => x.ProjectId == phase.ProjectId && x.Status == (int)Enquiry.Blazor.Enum.WorkStatus.Publication)
                            .OrderBy(x => x.PhaseId)
                            .LastOrDefault();

                        var newPhase = new Phase
                        {
                            ProjectId = lastPublication.ProjectId,
                            PhaseName = lastPublication.PhaseName,
                            AssignedDate = DateTime.Now,
                            Status = (int)Enum.WorkStatus.Publication,
                            DeadLine = lastPublication.DeadLine,
                        };
                        //var phaseStatus = _context.PhaseStatus.Where(x => x.PhaseName == phase.PhaseName).Select(x => x.SkipPublication).FirstOrDefault();
                        if (!phaseDto.IsSelectFile)
                        {
                            newPhase.IsPublicationApproval = true;
                            IList<string> members = _slackConfig.PublicationApproval.ToList();
                            string message = $"The project with ID {phase.Projects.ProjectRef} and client {phase.Projects.Clients.ClientName} needs to begin the publication process. Kindly review the manuscript on the publication approval page of our portal.";
                            foreach (var item in members)
                            {
                                await _slack.SendMessage(message, item);
                            }
                            _context.Phase.Add(newPhase);
                            _context.SaveChanges();
                        }
                        else if (phaseDto.IsSelectFile && phaseDto.selectedTechFilesForPub.Any())
                        {                           
                            IList<string> members = _slackConfig.PublicationFileUpload.ToList();
                            string message = $"Production Manager has uploaded the approved manuscript for Project ID {phase.Projects.ProjectRef} and Client {phase.Projects.Clients.ClientName}. Please proceed with initiating the publication process.";
                            foreach (var item in members)
                            {
                                await _slack.SendMessage(message, item);
                            }
                            _context.Phase.Add(newPhase);
                            _context.SaveChanges();
                            await UpdateFileToPublication(phaseDto.selectedTechFilesForPub, newPhase.PhaseId);
                        }
                        else
                        {
                            _context.Phase.Add(newPhase);
                            _context.SaveChanges();
                        }
                    }
                }
                
                if (phaseDto.IsCompletedphaseToHold)
                {
                    phase.Status = (int)Enum.WorkStatus.Hold;
                }
                _context.Update(phase);
                int result = await _context.SaveChangesAsync().ConfigureAwait(false);
                return (true, new string[] { "Project updated sucessfully" }, phase);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }
        public async Task UpdateFileToPublication(List<int> selectedFileIds,int phaseId)
        {
            try
            {
                var filesToCopy = await _context.PhaseFiles
                    .Where(f => selectedFileIds.Contains(f.PhaseFileId))
                    .ToListAsync();
                var userId = Int32.Parse(_session.GetInt32("CurrentUserId").ToString());
                var newPhaseFiles = new List<PhaseFiles>();
                foreach (var file in filesToCopy)
                {
                    var newFile = new PhaseFiles
                    {
                        EmpId = userId,
                        FileName = file.FileName,
                        PhaseId = phaseId,
                        FilePath = file.FilePath,
                        IsPublication = true,
                        IsJournalComment = file.IsJournalComment,
                    };
                    newPhaseFiles.Add(newFile);
                }

                await _context.PhaseFiles.AddRangeAsync(newPhaseFiles);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while updating files to publication: {ex.Message}");
                throw;
            }
        }

        public async Task<(bool Succeeded, string[] Error, Phase Phase)> CreatePhaseDemoAsync(int phaseId, PhaseDemoDto demo)
        {
            try
            {
                //if(_context.PhaseDemo.Any(x=>x.PhaseId == phaseId && x.Link == demo.Link)) return (false, new string[] { "Link must be unique" }, null);
                var loginEmpId = (int)_session.GetInt32("CurrentUserId");
                var pDemo = new List<Models.PhaseDemo>();

                var experts = new List<(bool IsChecked, int? Id)>
                {
                    (demo.TechExpertChecked, demo.TechExpertId),
                    (demo.TechExpert1Checked, demo.TechExpert1Id),
                    (demo.TechExpert2Checked, demo.TechExpert2Id),
                    (demo.TechExpert3Checked, demo.TechExpert3Id),
                    (demo.ProgrammerChecked, demo.ProgrammerId),
                    (demo.Programmer1Checked, demo.Programmer1Id)
                };

                var loginEmpIdExists = await _context.PhaseDemo
                        .Include(x => x.Employees)
                        .Include(x => x.Phase)
                        .FirstOrDefaultAsync(x => x.PhaseId == phaseId && x.EmpId == loginEmpId && !x.IsDemoAgain && x.Link == demo.Link);

                if (loginEmpIdExists == null) experts.Add((true, loginEmpId));

                foreach (var (isChecked, id) in experts)
                {
                    if (!id.HasValue) continue;

                    var existingEntry = await _context.PhaseDemo
                        .Include(x => x.Employees)
                        .Include(x => x.Phase)
                        .FirstOrDefaultAsync(x => x.PhaseId == phaseId && x.EmpId == id.Value && !x.IsDemoAgain && x.Link == demo.Link);

                    if (existingEntry != null)
                    {
                        if (!isChecked)
                        {
                            _context.Remove(existingEntry);
                            await SaveChangesAndNotifyRemoval(existingEntry);
                        }
                    }
                    else if (isChecked)
                    {
                        pDemo.Add(new Models.PhaseDemo
                        {
                            PhaseId = phaseId,
                            EmpId = id.Value,
                            Link = demo.Link
                        });
                    }
                }

                if (!experts.Any(x => x.Id.HasValue && x.IsChecked))
                {
                    var existingEntry = await _context.PhaseDemo
                        .Where(x => x.PhaseId == phaseId && x.Link == demo.Link).ToListAsync();
                    if (existingEntry.Any())
                    {
                        _context.RemoveRange(existingEntry);
                        await _context.SaveChangesAsync();
                    }
                }

                if (pDemo.Any())
                {
                    await _context.AddRangeAsync(pDemo);
                    if (await _context.SaveChangesAsync() > 0)
                    {
                        foreach (var item in pDemo)
                        {
                            var employee = await _context.PhaseDemo
                                .Include(x => x.Employees)
                                .Include(x => x.Phase)
                                .Include(x => x.Phase).ThenInclude(x => x.Projects)
                                .Include(x => x.Phase).ThenInclude(x => x.Projects).ThenInclude(x => x.Clients)
                                .FirstOrDefaultAsync(x => x.PhaseId == item.PhaseId && x.EmpId == item.EmpId);

                            if (employee != null && employee.EmpId != (int)_session.GetInt32("CurrentUserId"))
                            {
                                // Split the link by spaces
                                string[] splitLink = item.Link.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                                string part1 = splitLink[0];
                                // Check if the split array contains at least two elements
                                if (splitLink.Length >= 2)
                                {
                                    string part2 = splitLink[1];

                                    await _slack.SendMessage(
                                        @$"You are requested for the demo of {employee.Phase.Projects.Clients.ClientName}-{employee.Phase.Projects.ProjectRef.Substring(7)}" +
                                        @$" ({employee.Phase.PhaseName}) <{part1}> {part2}",
                                        employee.Employees.MemberId);
                                }
                                else
                                {
                                    // Handle cases where splitLink does not have enough elements
                                    await _slack.SendMessage(
                                        @$"You are requested for the demo of {employee.Phase.Projects.Clients.ClientName}-{employee.Phase.Projects.ProjectRef.Substring(7)}" +
                                        @$" ({employee.Phase.PhaseName}) <{part1}>",
                                        employee.Employees.MemberId);
                                }
                            }
                        }
                    }
                }
                return (true, new string[] { "Project updated successfully" }, null);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        private async Task SaveChangesAndNotifyRemoval(Models.PhaseDemo checkEmployeeForDemo)
        {
            if (await _context.SaveChangesAsync() > 0)
            {
                await _slack.SendMessage(
                    $"You are removed from the demo link of {checkEmployeeForDemo.Link} on phase {checkEmployeeForDemo.Phase.PhaseName}",
                    checkEmployeeForDemo.Employees.MemberId);
            }
        }

        public async Task<(bool Succeeded, string[] Error, EditPhaseOnHoldDto Phase)> EditProjectOnHoldFormAsync(int phaseId)
        {
            try
            {
                var checkForPgm = _context.Phase.Where(x => x.PhaseId == phaseId && (x.TechExpert == null
                || x.TechExpert1 == null || x.TechExpert2 == null || x.TechExpert3 == null)).OrderBy(x => x.ProjectId).LastOrDefault();
                var projectId = _context.Phase.Where(x => x.PhaseId == phaseId).Select(x => x.ProjectId).FirstOrDefault();
                var EmpId = Int32.Parse(_session.GetInt32("CurrentUserId").ToString());
                var lastPublication = _context.Phase.Where(x => x.ProjectId == projectId
                && x.Status == (int)Enquiry.Blazor.Enum.WorkStatus.Publication).OrderBy(x => x.PhaseId).LastOrDefault() != null;
                var phase = await _context.Phase.Include(x => x.Employees).Include(x => x.Employees1)
                    .Include(x => x.Employees2).Include(x => x.Employees3).Include(x => x.Employees4).Include(x => x.Employees5).Include(x=> x.WorkStatus)
                    .Where(x => x.PhaseId == phaseId).Select(x => new EditPhaseOnHoldDto()
                    {
                        //Comment = x.Comment,
                        NextAppoinment = x.NextAppoinment,
                        TechExpertId = x.TechExpert,
                        TechExpert1Id = x.TechExpert1,
                        TechExpert2Id = x.TechExpert2,
                        TechExpert3Id = x.TechExpert3,
                        TechExpert = x.TechExpert.HasValue ? x.Employees.EmployeeName : string.Empty,
                        TechExpert1 = x.TechExpert1.HasValue ? x.Employees1.EmployeeName : string.Empty,
                        TechExpert2 = x.TechExpert2.HasValue ? x.Employees2.EmployeeName : string.Empty,
                        TechExpert3 = x.TechExpert3.HasValue ? x.Employees3.EmployeeName : string.Empty,
                        Programmer = x.Programmer.HasValue ? x.Employees4.EmployeeName : string.Empty,
                        Programmer1 = x.Programmer1.HasValue ? x.Employees5.EmployeeName : string.Empty,
                        TechScore = x.TechExpert.HasValue ? x.TechScore : null,
                        TechScore1 = x.TechExpert1.HasValue ? x.TechScore1 : null,
                        TechScore2 = x.TechExpert2.HasValue ? x.TechScore2 : null,
                        TechScore3 = x.TechExpert3.HasValue ? x.TechScore3 : null,
                        ProgrammerScore = x.Programmer.HasValue ? x.ProgrammerScore : null,
                        ProgrammerScore1 = x.Programmer1.HasValue ? x.ProgrammerScore1 : null,
                        IsReassigned = x.PhaseName.Split("-", StringSplitOptions.None).Count() > 1 ? true : false,
                        TechTLStatus = x.TechTLStatus,
                        PgmTLStatus = x.PgmTLStatus,
                        TechTL = x.TechTL,
                        PgmTL = x.PgmTL,
                        Status = x.WorkStatus.WorkStatusName,
                        LastPublication = lastPublication,
                    }).FirstOrDefaultAsync();
                var phaseFiles = await _context.PhaseFiles
                               .Where(x => x.PhaseId == phaseId && !x.IsPublication)
                               .ToListAsync();

                var phasefile = new PhasefileViewDto
                {
                    ProposalDto = phaseFiles.Where(x => x.FilePath.Contains("Proposal_Manuscript_Thesis")).Select(x => new ProposalDto
                    {
                        EmpId = x.EmpId,
                        ProposalId = x.PhaseFileId,
                        Proposal = x.FileName,
                        ProposalPath = x.FilePath
                    }).ToList(),
                    VisoDto = phaseFiles.Where(x => x.FilePath.Contains("Viso")).Select(x => new VisoDto
                    {
                        EmpId = x.EmpId,
                        VisoId = x.PhaseFileId,
                        Viso = x.FileName,
                        VisoPath = x.FilePath
                    }).ToList(),
                    ReferencePaperDto = phaseFiles.Where(x => x.FilePath.Contains("ReferencePaper")).Select(x => new ReferencePaperDto
                    {
                        EmpId = x.EmpId,
                        ReferencePaperId = x.PhaseFileId,
                        ReferencePaper = x.FileName,
                        ReferencePaperPath = x.FilePath
                    }).ToList(),
                    OthersDto = phaseFiles.Where(x => x.FilePath.Contains("Others") && !x.FilePath.Contains("programming")).Select(x => new OthersDto
                    {
                        EmpId = x.EmpId,
                        OthersId = x.PhaseFileId,
                        Others = x.FileName,
                        OthersPath = x.FilePath
                    }).ToList(),
                    CodeDto = phaseFiles.Where(x => x.FilePath.Contains("Code")).Select(x => new CodeDto
                    {
                        EmpId = x.EmpId,
                        CodeId = x.PhaseFileId,
                        Code = x.FileName,
                        CodePath = x.FilePath
                    }).ToList(),
                    DataSetDto = phaseFiles.Where(x => x.FilePath.Contains("DataSet")).Select(x => new DataSetDto
                    {
                        EmpId = x.EmpId,
                        DataSetId = x.PhaseFileId,
                        DataSet = x.FileName,
                        DataSetPath = x.FilePath
                    }).ToList(),
                    GraphDto = phaseFiles.Where(x => x.FilePath.Contains("Graph")).Select(x => new GraphDto
                    {
                        EmpId = x.EmpId,
                        GraphId = x.PhaseFileId,
                        Graph = x.FileName,
                        GraphPath = x.FilePath
                    }).ToList(),
                    OthersPgmDto = phaseFiles.Where(x => x.FilePath.Contains("Others(p)")).Select(x => new OthersPgmDto
                    {
                        EmpId = x.EmpId,
                        OthersPgmId = x.PhaseFileId,
                        OthersPgm = x.FileName,
                        OthersPgmPath = x.FilePath
                    }).ToList()
                };
                var plagiarism = _context.Plagiarism.Where(x => x.PhaseId == phaseId).OrderByDescending(x => x.PlagiarismId).Select(x => new
                {
                    x.PhaseId,
                    x.PlagiarismId
                }).FirstOrDefault();
                   
                PlagiarismfileView plagiarismfileView = null;

                if (plagiarism != null)
                {
                    var plag = await _context.PlagiarismRecipient.Where(x => x.PlagiarismId == plagiarism.PlagiarismId &&
                   x.IsUploaded).ToListAsync();
                    plagiarismfileView = new PlagiarismfileView
                    {
                        PhaseId = plagiarism?.PhaseId ?? 0,
                        PlagFileName = plag.FirstOrDefault(x => x.UploadedFileName.Contains(".docx"))?.UploadedFileName,
                        PlagFilePath = plag.FirstOrDefault(x => x.UploadedFileName.Contains(".docx"))?.UploadedFilePath,
                        AIFileName = plag.FirstOrDefault(x => !x.UploadedFileName.Contains(".docx"))?.UploadedFileName,
                        AIFilePath = plag.FirstOrDefault(x => !x.UploadedFileName.Contains(".docx"))?.UploadedFilePath,
                    };
                }
                phase.PlagiarismfileView = plagiarismfileView;
                phase.phasefile = phasefile;
                phase.CanCompleteProgrammer = checkForPgm != null && (checkForPgm.TechExpert.HasValue || checkForPgm.TechExpert1.HasValue
                    || checkForPgm.TechExpert2.HasValue || checkForPgm.TechExpert3.HasValue) ? false : true;
                phase.IsTL = checkForPgm != null && ((checkForPgm.TechExpert.HasValue && checkForPgm.TechExpert.Value == EmpId) || (checkForPgm.TechExpert1.HasValue && checkForPgm.TechExpert1.Value == EmpId)
                    || (checkForPgm.TechExpert2.HasValue && checkForPgm.TechExpert2.Value == EmpId) || (checkForPgm.TechExpert3.HasValue && checkForPgm.TechExpert3.Value == EmpId)) ? true : false;
                return (true, new string[] { }, phase);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        public async Task<(bool Succeeded, string[] Error, PhaseDemoDto Demo)> GetPhaseDemoFormAsync(int phaseId)
        {
            try
            {
                var phase = await _context.Phase
                .Include(p => p.Employees)
                .Include(p => p.Employees1)
                .Include(p => p.Employees2)
                .Include(p => p.Employees3)
                .Include(p => p.Employees4)
                .Include(p => p.Employees5)
                .Include(p => p.PhaseDemo)
                .Where(p => p.PhaseId == phaseId)
                .Select(p => new PhaseDemoDto
                {
                    Link = p.PhaseDemo
                        .Where(pd => !pd.IsDemoAgain)
                        .OrderBy(pd => pd.DemoId)
                        .Select(pd => pd.Link)
                        .LastOrDefault() ?? string.Empty,
                    TechExpert = p.TechExpert.HasValue ? p.Employees.EmployeeName : string.Empty,
                    TechExpert1 = p.TechExpert1.HasValue ? p.Employees1.EmployeeName : string.Empty,
                    TechExpert2 = p.TechExpert2.HasValue ? p.Employees2.EmployeeName : string.Empty,
                    TechExpert3 = p.TechExpert3.HasValue ? p.Employees3.EmployeeName : string.Empty,
                    Programmer = p.Programmer.HasValue ? p.Employees4.EmployeeName : string.Empty,
                    Programmer1 = p.Programmer1.HasValue ? p.Employees5.EmployeeName : string.Empty,
                    TechExpertId = p.TechExpert.HasValue ? p.Employees.EmpId : (int?)null,
                    TechExpert1Id = p.TechExpert1.HasValue ? p.Employees1.EmpId : (int?)null,
                    TechExpert2Id = p.TechExpert2.HasValue ? p.Employees2.EmpId : (int?)null,
                    TechExpert3Id = p.TechExpert3.HasValue ? p.Employees3.EmpId : (int?)null,
                    ProgrammerId = p.Programmer.HasValue ? p.Employees4.EmpId : (int?)null,
                    TechExpertChecked = p.PhaseDemo.Any(pd => pd.EmpId == p.TechExpert && !pd.IsDemoAgain)
                    ? (p.PhaseDemo.OrderBy(x => x.DemoId).GroupBy(t => new { t.PhaseId, t.Status }).Count() == 1
                        ? (p.PhaseDemo.All(x => x.Status == false && x.PhaseId == phaseId) ? true : false)
                        : true)
                    : false,
                    TechExpert1Checked = p.PhaseDemo.Any(pd => pd.EmpId == p.TechExpert1 && !pd.IsDemoAgain)
                    ? (p.PhaseDemo.OrderBy(x => x.DemoId).GroupBy(t => new { t.PhaseId, t.Status }).Count() == 1
                        ? (p.PhaseDemo.All(x => x.Status == false && x.PhaseId == phaseId) ? true : false)
                        : true)
                    : false,
                    TechExpert2Checked = p.PhaseDemo.Any(pd => pd.EmpId == p.TechExpert2 && !pd.IsDemoAgain)
                    ? (p.PhaseDemo.OrderBy(x => x.DemoId).GroupBy(t => new { t.PhaseId, t.Status }).Count() == 1
                        ? (p.PhaseDemo.All(x => x.Status == false && x.PhaseId == phaseId) ? true : false)
                        : true)
                    : false,
                    TechExpert3Checked = p.PhaseDemo.Any(pd => pd.EmpId == p.TechExpert3 && !pd.IsDemoAgain)
                    ? (p.PhaseDemo.OrderBy(x => x.DemoId).GroupBy(t => new { t.PhaseId, t.Status }).Count() == 1
                        ? (p.PhaseDemo.All(x => x.Status == false && x.PhaseId == phaseId) ? true : false)
                        : true)
                    : false,
                    ProgrammerChecked = p.PhaseDemo.Any(pd => pd.EmpId == p.Programmer && !pd.IsDemoAgain)
                    ? (p.PhaseDemo.OrderBy(x => x.DemoId).GroupBy(t => new { t.PhaseId, t.Status }).Count() == 1
                        ? (p.PhaseDemo.All(x => x.Status == false && x.PhaseId == phaseId) ? true : false)
                        : true)
                    : false,
                    Programmer1Checked = p.PhaseDemo.Any(pd => pd.EmpId == p.Programmer1 && !pd.IsDemoAgain)
                    ? (p.PhaseDemo.OrderBy(x => x.DemoId).GroupBy(t => new { t.PhaseId, t.Status }).Count() == 1
                        ? (p.PhaseDemo.All(x => x.Status == false && x.PhaseId == phaseId) ? true : false)
                        : true)
                    : false
                })
                .FirstOrDefaultAsync();
                return (true, new string[] { }, phase);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        public async Task<(bool Succeeded, string[] Error, IList<PhaseDemoListDto> Demo)> GetPhaseDemoAsync(string status)
        {
            try
            {
                var demo = await (from phaseDemo in _context.PhaseDemo
                                  join phase in _context.Phase on phaseDemo.PhaseId equals phase.PhaseId
                                  join project in _context.Projects on phase.ProjectId equals project.ProjectId
                                  join client in _context.Clients on project.EnquiryId equals client.EnquiryId
                                  join employee in _context.Employees on phaseDemo.EmpId equals employee.EmpId
                                  group phaseDemo by new { phaseDemo.PhaseId, phaseDemo.Link, phaseDemo.IsDemoAgain } into g
                                  select new PhaseDemoListDto()
                                  {
                                      PhaseId = g.FirstOrDefault().PhaseId,
                                      PhaseName = g.FirstOrDefault().Phase.PhaseName,
                                      Link = g.FirstOrDefault().Link,
                                      ProjectRef = g.FirstOrDefault().Phase.Projects.ProjectRef,
                                      ClientName = g.FirstOrDefault().Phase.Projects.Clients.ClientName,
                                      Status = ((g.All(x => x.Status)) && (g.Any(x => x.IsClient))) ? "Completed" : "Pending",
                                      EmpStatus = g.Any(x => x.EmpId == Int32.Parse(_session.GetInt32("CurrentUserId").ToString())) ?
                                                   (g.FirstOrDefault(x => x.EmpId == Int32.Parse(_session.GetInt32("CurrentUserId").ToString())).Status ? "Completed" : "Pending") :
                                                   "Completed",
                                      IsClient = g.FirstOrDefault().IsClient,
                                      CreatedOn = g.FirstOrDefault().CreatedDate,
                                      IsClientFeedback = g.Where(x => x.IsClient == true).FirstOrDefault().Feedback,
                                      IsClientFeedbackUpdatedBy = g.Where(x => x.IsClient == true && x.Employees.EmpId == x.EmpId).Select(y => y.Employees.EmployeeName).FirstOrDefault(),
                                      Contact = g.FirstOrDefault().Phase.Projects.Clients.Contact,
                                      TechFeedbackDto = g.Where(x => x.Employees.DeptId == 2 && x.IsClient == false)
                                     .Select(x => new TechFeedbackDto
                                     {
                                         EmpId = x.Employees.EmpId,
                                         EmpName = x.Employees.EmployeeName,
                                         EmpFeedback = x.Feedback
                                     }).ToList(),
                                      ProgrammerFeedbackDto = g.Where(x => x.Employees.DeptId == 3 && x.IsClient == false)
                                           .Select(x => new ProgrammerFeedbackDto
                                           {
                                               EmpId = x.Employees.EmpId,
                                               EmpName = x.Employees.EmployeeName,
                                               EmpFeedback = x.Feedback
                                           }).ToList(),
                                      BDAFeedbackDto = g.Where(x => x.Employees.DeptId == 1 && x.IsClient == false)
                                   .Select(x => new BDAFeedbackDto
                                   {
                                       EmpId = x.Employees.EmpId,
                                       EmpName = x.Employees.EmployeeName,
                                       EmpFeedback = x.Feedback
                                   }).ToList(),
                                  }).Where(y => y.Status == status).ToListAsync();
                if ((_session.GetString("Dept") == Enum.Department.Tech.ToString() || _session.GetString("Dept") == Enum.Department.Programming.ToString())
                    && _session.GetString("Role") != Enum.Roles.Manager.ToString())
                {
                    demo = demo.Where(x => x.TechFeedbackDto.Any(t => t.EmpId == _session.GetInt32("CurrentUserId"))
                    || x.ProgrammerFeedbackDto.Any(t => t.EmpId == _session.GetInt32("CurrentUserId"))
                    || x.BDAFeedbackDto.Any(t => t.EmpId == _session.GetInt32("CurrentUserId"))).ToList();
                }
                return (true, new string[] { }, demo);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        public async Task<(bool Succeeded, string[] Error, Phase Phase)> UpdateProgressAsync(int progressId, int phaseId, int value)
        {
            try
            {
                var phase = await _context.Phase.FindAsync(phaseId);
                if (progressId == 1) phase.Progress = (int)Math.Round((decimal)value / 5, MidpointRounding.AwayFromZero) * 5;
                if (progressId == 2) phase.Progress1 = (int)Math.Round((decimal)value / 5, MidpointRounding.AwayFromZero) * 5;
                if (progressId == 3) phase.Progress2 = (int)Math.Round((decimal)value / 5, MidpointRounding.AwayFromZero) * 5;
                if (progressId == 4) phase.Progress3 = (int)Math.Round((decimal)value / 5, MidpointRounding.AwayFromZero) * 5;
                _context.Update(phase);
                int result = await _context.SaveChangesAsync().ConfigureAwait(false);
                return (true, new string[] { "Project updated sucessfully" }, phase);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        public async Task<(bool Succeeded, string[] Error, IList<ProjectListDto> Data)> GetGlobalSearchAsync(string searchString)
        {
            try
            {
                IEnumerable<Phase> phase = null;

                var project = await _context.Projects.Where(x => x.ProjectRef.Contains(searchString))
                    .Include(x => x.Phase).ThenInclude(x => x.Employees)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees1)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees2)
                    .Include(x => x.Phase).ThenInclude(x => x.WorkStatus)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees3)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees4)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees5)
                    .Include(x => x.Clients).ThenInclude(x => x.BDAEmployee)
                    .Include(x => x.Clients).ThenInclude(x => x.TechEmployee).ToListAsync();

                phase = project.Where(x => x.Phase.Count() > 0).Select(x => x.Phase.OrderByDescending(x => x.ProjectId).LastOrDefault());



                List<String> lstCustomSort = new List<String>() { "Publication", "Completed", "Published" };


                var result = phase.Select(t => new ProjectListDto()
                {
                    EnquiryId = t.Projects.Clients.EnquiryId,
                    PhaseId = t.PhaseId,
                    ProjectId = t.ProjectId,
                    ClientName = t.Projects.Clients.ClientName,
                    ProjectName = t.Projects.ProjectName,
                    PhaseName = t.PhaseName,
                    EnquiryRef = t.Projects.ProjectRef,
                    Contact = t.Projects.Clients.Contact,
                    Domain = t.Projects.Clients.Domain,
                    DeadLine = t.DeadLine,
                    NextAppoinment = t.NextAppoinment,
                    // DemoDate =  t.DemoDate,
                    //DemoDate = t.NextAppoinment <  t.DemoDate  ? t.NextAppoinment : t.DemoDate,
                    // DemoDate = t.NextAppoinment != null ? t.NextAppoinment : t.DemoDate,
                    DemoDate = t.Status == (int)Enum.WorkStatus.Hold ? t.NextAppoinment : t.DemoDate,
                    DemoDate3 = t.Status == (int)Enum.WorkStatus.Hold ? t.NextAppoinment : t.DemoDate3,
                    Status = t.WorkStatus.WorkStatusName,
                    AssignedTech = t.Employees == null ? "" : t.Employees.EmployeeName,
                    AssignedTech1 = t.Employees1 == null ? "" : t.Employees1.EmployeeName,
                    AssignedTech2 = t.Employees2 == null ? "" : t.Employees2.EmployeeName,
                    AssignedTech3 = t.Employees3 == null ? "" : t.Employees3.EmployeeName,
                    AssignedTech4 = t.Employees4 == null ? "" : t.Employees4.EmployeeName,
                    AssignedTech5 = t.Employees5 == null ? "" : t.Employees5.EmployeeName,
                    Comment = t.Comment,


                }).OrderBy(x => x.DeadLine).ToList()
                .OrderBy(x => x.DemoDate3).ToList()
                .OrderBy(x => x.DemoDate).ToList()
                .OrderBy(x => lstCustomSort.Contains(x.Status) ? 2 : 1).ToList();




                return (true, new string[] { }, result);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }
        public async Task<(bool Succeeded, string[] Error, Phase phase)> UpdatePhasePriorityAsync(PhasePriority phaseItem)
        {
            try
            {
                var result = await _context.Phase
                    .FirstOrDefaultAsync(p => p.PhaseId == phaseItem.PhaseId);

                if (result != null)
                {
                    if (result.TechExpert == phaseItem.EmployeeId)
                    {
                        result.TechPriority = phaseItem.PriorityId;
                        result.DemoDate = phaseItem.DemoDate;
                    }
                    else if (result.TechExpert1 == phaseItem.EmployeeId)
                    {
                        result.TechPriority1 = phaseItem.PriorityId;
                        result.DemoDate1 = phaseItem.DemoDate;
                    }
                    else if (result.TechExpert2 == phaseItem.EmployeeId)
                    {
                        result.TechPriority2 = phaseItem.PriorityId;
                        result.DemoDate2 = phaseItem.DemoDate;
                    }
                    else if (result.TechExpert3 == phaseItem.EmployeeId)
                    {
                        result.TechPriority3 = phaseItem.PriorityId;
                        result.DemoDate4 = phaseItem.DemoDate;
                    }
                    else if (result.Programmer == phaseItem.EmployeeId)
                    {
                        result.ProgrammerPriority = phaseItem.PriorityId;
                        result.DemoDate3 = phaseItem.DemoDate;
                    }
                    else if (result.Programmer1 == phaseItem.EmployeeId)
                    {
                        result.ProgrammerPriority1 = phaseItem.PriorityId;
                        result.DemoDate5 = phaseItem.DemoDate;
                    }

                    _context.Update(result);

                    await _context.SaveChangesAsync().ConfigureAwait(true);

                    return (true, null, result);
                }
                else
                {
                    return (false, new[] { "Phase not found" }, null);
                }
            }
            catch (Exception ex)
            {
                return (false, new[] { ex.Message }, null);
            }
        }


        public async Task<(bool Succeeded, string[] Error, Phase phase)> EditPhaseFormPriorityAsync(PhasePriority extraList)
        {
            try
            {
                var result = await _context.Phase
                    .FirstOrDefaultAsync(p => p.PhaseId == extraList.PhaseId);

                if (result != null)
                {
                    if (extraList.Input == "techExpert")
                    {
                        result.TechExpert = extraList.EmployeeId;
                        result.TechPriority = extraList.PriorityId;
                        result.DemoDate = extraList.DemoDate;
                        result.Remarks = extraList.Remark;
                    }
                    else if (extraList.Input == "techExpert1")
                    {
                        result.TechExpert1 = extraList.EmployeeId;
                        result.TechPriority1 = extraList.PriorityId;
                        result.DemoDate1 = extraList.DemoDate;
                        result.Remarks1 = extraList.Remark;
                    }
                    else if (extraList.Input == "techExpert2")
                    {
                        result.TechExpert2 = extraList.EmployeeId;
                        result.TechPriority2 = extraList.PriorityId;
                        result.DemoDate2 = extraList.DemoDate;
                        result.Remarks2 = extraList.Remark;
                    }
                    else if (extraList.Input == "techExpert3")
                    {
                        result.TechExpert3 = extraList.EmployeeId;
                        result.TechPriority3 = extraList.PriorityId;
                        result.DemoDate4 = extraList.DemoDate;
                        result.Remarks4 = extraList.Remark;
                    }
                    else if (extraList.Input == "programmer")
                    {
                        result.Programmer = extraList.EmployeeId;
                        result.ProgrammerPriority = extraList.PriorityId;
                        result.DemoDate3 = extraList.DemoDate;
                        result.Remarks3 = extraList.Remark;
                    }
                    else if (extraList.Input == "programmer1")
                    {
                        result.Programmer1 = extraList.EmployeeId;
                        result.ProgrammerPriority1 = extraList.PriorityId;
                        result.DemoDate5 = extraList.DemoDate;
                        result.Remarks5 = extraList.Remark;
                    }

                    _context.Update(result);

                    await _context.SaveChangesAsync().ConfigureAwait(true);

                    return (true, null, result);
                }
                else
                {
                    return (false, new[] { "Phase not found" }, null);
                }
            }
            catch (Exception ex)
            {
                return (false, new[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Error, Phase Phase)> ReassignedPhaseAsync(string reassignedPhase, int projectId, DateTime deadline, DateTime AssignedDate, string reason)
        {
            try
            {
                var result = new Phase
                {
                    PhaseName = reassignedPhase,
                    ProjectId = projectId,
                    Status = (int)Enum.WorkStatus.Assigned,
                    DeadLine = deadline,
                    AssignedDate = AssignedDate
                };

                await _context.AddAsync(result);
                var data = await _context.SaveChangesAsync().ConfigureAwait(false);
                if (data > 0)
                {
                    var phaseComment = new PhaseHistory()
                    {
                        PhaseId = result.PhaseId,
                        Comments = reason,
                        EmpId = (int)_session.GetInt32("CurrentUserId"),
                        IsReassigned = true,
                    };
                    await _context.AddAsync(phaseComment);
                    await _context.SaveChangesAsync().ConfigureAwait(false);
                }

                return (true, new string[] { "Project added successfully" }, result);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }

        public async Task<(bool Succeeded, string[] Error, IList<PhaseStatusDto> Data)> GetPhaseStatusAsync()
        {
            try
            {
                var activePhaseStatusList = _context.PhaseStatus
                 .Where(ps => ps.IsActive)
                 .ToList();
                var phaseStatusDtoList = activePhaseStatusList.Select(ps => _mapper.Map<PhaseStatusDto>(ps)).ToList();
                return (true, new string[] { }, phaseStatusDtoList);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Error, IList<PhaseStatusDto> Data)> GetPhaseStatusDropdownAsync()
        {
            try
            {
                var activePhaseStatusList = _context.PhaseStatus
                 .Where(ps => ps.IsActive && !ps.OnlyForProgrammers && !ps.OnlyForTech && !ps.SpecialDeadline)
                 .ToList();
                var phaseStatusDtoList = activePhaseStatusList.Select(ps => _mapper.Map<PhaseStatusDto>(ps)).ToList();
                return (true, new string[] { }, phaseStatusDtoList);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Error, IList<PhaseStatusDto> Data)> GetPhaseStatusDropdownDaysOnlyAsync()
        {
            try
            {
                var activePhaseStatusList = _context.PhaseStatus
                 .Where(ps => ps.IsActive && !ps.OnlyForProgrammers && !ps.OnlyForTech && !ps.IsMonthCalc)
                 .ToList();
                var phaseStatusDtoList = activePhaseStatusList.Select(ps => _mapper.Map<PhaseStatusDto>(ps)).ToList();
                return (true, new string[] { }, phaseStatusDtoList);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Error, IList<PhaseStatusDto> Data)> GetPhaseDetailsAsync(string phaseId)
        {
            try
            {
                var phaseStatus = await _context.PhaseStatus.FirstOrDefaultAsync(ps => ps.PhaseName == phaseId && ps.IsActive);
                var PhaseDeadLine = new List<PhaseStatusDto> { _mapper.Map<PhaseStatusDto>(phaseStatus) };
                return (true, new string[] { }, PhaseDeadLine);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Error, PhaseStatusDto Phasestatus)> GetPhaseListAsync(int phaseId)
        {
            try
            {
                var result = await _context.PhaseStatus.FindAsync(phaseId);
                var map = _mapper.Map<PhaseStatusDto>(result);
                return (true, new string[] { }, map);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }
        public async Task<(bool Succeeded, string[] Error, PhaseStatus Phasestatus)> CreateNewPhaseAsync(PhaseStatusDto phaseStatusDto)
        {
            try
            {
                var map = _mapper.Map<PhaseStatus>(phaseStatusDto);
                await _context.AddAsync(map);
                int result = await _context.SaveChangesAsync();
                return (true, new string[] { "Phase added sucessfully" }, map);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }
        public async Task<(bool Succeeded, string[] Error, PhaseStatus Phasestatus)> UpdatePhaseListAsync(int phaseId, PhaseStatusDto phaseStatusDto)
        {
            try
            {
                var existingPhase = await _context.PhaseStatus.FindAsync(phaseId);

                if (existingPhase == null)
                {
                    return (false, new string[] { "Phase not found" }, null);
                }
                existingPhase.PhaseName = phaseStatusDto.PhaseName;
                existingPhase.ClientDeadline = phaseStatusDto.ClientDeadline;
                existingPhase.EmployeeDeadline = phaseStatusDto.EmployeeDeadline;
                existingPhase.IsMonthCalc = phaseStatusDto.IsMonthCalc;
                existingPhase.IsScore = phaseStatusDto.IsScore;
                existingPhase.OnlyForProgrammers = phaseStatusDto.OnlyForProgrammers;
                existingPhase.OnlyForTech = phaseStatusDto.OnlyForTech;
                existingPhase.SpecialDeadline = phaseStatusDto.SpecialDeadline;
                existingPhase.SkipPublication = phaseStatusDto.SkipPublication;
                int result = await _context.SaveChangesAsync();
                return (true, new string[] { "Phase updated successfully" }, existingPhase);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Error, IList<PhaseStatus> Data)> GetTechWorkTypeAsync()
        {
            try
            {
                var data = await _context.PhaseStatus.Where(x => x.IsActive == true && x.OnlyForTech == true).ToListAsync();

                return (true, new string[] { }, data);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }
        public async Task<(bool Succeeded, string[] Error, IList<PhaseStatus> Data)> GetProgrammersWorkTypeAsync()
        {
            try
            {
                var data = await _context.PhaseStatus.Where(x => x.IsActive == true && x.OnlyForProgrammers == true).ToListAsync();

                return (true, new string[] { }, data);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }

        public int GetEmployeesInProgressAsync(int empId)
        {
            try
            {
                var count = _context.Projects
    .Select(project => project.Phase.OrderBy(x => x.PhaseId).LastOrDefault()) // Flatten phases across all projects
    .Where(phase =>
        (phase.Status == (int)Enum.WorkStatus.Progress) && // Phase is in progress
        ( // Any of the specified conditions match
            (phase.TechExpert == empId && phase.TechStatus == false) ||
            (phase.TechExpert1 == empId && phase.TechStatus1 == false) ||
            (phase.TechExpert2 == empId && phase.TechStatus2 == false) ||
            (phase.TechExpert3 == empId && phase.TechStatus3 == false) ||
            (phase.Programmer == empId && phase.ProgrammerStatus == false) ||
            (phase.Programmer1 == empId && phase.ProgrammerStatus1 == false)
        ) &&
        !( // Phase does not have any of the excluded statuses
            phase.Status == (int)Enum.WorkStatus.Assigned ||
            phase.Status == (int)Enum.WorkStatus.Hold ||
            phase.Status == (int)Enum.WorkStatus.Publication ||
            phase.Status == (int)Enum.WorkStatus.Revision ||
            phase.Status == (int)Enum.WorkStatus.Accepted ||
            phase.Status == (int)Enum.WorkStatus.Rejected ||
            phase.Status == (int)Enum.WorkStatus.Completed
        )
    )
    .Count();


                return count;
            }
            catch (Exception ex)
            {

                throw;
            }


        }
        public async Task<(bool Succeeded, string[] Error, IList<(string EmployeeName, int EmpId, bool IsDisabled)> Data)> GetTechAssignDropDownAsync()
        {
            try
            {
                var data = new List<Employees>();
                if (_session.GetString("Role") == Enum.Roles.Manager.ToString())
                {
                    data = await _context.Employees
                       .Where(x => x.IsActive && x.DeptId == 2)
                       .ToListAsync();
                }
                else
                {
                    data = await _context.Employees
                       .Where(x => x.IsActive && x.DeptId == 2 && x.SuperiorId == _session.GetInt32("CurrentUserId"))
                       .ToListAsync();
                }

                var filteredData = new List<(string EmployeeName, int EmpId, bool IsDisabled)>();
                foreach (var employee in data)
                {
                    var inProgressCount = GetEmployeesInProgressAsync(employee.EmpId);
                    if (inProgressCount < 3)
                    {
                        filteredData.Add((employee.EmployeeName, employee.EmpId, false));
                    }
                    else
                    {
                        filteredData.Add((employee.EmployeeName, employee.EmpId, true));
                    }
                }

                return (true, new string[] { }, filteredData);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<bool> DeleteAssignedWorkAsync(int phaseId, string techType, int techId, string remark)
        {
            try
            {
                var projects = await _context.Phase
                    .Where(p => p.PhaseId == phaseId)
                    .ToListAsync();
                var phase = await _context.PhaseExecution
                    .Where(ph => ph.PhaseId == phaseId &&
                                 ph.EmpId == techId || ph.Remarks == remark).OrderBy(ph => ph.PhaseExecutionId).LastOrDefaultAsync();
                if (phase != null)
                {
                    _context.PhaseExecution.Remove(phase);
                    await _context.SaveChangesAsync();
                }
                foreach (var project in projects)
                {
                    switch (techType)
                    {
                        case "Tech":
                            if (project.TechExpert == techId)
                            {
                                project.TechExpert = null;
                                project.Remarks = null;
                                project.DemoDate = null;
                            }
                            break;
                        case "Tech1":
                            if (project.TechExpert1 == techId)
                            {
                                project.TechExpert1 = null;
                                project.Remarks1 = null;
                                project.DemoDate1 = null;
                            }
                            break;
                        case "Tech2":
                            if (project.TechExpert2 == techId)
                            {
                                project.TechExpert2 = null;
                                project.Remarks2 = null;
                                project.DemoDate2 = null;
                            }
                            break;
                        case "Tech3":
                            if (project.TechExpert3 == techId)
                            {
                                project.TechExpert3 = null;
                                project.Remarks4 = null;
                                project.DemoDate4 = null;
                            }
                            break;
                        case "Pgm":
                            if (project.Programmer == techId)
                            {
                                project.Programmer = null;
                                project.Remarks3 = null;
                                project.DemoDate3 = null;
                            }
                            break;
                        case "Pgm1":
                            if (project.Programmer1 == techId)
                            {
                                project.Programmer1 = null;
                                project.Remarks5 = null;
                                project.DemoDate5 = null;
                            }
                            break;
                        default:
                            break;
                    }
                }

                await _context.SaveChangesAsync();
                foreach (var project in projects)
                {
                    if (project.TechExpert == null && project.TechExpert1 == null && project.TechExpert2 == null
                        && project.TechExpert3 == null && project.Programmer == null && project.Programmer1 == null)
                    {
                        project.Status = (int)Enum.WorkStatus.Assigned;
                        await _context.SaveChangesAsync();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while deleting the Assigned work.", ex);
            }
        }

        public async Task<(bool Succeeded, string[] Error)> PhaseExecutionAsync(EditPhaseDto phaseDto, int status)
        {
            try
            {
                var phase = await _context.PhaseExecution
                    .Where(ph => ph.PhaseId == phaseDto.PhaseId &&
                                 (ph.EmpId == phaseDto.TechExpert || ph.EmpId == phaseDto.TechExpert1 ||
                                  ph.EmpId == phaseDto.TechExpert2 || ph.EmpId == phaseDto.TechExpert3 ||
                                  ph.EmpId == phaseDto.Programmer || ph.EmpId == phaseDto.Programmer1))
                    .ToListAsync();

                bool tech = false;
                bool tech1 = false;
                bool tech2 = false;
                bool tech3 = false;
                bool pgm = false;
                bool pgm1 = false;

                if (phase != null && phase.Any())
                {
                    foreach (var phaseExecution in phase)
                    {
                        if (phaseExecution.PhaseId == phaseDto.PhaseId)
                        {
                            if (phaseDto.TechExpert == phaseExecution.EmpId && phaseDto.Remarks == phaseExecution.Remarks)
                            {
                                tech = true;
                                continue;
                            }

                            if (phaseDto.TechExpert1 == phaseExecution.EmpId && phaseDto.Remarks1 == phaseExecution.Remarks)
                            {
                                tech1 = true;
                                continue;
                            }

                            if (phaseDto.TechExpert2 == phaseExecution.EmpId && phaseDto.Remarks2 == phaseExecution.Remarks)
                            {
                                tech2 = true;
                                continue;
                            }

                            if (phaseDto.TechExpert3 == phaseExecution.EmpId && phaseDto.Remarks4 == phaseExecution.Remarks)
                            {
                                tech3 = true;
                                continue;
                            }

                            if (phaseDto.Programmer == phaseExecution.EmpId && phaseDto.Remarks3 == phaseExecution.Remarks)
                            {
                                pgm = true;
                                continue;
                            }

                            if (phaseDto.Programmer1 == phaseExecution.EmpId && phaseDto.Remarks5 == phaseExecution.Remarks)
                            {
                                pgm1 = true;
                                continue;
                            }
                        }
                    }
                }

                if ((phase == null && phaseDto.TechExpert.HasValue) || (phaseDto.TechExpert.HasValue && tech == false))
                {
                    await CreatePhaseExecutionAsync(phaseDto.PhaseId, phaseDto.TechExpert, phaseDto.Remarks, phaseDto.DemoDate, status);
                }

                if ((phase == null && phaseDto.TechExpert1.HasValue) || (phaseDto.TechExpert1.HasValue && tech1 == false))
                {
                    await CreatePhaseExecutionAsync(phaseDto.PhaseId, phaseDto.TechExpert1, phaseDto.Remarks1, phaseDto.DemoDate1, status);
                }

                if ((phase == null && phaseDto.TechExpert2.HasValue) || (phaseDto.TechExpert2.HasValue && tech2 == false))
                {
                    await CreatePhaseExecutionAsync(phaseDto.PhaseId, phaseDto.TechExpert2, phaseDto.Remarks2, phaseDto.DemoDate2, status);
                }

                if ((phase == null && phaseDto.TechExpert3.HasValue) || (phaseDto.TechExpert3.HasValue && tech3 == false))
                {
                    await CreatePhaseExecutionAsync(phaseDto.PhaseId, phaseDto.TechExpert3, phaseDto.Remarks4, phaseDto.DemoDate4, status);
                }

                if ((phase == null && phaseDto.Programmer.HasValue) || (phaseDto.Programmer.HasValue && pgm == false))
                {
                    await CreatePhaseExecutionAsync(phaseDto.PhaseId, phaseDto.Programmer, phaseDto.Remarks3, phaseDto.DemoDate3, status);
                }

                if ((phase == null && phaseDto.Programmer1.HasValue) || (phaseDto.Programmer1.HasValue && pgm1 == false))
                {
                    await CreatePhaseExecutionAsync(phaseDto.PhaseId, phaseDto.Programmer1, phaseDto.Remarks5, phaseDto.DemoDate5, status);
                }

                return (true, new string[] { "Project updated successfully" });
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message });
            }
        }

        private async Task CreatePhaseExecutionAsync(int phaseId, int? empId, string remarks, DateTime? demoDate, int status)
        {
            if (empId.HasValue)
            {
                var phaseExecution = new Models.PhaseExecution
                {
                    EmpId = empId.Value,
                    PhaseId = phaseId,
                    Remarks = remarks,
                    DemoDate = demoDate,
                    Status = status
                };
                _context.PhaseExecution.Add(phaseExecution);
                await _context.SaveChangesAsync();
            }
        }




        public async Task<IList<SubordinatesProjectListDto>> GetSuperiorPhaseAsync()
        {
            try
            {
                var userId = _session.GetInt32("CurrentUserId") ?? throw new Exception("CurrentUserId is null");
                var employees = await _context.Employees
                    .Where(x => x.IsActive && x.SuperiorId == userId)
                    .ToListAsync();

                var result = new List<SubordinatesProjectListDto>();

                foreach (var employee in employees)
                {
                    var projects = await _context.Projects
                        .Include(x => x.Phase)
                        .ThenInclude(x => x.Employees)
                        .Include(x => x.Phase)
                        .ThenInclude(x => x.Employees1)
                        .Include(x => x.Phase)
                        .ThenInclude(x => x.Employees2)
                        .Include(x => x.Phase)
                        .ThenInclude(x => x.Employees3)
                        .Include(x => x.Phase)
                        .ThenInclude(x => x.Employees4)
                        .Include(x => x.Phase)
                        .ThenInclude(x => x.Employees5)
                        .Include(x => x.Phase)
                        .ThenInclude(x => x.WorkStatus)
                        .Include(x => x.Clients)
                        .ThenInclude(x => x.BDAEmployee)
                        .Include(x => x.Clients)
                        .ThenInclude(x => x.TechEmployee)
                        .Where(x => x.Phase.Any() &&
                                    (x.Phase.Any(y => y.Employees != null && y.Employees.EmpId == employee.EmpId) ||
                                    x.Phase.Any(y => y.Employees1 != null && y.Employees1.EmpId == employee.EmpId) ||
                                    x.Phase.Any(y => y.Employees2 != null && y.Employees2.EmpId == employee.EmpId) ||
                                    x.Phase.Any(y => y.Employees3 != null && y.Employees3.EmpId == employee.EmpId) ||
                                    x.Phase.Any(y => y.Employees4 != null && y.Employees4.EmpId == employee.EmpId) ||
                                    x.Phase.Any(y => y.Employees5 != null && y.Employees5.EmpId == employee.EmpId)
                                    ))
                        .Select(x => x.Phase.OrderBy(x => x.PhaseId).LastOrDefault())
                        .Where(phasetmp => ((phasetmp.TechExpert == employee.EmpId) ||
                                           (phasetmp.TechExpert1 == employee.EmpId) ||
                                           (phasetmp.TechExpert2 == employee.EmpId) ||
                                           (phasetmp.TechExpert3 == employee.EmpId) ||
                                           (phasetmp.Programmer == employee.EmpId) ||
                                           (phasetmp.Programmer1 == employee.EmpId)) && (phasetmp.Status == 1 || phasetmp.Status == 2 || phasetmp.Status == 3))
                        .OrderBy(x => x.Status)
                        .ThenBy(x => x.DeadLine)
                        .ToListAsync();

                    foreach (var project in projects)
                    {
                        result.Add(new SubordinatesProjectListDto()
                        {
                            EmpName = employee.EmployeeName,
                            EnquiryId = project.Projects.Clients.EnquiryId,
                            PhaseId = project.PhaseId,
                            ProjectId = project.ProjectId,
                            ClientName = project.Projects.Clients.ClientName,
                            ProjectName = project.Projects.ProjectName,
                            PhaseName = project.PhaseName,
                            EnquiryRef = project.Projects.ProjectRef,
                            Contact = project.Projects.Clients.Contact,
                            Domain = project.Projects.Clients.Domain,
                            DeadLine = project.DeadLine,
                            NextAppoinment = project.NextAppoinment,
                            DemoDate = project.Status == (int)Enum.WorkStatus.Hold ? project.NextAppoinment : project.DemoDate,
                            DemoDate3 = project.Status == (int)Enum.WorkStatus.Hold ? project.NextAppoinment : project.DemoDate3,
                            DemoDate1 = project.DemoDate1,
                            DemoDate2 = project.DemoDate2,
                            DemoDate4 = project.DemoDate4,
                            DemoDate5 = project.DemoDate5,
                            Status = project.WorkStatus.WorkStatusName,
                            StatusId = project.Status,
                            AssignedTech = project.Employees?.EmployeeName ?? "",
                            AssignedTech1 = project.Employees1?.EmployeeName ?? "",
                            AssignedTech2 = project.Employees2?.EmployeeName ?? "",
                            AssignedTech3 = project.Employees3?.EmployeeName ?? "",
                            AssignedTech4 = project.Employees4?.EmployeeName ?? "",
                            AssignedTech5 = project.Employees5?.EmployeeName ?? "",
                            WorkCountTech = project.TechExpert.HasValue ? GetEmployeesInProgressAsync(project.TechExpert.Value) : 0,
                            WorkCountTech1 = project.TechExpert1.HasValue ? GetEmployeesInProgressAsync(project.TechExpert1.Value) : 0,
                            WorkCountTech2 = project.TechExpert2.HasValue ? GetEmployeesInProgressAsync(project.TechExpert2.Value) : 0,
                            WorkCountTech3 = project.TechExpert3.HasValue ? GetEmployeesInProgressAsync(project.TechExpert3.Value) : 0,
                            WorkCountTech4 = project.Programmer.HasValue ? GetEmployeesInProgressAsync(project.Programmer.Value) : 0,
                            WorkCountTech5 = project.Programmer1.HasValue ? GetEmployeesInProgressAsync(project.Programmer1.Value) : 0,
                            Comment = project.Comment,
                            TechExpert = project.TechExpert,
                            TechExpert1 = project.TechExpert1,
                            TechExpert2 = project.TechExpert2,
                            TechExpert3 = project.TechExpert3,
                            Programmer = project.Programmer,
                            Programmer1 = project.Programmer1,
                            TechPriority = project.TechPriority,
                            TechPriority1 = project.TechPriority1,
                            TechPriority2 = project.TechPriority2,
                            TechPriority3 = project.TechPriority3,
                            ProgrammerPriority = project.ProgrammerPriority,
                            ProgrammerPriority1 = project.ProgrammerPriority1,
                            TechStatus = project.TechStatus && project.TechExpert == employee.EmpId,
                            TechStatus1 = project.TechStatus1 && project.TechExpert1 == employee.EmpId,
                            TechStatus2 = project.TechStatus2 && project.TechExpert2 == employee.EmpId,
                            TechStatus3 = project.TechStatus3 && project.TechExpert3 == employee.EmpId,
                            ProgrammerStatus = project.ProgrammerStatus && project.Programmer == employee.EmpId,
                            ProgrammerStatus1 = project.ProgrammerStatus1 && project.Programmer1 == employee.EmpId,
                            TechTLStatus = project.TechTLStatus == false && project.TechTL.HasValue && project.TechTL == _session.GetInt32("CurrentUserId") ? true : false,
                            PgmTLStatus = project.PgmTLStatus == false && project.PgmTL.HasValue && project.PgmTL == _session.GetInt32("CurrentUserId") ? true : false,
                            TechTL = project.TechTL,
                            PgmTL = project.PgmTL,
                            TechTLStatus1 = project.TechTLStatus,
                            PgmTLStatus1 = project.PgmTLStatus,
                            TechStatusAny = ((project.TechStatus && project.TechExpert.HasValue) || (project.TechStatus1 && project.TechExpert1.HasValue)
                        || (project.TechStatus2 && project.TechExpert2.HasValue) || (project.TechStatus3 && project.TechExpert3.HasValue)) ? true : false,
                            PgmStatusAny = ((project.ProgrammerStatus && project.Programmer.HasValue) || (project.ProgrammerStatus1 && project.Programmer1.HasValue)) ? true : false,
                            Priority = GetPriority(project, employee.EmpId),
                            ManagerPriority = GetManagerPriority(project)
                        });
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private int? GetPriority(Phase phase, int userId)
        {
            return userId switch
            {
                _ when phase.TechExpert == userId => phase.TechPriority,
                _ when phase.TechExpert1 == userId => phase.TechPriority1,
                _ when phase.TechExpert2 == userId => phase.TechPriority2,
                _ when phase.TechExpert3 == userId => phase.TechPriority3,
                _ when phase.Programmer == userId => phase.ProgrammerPriority,
                _ when phase.Programmer1 == userId => phase.ProgrammerPriority1,
                _ => null
            };
        }

        private int? GetManagerPriority(Phase phase)
        {
            return 1 switch
            {
                _ when phase.TechPriority == 1 => phase.TechPriority,
                _ when phase.TechPriority1 == 1 => phase.TechPriority1,
                _ when phase.TechPriority2 == 1 => phase.TechPriority2,
                _ when phase.TechPriority3 == 1 => phase.TechPriority3,
                _ when phase.ProgrammerPriority == 1 => phase.ProgrammerPriority,
                _ when phase.ProgrammerPriority1 == 1 => phase.ProgrammerPriority1,
                _ => null
            };
        }
        public async Task<(bool Succeeded, string[] Error)> UpdateFeedbackFormAsync(int PhaseId, int UserId, UpdatePhaseDemoListDto phaseFeedback)
        {
            try
            {
                var entity = _context.PhaseDemo.FirstOrDefault(x => x.PhaseId == PhaseId && x.EmpId == UserId && !x.Status);
                if (entity != null)
                {
                    entity.Status = true;
                    entity.Feedback = phaseFeedback.Feedback;
                    if (phaseFeedback.IsDemoAgain)
                    {
                        var updateDemoAgain = _context.PhaseDemo.Where(x => x.PhaseId == PhaseId && x.Link == phaseFeedback.Link).ToList();
                        if (updateDemoAgain.Count > 0)
                        {
                            var checkRameshUpdate = _context.PhaseDemo.FirstOrDefault(x => x.PhaseId == PhaseId && x.EmpId == 2 && x.Status && x.Link == phaseFeedback.Link);
                            if (checkRameshUpdate == null)
                            {
                                phaseFeedback.IsClient = true;
                                await CreateClientFeedbackByTLAsync(PhaseId, 2, phaseFeedback.Link, phaseFeedback);
                            }
                            else
                            {
                                updateDemoAgain.Add(checkRameshUpdate);
                            }
                            updateDemoAgain.ForEach(x => { x.IsDemoAgain = phaseFeedback.IsDemoAgain; x.Status = true; x.Feedback = phaseFeedback.Feedback; });
                            _context.UpdateRange(updateDemoAgain);
                        }
                    }
                    _context.Update(entity);
                    await _context.SaveChangesAsync();

                    return (true, new string[] { "Feedback updated successfully" });
                }
                else if (UserId == 2)
                {
                    phaseFeedback.IsClient = true;
                    await CreateClientFeedbackByTLAsync(PhaseId, UserId, phaseFeedback.Link, phaseFeedback);
                }
                return (false, new string[] { "Entity not found" });
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message });
            }
        }
        public async Task<(bool Succeeded, string[] Error)> CreateClientFeedbackByTLAsync(int PhaseId, int UserId, string Link, UpdatePhaseDemoListDto Tlfeedback)
        {
            try
            {
                var phaseDemo = new Models.PhaseDemo
                {
                    PhaseId = PhaseId,
                    EmpId = UserId,
                    Link = Link,
                    Status = true,
                    Feedback = Tlfeedback.Feedback,
                    IsClient = Tlfeedback.IsClient,
                    IsDemoAgain = Tlfeedback.IsDemoAgain
                };

                await _context.PhaseDemo.AddAsync(phaseDemo);
                await _context.SaveChangesAsync();
                return (true, new string[] { "Feedback Saved sucessfully" });
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message });
            }

        }

        public async Task<(bool Succeeded, string[] Errors, EditTotalPaymentDetailDto Payment)> EditPaymentDetailsAsync(int ProjectId)
        {
            try
            {
                var paymentDetails = await _context.Projects
                    .Where(x => x.ProjectId == ProjectId)
                    .Select(x => new EditTotalPaymentDetailDto
                    {
                        ProjectId = x.ProjectId,
                        EnquiryId = x.EnquiryId,
                        TotalPayment = x.TotalPayment,
                        PaymentConfirmation = Regex.Replace(x.FeeConfirmation, @"\s+", " "),
                        ProjectName = x.ProjectName
                    })
                    .FirstOrDefaultAsync();
                return (true, null, paymentDetails);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Errors)> UpdatePaymentDetailsAsync(EditTotalPaymentDetailDto payment)
        {
            try
            {
                var updatedetail = await _context.Projects.FindAsync(payment.ProjectId);
                if (payment.ProjectStatusName != null && payment.Payment != 0)
                {
                    var clientDetail = _context.Clients.Where(y => y.EnquiryId == payment.EnquiryId).FirstOrDefault();
                    var projectStatus = await _context.ProjectStatus
                        .Where(x => x.ProjectName == payment.ProjectStatusName && x.WorkType == payment.WorkType)
                        .Select(x => new
                        {
                            x.NormalPayment,
                            x.AgentPayment
                        })
                        .FirstOrDefaultAsync();
                    if ((clientDetail.IsAgent == true && projectStatus.AgentPayment != payment.Payment)
                                        || (clientDetail.IsAgent == false && projectStatus.NormalPayment != payment.Payment))
                    {
                        //var managers = await _context.Employees.Where(x => (x.DeptId == 1 && x.RoleId == 1 && x.IsActive == true) || (x.DeptId == 2 && x.RoleId == 1 && x.IsActive == true))
                        //                .Select(x => x.MemberId).ToListAsync();
                        IList<string> members = _slackConfig.FeeApproval.ToList();
                        string approvalMessage = "";
                        if ((clientDetail.IsAgent == true && projectStatus.AgentPayment > payment.Payment)
                        || (clientDetail.IsAgent == false && projectStatus.NormalPayment > payment.Payment))
                        {
                            approvalMessage = $"Project registered with Reduced payment. Kindly check and approve the Project ID :{updatedetail.ProjectRef} and Name :{clientDetail.ClientName}";
                        }
                        else if ((clientDetail.IsAgent == true && projectStatus.AgentPayment < payment.Payment)
                        || (clientDetail.IsAgent == false && projectStatus.NormalPayment < payment.Payment))
                        {
                            approvalMessage = $"Project registered with Increased payment. Kindly check and approve the Project ID :{updatedetail.ProjectRef} and Name :{clientDetail.ClientName}";
                        }
                        foreach (var item in members)
                        {
                            await _slack.SendMessage(approvalMessage, item);
                        }
                        updatedetail.PaymentApproval = true;
                    }
                    updatedetail.ProjectName = $"{payment.ProjectStatusName}_{payment.WorkType}";
                    updatedetail.TotalPayment = payment.Payment;
                }
                else
                {
                    updatedetail.TotalPayment = payment.TotalPayment;
                    updatedetail.ProjectName = payment.ProjectName;
                }
                updatedetail.FeeConfirmation = payment.PaymentConfirmation;
                _context.Update(updatedetail);
                _context.SaveChanges();
                return (true, null);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message });
            }
        }
        public async Task<(bool Succeeded, string[] Error, IList<ProjectStatusDto> Data)> GetProjectStatusAsync()
        {
            try
            {
                var ProjectStatusList = _context.ProjectStatus.ToList();
                var projectStatusDtoList = ProjectStatusList.Select(ps => _mapper.Map<ProjectStatusDto>(ps)).ToList();
                return (true, new string[] { }, projectStatusDtoList);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Error, ProjectStatus Projectstatus)> CreateNewProjectAsync(ProjectStatusDto projectStatusDto)
        {
            try
            {
                var map = _mapper.Map<ProjectStatus>(projectStatusDto);
                await _context.AddAsync(map);
                int result = await _context.SaveChangesAsync();
                return (true, new string[] { "Project added sucessfully" }, map);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }
        public async Task<(bool Succeeded, string[] Error, ProjectStatusDto Projectstatus)> GetProjectStatusListAsync(int projectStatusId)
        {
            try
            {
                var ProjectList = await _context.ProjectStatus.FindAsync(projectStatusId);
                var map = _mapper.Map<ProjectStatusDto>(ProjectList);
                return (true, new string[] { }, map);
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message }, null);
            }

        }
        public async Task<(bool Succeeded, string[] Error, ProjectStatus projectStatus)> UpdateProjectStatusListAsync(ProjectStatusDto projectStatusDto)
        {
            try
            {
                var existingProjectStatus = await _context.ProjectStatus.FindAsync(projectStatusDto.ProjectStatusId);

                if (existingProjectStatus == null)
                {
                    return (false, new string[] { "Phase not found" }, null);
                }
                existingProjectStatus.ProjectName = projectStatusDto.ProjectName;
                existingProjectStatus.WorkType = projectStatusDto.WorkType;
                existingProjectStatus.AgentPayment = projectStatusDto.AgentPayment;
                existingProjectStatus.NormalPayment = projectStatusDto.NormalPayment;
                existingProjectStatus.Incentive = projectStatusDto.Incentive;
                existingProjectStatus.ReducedIncentive = projectStatusDto.ReducedIncentive;
                _context.ProjectStatus.Update(existingProjectStatus);
                await _context.SaveChangesAsync();
                return (true, new string[] { "ProjectStatus updated successfully" }, existingProjectStatus);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<bool> DeleteProjectStatusAsync(int projectStatusId)
        {
            try
            {
                var DeleteProjectStatus = await _context.ProjectStatus.FindAsync(projectStatusId);
                if (DeleteProjectStatus != null)
                {
                    _context.ProjectStatus.Remove(DeleteProjectStatus);
                    await _context.SaveChangesAsync();
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while deleting the ProjectStatus.", ex);
            }
        }
        public async Task<(bool Succeeded, string[] Error, IList<ProjectStatusDto> Data)> GetProjectStatusDropdownAsync()
        {
            try
            {
                var projectStatusList = await _context.ProjectStatus.ToListAsync();
                var groupedProjectStatusList = projectStatusList.GroupBy(x => x.ProjectName).ToList();
                var projectStatusDtoList = groupedProjectStatusList.Select(ps => _mapper.Map<ProjectStatusDto>(ps.First())).ToList();
                //var ProjectStatusList = _context.ProjectStatus
                // .GroupBy(x => x.ProjectName)
                // .ToList();
                //var projectStatusDtoList = ProjectStatusList.Select(ps => _mapper.Map<ProjectStatusDto>(ps)).ToList();
                return (true, new string[] { }, projectStatusDtoList);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Errors, IList<SelectListItem> WorkTypes)> GetWorkTypesByProjectNameAsync(string projectName)
        {
            try
            {
                var workTypes = await _context.ProjectStatus
                                              .Where(wt => wt.ProjectName == projectName)
                                              .Select(wt => new SelectListItem
                                              {
                                                  Text = wt.WorkType,
                                                  Value = wt.ProjectStatusId.ToString()
                                              })
                                              .ToListAsync();

                return (true, new string[] { }, workTypes);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Errors, double payment)> GetPaymentProjectStatusAsync(int EnquiryId, string ProjectName, string WorkType)
        {
            try
            {
                var clientData = _context.Clients.Where(x => x.EnquiryId == EnquiryId).Select(x => x.IsAgent).FirstOrDefault();
                double Payment;
                if (clientData)
                {
                    Payment = _context.ProjectStatus.Where(wt => wt.ProjectName == ProjectName && wt.WorkType == WorkType)
                              .Select(wt => wt.AgentPayment).FirstOrDefault();
                }
                else
                {
                    Payment = _context.ProjectStatus.Where(wt => wt.ProjectName == ProjectName && wt.WorkType == WorkType)
                              .Select(wt => wt.NormalPayment).FirstOrDefault();
                }


                return (true, new string[] { }, Payment);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, 0);
            }
        }
        public async Task<(bool Succeeded, string[] Errors)> UpdatePaymentRemarkAsync(ApprovalDto approval)
        {
            try
            {
                var project = await _context.Projects.FindAsync(approval.ProjectId);
                if (project == null)
                {
                    return (false, new string[] { "Project not found" });
                }

                project.PaymentRemarks = approval.PaymentRemark;
                project.PaymentApproval = false;

                _context.Projects.Update(project);
                await _context.SaveChangesAsync();

                return (true, new string[] { "Payment remark added successfully" });
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message });
            }
        }
        public async Task<(bool Succeeded, string[] Errors)> UpdateTLAsync(ChangeTlInActive changeTL)
        {
            try
            {
                var EnquiryId = _context.Projects.Where(y => y.ProjectRef == changeTL.EnquiryRef).Select(y => y.EnquiryId).FirstOrDefault();
                var clientDetails = _context.Clients.Find(EnquiryId);
                var dept = _context.Employees.Where(x => x.EmpId == changeTL.TeamLeader).Select(x => x.DeptId).FirstOrDefault();
                if (dept == 2)
                {
                    clientDetails.TechTL = changeTL.TeamLeader;
                }
                else
                {
                    clientDetails.ProgrammerTL = changeTL.TeamLeader;
                }
                _context.Clients.Update(clientDetails);
                await _context.SaveChangesAsync();

                return (true, new string[] { "TechTL updated successfully" });
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message });
            }
        }

        public async Task<(bool Succeeded, string[] Errors)> CreatePhaseFileAsync(PhaseFiles file)
        {
            try
            {
                await _context.PhaseFiles.AddAsync(file);
                await _context.SaveChangesAsync();
                if (file.IsPublication)
                {
                    var clientName = _context.Phase.Where(x => x.PhaseId == file.PhaseId).Include(x => x.Projects)
                        .ThenInclude(x => x.Clients).Select(x => new
                        {
                            x.Projects.ProjectRef,
                            x.Projects.Clients.ClientName
                        }).FirstOrDefault();
                    IList<string> members = _slackConfig.PublicationFileUpload.ToList();
                    var message = $"Technical Manager has uploaded the approved manuscript for Project ID { clientName.ProjectRef} and Client {clientName.ClientName}. Please proceed with initiating the publication process.";
                    await SendUploadSlackMessage(members, message);          
                }
                return (true, new string[] { "Files added successfully" });
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message });
            }
        }
        private Task SendUploadSlackMessage(IList<string> members, string slackMessage)
        {
            return Task.Run(async () =>
            {
                try
                {
                    foreach (var item in members)
                    {
                        await _slack.SendMessage(slackMessage, item); // Send message for each member
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception($"Slack Message sending failed: {ex.Message}", ex); // Handle exceptions
                }
            });
        }
        public async Task<(bool Succeeded, string[] Errors)> DeletePhaseFileAsync(int phaseFileId)
        {
            try
            {
                var phaseFile = await _context.PhaseFiles.FindAsync(phaseFileId);
                var filePath = phaseFile.FilePath;
                if (System.IO.File.Exists(filePath))
                {
                    System.IO.File.Delete(filePath);
                    if (System.IO.File.Exists(filePath))
                    {
                        return (false, new string[] { $"File at path {filePath} could not be deleted." });
                    }
                    else if (!System.IO.File.Exists(filePath))
                    {
                        _context.PhaseFiles.Remove(phaseFile);
                        await _context.SaveChangesAsync();
                    }
                }

                return (true, new string[] { "Files Deleted successfully" });
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message });
            }
        }
        public async Task<(bool Succeeded, string[] Errors, bool hasFile)> GetPhaseFileDetailsAsync(int projectId)
        {
            try
            {
                var phaseId = _context.Phase.Where(x => x.ProjectId == projectId).OrderByDescending(x => x.PhaseId).Select(x => x.PhaseId).FirstOrDefault();
                bool hasFiles = await _context.PhaseFiles
                            .AnyAsync(x => x.PhaseId == phaseId);
                return (true, null, hasFiles);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, false);
            }
        }
        public async Task<(bool Succeeded, string[] Errors)> UpdatePhaseFileAsync(PhaseFiles file, int PhaseFileId)
        {
            try
            {
                    var phaseFile = await _context.PhaseFiles.FindAsync(PhaseFileId);
                    if (phaseFile == null)
                    {
                        return (false, new string[] { $"PhaseFile with ID {PhaseFileId} not found." });
                    }

                    var filePath = phaseFile.FilePath;
                    if (System.IO.File.Exists(filePath))
                    {
                        System.IO.File.Delete(filePath);
                        if (System.IO.File.Exists(filePath))
                        {
                            return (false, new string[] { $"File at path {filePath} could not be deleted." });
                        }
                    }

                    phaseFile.PhaseId = file.PhaseId;
                    phaseFile.EmpId = file.EmpId;
                    phaseFile.FileName = file.FileName;
                    phaseFile.FilePath = file.FilePath;

                    _context.Update(phaseFile);
                    await _context.SaveChangesAsync();                    
                return (true, new string[] { "Files updated successfully" });
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message });
            }
        }
        public async Task<(bool Succeeded, string[] Errors)> UpdateTLOrManagerPhaseFileAsync(PhaseFiles file, IList<int?> FileIds,string FolderName, bool IsPublication)
        {
            try
            {
                if (FileIds != null && FileIds.Any())
                {
                    foreach (var fileId in FileIds)
                    {
                        if (fileId.HasValue)
                        {
                            var oldFile = await _context.PhaseFiles.FindAsync(fileId.Value);
                            if (oldFile != null)
                            {
                                var oldFilePath = oldFile.FilePath;
                                if (System.IO.File.Exists(oldFilePath))
                                {
                                    System.IO.File.Delete(oldFilePath);
                                    if (System.IO.File.Exists(oldFilePath))
                                    {
                                        return (false, new string[] { $"File at path {oldFilePath} could not be deleted." });
                                    }
                                }
                                _context.PhaseFiles.Remove(oldFile);
                            }
                        }
                    }
                    await _context.SaveChangesAsync();
                }
                await _context.PhaseFiles.AddAsync(file);
                await _context.SaveChangesAsync();
                if (IsPublication)
                {
                    var clientName = await _context.Phase
                        .Where(x => x.PhaseId == file.PhaseId)
                        .Include(x => x.Projects)
                            .ThenInclude(x => x.Clients).ThenInclude(x=> x.TechTLEmployee)
                        .Select(x => new
                        {
                            ProjectRef = x.Projects.ProjectRef, 
                            ClientName = x.Projects.Clients.ClientName, 
                            TechMemberId = x.Projects.Clients.TechTLEmployee.MemberId,
                            MemberId = x.TechExpert.HasValue ? x.Employees.MemberId : string.Empty,
                            MemberId1 = x.TechExpert.HasValue ? x.Employees1.MemberId : string.Empty,
                            MemberId2 = x.TechExpert.HasValue ? x.Employees2.MemberId : string.Empty,
                            MemberId3 = x.TechExpert.HasValue ? x.Employees3.MemberId : string.Empty
                        })
                        .FirstOrDefaultAsync();
                    
                    if (clientName == null)
                    {
                        return (false, new string[] { "Client information not found for the given Phase ID." });
                    }

                    List<string> members = new List<string>();
                    members.Add(clientName.TechMemberId);
                    members.Add(clientName.MemberId);
                    members.Add(clientName.MemberId1);
                    members.Add(clientName.MemberId2);
                    members.Add(clientName.MemberId3);
                    members = members.Where(member => !string.IsNullOrEmpty(member)).ToList();
                    var message = $"Technical Manager has requested a review of the {FolderName} for Project ID {clientName.ProjectRef} and Client {clientName.ClientName}. Kindly proceed with initiating the correction process.";
                    await SendUploadSlackMessage(members, message);
                }
                return (true, new string[] { "Files updated successfully" });
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message });
            }
        }

        public async Task<(bool Succeeded, string[] Errors, PlagiarismRecipient plag)> GetPlagiarismRecipientDetailsAsync(int plagiarismRecipientId)
        {
            try
            {
                var plag = await _context.PlagiarismRecipient.FindAsync(plagiarismRecipientId);
                return (true, null, plag);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }

        public async Task<(bool Succeeded, string[] Errors)> StoreFileIdInPlagiarismRecipientAsync(int plagiarismRecipientId, string fileId)
        {
            try
            {
                var plag = await _context.PlagiarismRecipient.FindAsync(plagiarismRecipientId);
                plag.StoreFileId = fileId;
                _context.PlagiarismRecipient.UpdateRange(plag);
                await _context.SaveChangesAsync();

                return (true, new string[] { "Store FileId successfully stored " });
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message });
            }
        }
    }
}

