﻿using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Reactive.Linq;
using Enquiry.Blazor.Models;
using Google.Apis.Drive.v3;
using Enquiry.Blazor.Services.Interface;
using Google.Apis.Auth.OAuth2.Flows;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Auth.OAuth2.Responses;
using Google.Apis.Drive.v3.Data;
using Google.Apis.Services;
using Microsoft.EntityFrameworkCore;
using Google.Apis.Upload;
using static Google.Apis.Drive.v3.FilesResource;

namespace Enquiry.Blazor.Services
{
    public class GoogleAuthService : IGoogleAuthService
    {
        private readonly GoogleAuthConfig _googleAuthConfig;
        private readonly string[] _scopes = { DriveService.Scope.DriveFile };
        private readonly HttpContext _httpContext;
        private readonly IUrlHelper _urlHelper;
        private readonly string _applicationName = "Portal";
        readonly ApplicationDbContext _context;
        readonly ISlack _slack;
        public GoogleAuthService(IHttpContextAccessor httpContextAccessor, IUrlHelperFactory urlHelperFactory, ApplicationDbContext context, ISlack slack,
            IOptions<GoogleAuthConfig> googleAuthConfig = null)
        {
            _googleAuthConfig = googleAuthConfig.Value;
            _httpContext = httpContextAccessor.HttpContext;
            _context = context;
            _slack = slack;
            var actionContext = new ActionContext(
            _httpContext,
            _httpContext.GetRouteData(),
            new Microsoft.AspNetCore.Mvc.Abstractions.ActionDescriptor());

            _urlHelper = urlHelperFactory.GetUrlHelper(actionContext);
        }

        public string GetGoogleAuthUrl()
        {
            //string tempUrl = "https://actively-brief-mastiff.ngrok-free.app/Login/GoogleAuthCallback";
            var scheme = _httpContext.Request.Scheme;
            var host = _httpContext.Request.Host.Host;
            var port = _httpContext.Request.Host.Port ?? (scheme == "https" ? 443 : 80);

            var redirectUri = _urlHelper.Action("GoogleAuthCallback", "Login", null, scheme);

            var authUri = new GoogleAuthorizationCodeFlow(new GoogleAuthorizationCodeFlow.Initializer
            {
                ClientSecrets = new ClientSecrets
                {
                    ClientId = _googleAuthConfig.ClientId,
                    ClientSecret = _googleAuthConfig.ClientSecret
                },
                Scopes = _scopes
            });
            // Build the base authorization URL
            var authorizationUrl = authUri.CreateAuthorizationCodeRequest(redirectUri).Build();

            // Manually append the access_type=offline and prompt=consent parameters
            string fullAuthUrl = authorizationUrl + "&prompt=consent";

            return fullAuthUrl;
        }

        public async Task<TokenResponse> GetUserCredential(string code)
        {
            var scheme = _httpContext.Request.Scheme;
            var host = _httpContext.Request.Host.Host;
            var port = _httpContext.Request.Host.Port ?? (scheme == "https" ? 443 : 80);

            var callbackUrl = _urlHelper.Action("GoogleAuthCallback", "Login", null, scheme);
            // Create the full redirect URI
            var redirectUri = callbackUrl;

            // Get the authenticated user's email
            var email = _httpContext.User.FindFirst(claim => claim.Type == "email")?.Value;

            var authCodeFlow = new GoogleAuthorizationCodeFlow(new GoogleAuthorizationCodeFlow.Initializer
            {
                ClientSecrets = new ClientSecrets
                {
                    ClientId = _googleAuthConfig.ClientId,
                    ClientSecret = _googleAuthConfig.ClientSecret
                },
                Scopes = _scopes
            });

            TokenResponse tokenResponse = await authCodeFlow.ExchangeCodeForTokenAsync(email, code, redirectUri, CancellationToken.None);
            return tokenResponse;
        }

        public UserCredential GetGoogleCredential(string accessToken)
        {
            if (string.IsNullOrEmpty(accessToken))
            {
                // Redirect to the authentication flow if access token is missing
                return null;
            }

            var email = _httpContext.User.FindFirst(claim => claim.Type == "email")?.Value;
            var token = new TokenResponse { AccessToken = accessToken };
            var credentials = new UserCredential(new GoogleAuthorizationCodeFlow(
                new GoogleAuthorizationCodeFlow.Initializer
                {
                    ClientSecrets = new ClientSecrets
                    {
                        ClientId = _googleAuthConfig.ClientId,
                        ClientSecret = _googleAuthConfig.ClientSecret
                    }
                }), email, token);

            return credentials;
        }

        public async Task<GoogleCredential> RefreshTokenAsync(string refreshToken)
        {
            var authCodeFlow = new GoogleAuthorizationCodeFlow(new GoogleAuthorizationCodeFlow.Initializer
            {
                ClientSecrets = new ClientSecrets
                {
                    ClientId = _googleAuthConfig.ClientId,
                    ClientSecret = _googleAuthConfig.ClientSecret
                },
                Scopes = _scopes,
            });

            var email = _httpContext.User.FindFirst(claim => claim.Type == "email")?.Value;
            var tokenResponse = await authCodeFlow.RefreshTokenAsync(email, refreshToken, CancellationToken.None);
            return GoogleCredential.FromAccessToken(tokenResponse.AccessToken);
        }

        public async Task<UserCredential> GetUserCredentialFromGoogleCredential(GoogleCredential googleCredential, string refreshToken)
        {
            var clientSecrets = new ClientSecrets
            {
                ClientId = _googleAuthConfig.ClientId,
                ClientSecret = _googleAuthConfig.ClientSecret
            };

            // Manually refresh the access token using the GoogleCredential
            var newAccessToken = await googleCredential.UnderlyingCredential.GetAccessTokenForRequestAsync();

            var email = _httpContext.User.FindFirst(claim => claim.Type == "email")?.Value;

            var userCredential = new UserCredential(
                new GoogleAuthorizationCodeFlow(new GoogleAuthorizationCodeFlow.Initializer
                {
                    ClientSecrets = clientSecrets,
                    Scopes = _scopes,
                }),
                email,
                new TokenResponse
                {
                    AccessToken = newAccessToken,
                    RefreshToken = refreshToken
                });

            return userCredential;
        }

        public async Task<string> GetGoogleDocsEditUrlAsync(string fileId, UserCredential credential, string fileName)
        {
            var driveService = new DriveService(new BaseClientService.Initializer
            {
                HttpClientInitializer = credential, // Use your authenticated credential here
                ApplicationName = _applicationName
            });
            string mimeType = GetMimeType(fileName);
            string docUrl = string.Empty;
            var email = _httpContext.User.FindFirst(claim => claim.Type == "email")?.Value;
            try
            {
                var permission = await driveService.Permissions.Create(new Permission
                {
                    Role = "commenter", // Role of commenter
                    Type = "user",      // Type of user
                    EmailAddress = email // Replace with the actual email address
                }, fileId).ExecuteAsync();
                if (mimeType == "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
                {
                    docUrl = $"https://docs.google.com/document/d/{fileId}/edit";
                }
                else if (mimeType == "application/pdf" || mimeType == "application/vnd.visio" || mimeType == "application/vnd.ms-visio.drawing")
                {
                    docUrl = $"https://drive.google.com/file/d/{fileId}/preview";
                }
                else if (mimeType == "application/vnd.ms-excel" || mimeType == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                {
                    docUrl = $"https://docs.google.com/spreadsheets/d/{fileId}/edit";
                }
                else
                {
                    docUrl = $"https://docs.google.com/document/d/{fileId}/edit";
                }

                return docUrl.ToString();
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<Google.Apis.Drive.v3.Data.File> GetFileMetadataFromDrive(UserCredential credential, string fileId)
        {
            var driveService = new DriveService(new BaseClientService.Initializer
            {
                HttpClientInitializer = credential,
                ApplicationName = _applicationName
            });

            try
            {
                // Get the file metadata using the fileId
                var request = driveService.Files.Get(fileId);
                var fileMetadata = await request.ExecuteAsync();
                return fileMetadata;
            }
            catch (Google.GoogleApiException ex)
            {
                // Handle the case where the file is not found (404 error)
                if (ex.HttpStatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    return null; // File does not exist in Google Drive
                }
                throw; // Rethrow for other exceptions
            }
            catch (Exception ex) 
            { 
                throw; 
            }
        }

        public async Task DeleteFileFromDrive(UserCredential credential, string fileId)
        {
            var driveService = new DriveService(new BaseClientService.Initializer
            {
                HttpClientInitializer = credential, // Use your authenticated credential here
                ApplicationName = _applicationName
            });

            driveService.Files.Delete(fileId);
        }

        public async Task DownloadFileFromDrive(UserCredential credential, string destinationFilePath, bool sendOnSlack, int plagiarismRecipientId)
        {
            var plagRecip = await _context.PlagiarismRecipient
                .Where(x=>x.PlagiarismRecipientId == plagiarismRecipientId).Include(x=>x.Plagiarism).Include(x=>x.Employees)
                .Include(x => x.Plagiarism).ThenInclude(x=>x.Phase).FirstOrDefaultAsync();
            var driveService = new DriveService(new BaseClientService.Initializer
            {
                HttpClientInitializer = credential,
                ApplicationName = _applicationName
            });

            try
            {
                // Get the file metadata
                var request = driveService.Files.Get(plagRecip.StoreFileId);

                // Use the MediaDownloader to download the file
                using (var memoryStream = new MemoryStream())
                {
                    // Execute the request and download the file
                    await request.DownloadAsync(memoryStream);

                    // Save the file to the local file path
                    using (var fileStream = new FileStream(destinationFilePath, FileMode.Create, FileAccess.Write))
                    {
                        memoryStream.WriteTo(fileStream);
                    }
                }
                if (sendOnSlack)
                {
                    string message = $"The plagiarism that you are checked for phase {plagRecip.Plagiarism?.Phase.PhaseName} is under correction";
                    await _slack.SendMessage(message, plagRecip?.Employees.MemberId);
                }
                else
                {
                    await DeleteFileFromDrive(credential, plagRecip.StoreFileId);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<(IUploadProgress uploadProgress,CreateMediaUpload mediaUpload)> AddFileToDrive(UserCredential credential, string filename, string filePath)
        {
            var driveService = new DriveService(new BaseClientService.Initializer
            {
                HttpClientInitializer = credential, // Use your authenticated credential here
                ApplicationName = _applicationName
            });

            var fileMetadata = new Google.Apis.Drive.v3.Data.File()
            {
                Name = filename
            };
            try
            {
                using (var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                {
                    // Get MIME type based on file extension
                    var mimeType = GetMimeType(filename);

                    // Create the file upload request
                    var request = driveService.Files.Create(fileMetadata, fileStream, mimeType);
                    request.Fields = "id";

                    // Upload the file
                    IUploadProgress uploadProgress = await request.UploadAsync();

                    // Return the upload progress
                    return (uploadProgress, request); // Directly return IUploadProgress
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<StoreGoogleTokens> CreateGoogleToken(StoreGoogleTokens token)
        {
            await _context.AddAsync(token);
            await _context.SaveChangesAsync();
            return token;
        }

        public async Task<StoreGoogleTokens> GetGoogleToken(int userId)
        {
            var token = await _context.StoreGoogleTokens.Where(x => x.UserId == userId).FirstOrDefaultAsync();
            return token;
        }
        public async Task<StoreGoogleTokens> UpdateGoogleToken(StoreGoogleTokens token)
        {
            var user = await _context.StoreGoogleTokens.Where(x => x.UserId == token.UserId).FirstOrDefaultAsync();
            if (user == null) return null;
            user.AccessToken = token.AccessToken;
            if(!string.IsNullOrEmpty(token.RefreshToken)) user.RefreshToken = token.RefreshToken;
            user.ExpiresIn = token.ExpiresIn;
            user.ExpiryTime = token.ExpiryTime;
            _context.Update(user);
            await _context.SaveChangesAsync();
            return token;
        }

        public async Task<bool> EnsureGoogleAuthAsync(int userId)
        {
            var token = await GetGoogleToken(userId);
            // Check if access token exists
            if (token == null || (token != null && string.IsNullOrEmpty(token.AccessToken)))
            {
                return false; // Token does not exist, re-authentication is needed
            }

            // Optionally, check the expiration of the token if you stored it
            if (token != null && IsTokenExpired(token.ExpiryTime))
            {
                // Try refreshing the token using the refresh token
                if (!string.IsNullOrEmpty(token.RefreshToken))
                {
                    var googleCredential = await RefreshTokenAsync(token.RefreshToken);
                    if (googleCredential != null)
                    {
                        // Store the new access token and refresh token
                        var accessToken = await googleCredential.UnderlyingCredential.GetAccessTokenForRequestAsync();
                        var tokenExpiryTime = DateTime.Now.AddSeconds(3599);
                        long expiresIn = (long)(tokenExpiryTime - DateTime.UtcNow).TotalSeconds;
                        var store = new StoreGoogleTokens()
                        {
                            UserId = userId,
                            AccessToken = accessToken,
                            RefreshToken = token.RefreshToken,
                            ExpiresIn = expiresIn,
                            ExpiryTime = tokenExpiryTime,
                        };
                        await UpdateGoogleToken(store);
                    }
                }

                return true; // Refresh failed, re-authentication is needed
            }

            return true; // Token is valid, no need to re-authenticate
        }

        private bool IsTokenExpired(DateTime ExpiryTime)
        {
            return DateTime.Now >= ExpiryTime;
        }

        public static string GetMimeType(string filePath)
        {
            var extension = Path.GetExtension(filePath)?.ToLowerInvariant();

            var mimeTypes = new Dictionary<string, string>(StringComparer.InvariantCultureIgnoreCase)
                {
                    { ".doc", "application/msword" },
                    { ".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document" },
                    { ".pdf", "application/pdf" },
                    { ".txt", "text/plain" },
                    { ".jpg", "image/jpeg" },
                    { ".png", "image/png" },
                    { ".xls", "application/vnd.ms-excel" },
                    { ".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" },
                    { ".ppt", "application/vnd.ms-powerpoint" },
                    { ".pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation" },
                    { ".vsd", "application/vnd.visio" },  // Visio binary file
                    { ".vsdx", "application/vnd.ms-visio.drawing" },  // Visio drawing (XML-based)
                    { ".vsdm", "application/vnd.ms-visio.drawing.macroenabled.12" },  // Visio macro-enabled drawing
                    { ".vss", "application/vnd.visio" },  // Visio stencil file
                    { ".vssx", "application/vnd.ms-visio.stencil" },  // Visio stencil (XML-based)
                    { ".vst", "application/vnd.visio" },  // Visio template file
                    { ".vstx", "application/vnd.ms-visio.template" },  // Visio template (XML-based)
                    { ".vstm", "application/vnd.ms-visio.template.macroenabled.12" },  // Visio macro-enabled template
                };

            if (extension != null && mimeTypes.TryGetValue(extension, out var mimeType))
            {
                return mimeType;
            }

            // Return default MIME type if not found
            return "application/octet-stream";
        }
    }
}
