﻿using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Extensions;
using Enquiry.Blazor.Models;
using Enquiry.Blazor.Services.Interface;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Options;
using MimeKit;
using System.Text.RegularExpressions;

namespace Enquiry.Blazor.Services
{
    public class EmailService : IEmail
    {
        readonly ApplicationDbContext _context;
        readonly ISlack _slack;
        private readonly IDistributedCache _cache;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly SlackConfig _slackConfig;
        public EmailService(ApplicationDbContext context, ISlack slack, IDistributedCache cache, IHttpContextAccessor httpContextAccessor, IOptions<SlackConfig> slackConfig = null)
        {
            _context = context;
            _slack = slack;
            _cache = cache;
            _httpContextAccessor = httpContextAccessor;
            _slackConfig = slackConfig.Value;
        }

        public async Task<(bool Succeeded, string[] Errors)> CreateEmailDetailsAsync(MimeMessage message, uint uid)
        {
            var errors = new List<string>();

            try
            {
                var emailDetails = _context.Emails.Where(x => x.MessageId == message.MessageId && x.ReceivedDate == message.Date.DateTime).FirstOrDefault();
                if (emailDetails == null)
                {
                    var email = new Emails
                    {
                        FromAddress = ExtractEmailAddress(message.From.ToString()),
                        ToAddress = ExtractEmailAddress(message.To.ToString()),
                        ClientName = ExtractClientName(message.From.ToString()),
                        Subject = message.Subject,
                        Body = message.HtmlBody,
                        ReceivedDate = message.Date.DateTime,
                        IsRead = false,
                        MessageId = message.MessageId
                    };

                    await _context.Emails.AddAsync(email);
                    await _context.SaveChangesAsync(); // Save the email to get the EmailId asynchronously

                    var attachmentPaths = SaveAttachments(message.Attachments, email.EmailId);
                    foreach (var path in attachmentPaths)
                    {
                        _context.EmailAttachmentsFiles.Add(new EmailAttachmentsFiles
                        {
                            EmailId = email.EmailId,
                            AttachmentFilePath = path.FilePath,
                            AttachmentFileName = path.FileName
                        });
                    }

                    await _context.SaveChangesAsync().ConfigureAwait(false);
                    //var enquiryExists = _context.Clients.Where(x => message.Subject.Contains(x.EnquiryRef) && message.Subject.Contains("Enquiry")).Select(x=> new {ClientName = x.ClientName, EnquiryRef = x.EnquiryRef}).FirstOrDefault();
                    //var projectExists = _context.Projects.Where(x => message.Subject.Contains(x.ProjectRef) && message.Subject.Contains(x.ProjectName)).Include(x=> x.Clients).Select(x => new { ClientName = x.Clients.ClientName, ProjectRef = x.ProjectRef }).FirstOrDefault();
                    //var publicationExists = _context.Projects.Include(x=> x.Phase).Where(x => message.Subject.Contains(x.ProjectRef) && message.Subject.Contains(x.Phase.Where(p => p.Status == 4).OrderByDescending(p => p.PhaseId).Select(p => p.PhaseName).FirstOrDefault())).Include(x=> x.Clients).Select(x => new { ClientName = x.Clients.ClientName, ProjectRef = x.ProjectRef }).FirstOrDefault();
                    var currentEmail = _context.Emails.Find(email.EmailId);
                    //if (enquiryExists != null)
                    //{
                    //    IList<string> members = _slackConfig.EnquiryEmailChecker.ToList();
                    //    string MemberId = string.Join("/", members);
                    //    currentEmail.MemberId = MemberId;
                    //    _context.SaveChanges();

                    //    string slackMessage = $"We have received an email from {enquiryExists.ClientName} {enquiryExists.EnquiryRef}";
                    //    await SendSlackMessage(members, slackMessage);
                    //}
                    //else if (projectExists != null)
                    //{
                    //    IList<string> members = _slackConfig.ProductionEmailChecker.ToList();
                    //    string MemberId = string.Join("/", members);
                    //    currentEmail.MemberId = MemberId;
                    //    _context.SaveChanges();

                    //    string slackMessage = $"We have received an email from {projectExists.ClientName} {projectExists.ProjectRef}";
                    //    await SendSlackMessage(members, slackMessage);
                    //}
                    //else if (publicationExists != null)
                    //{
                    //    IList<string> members = _slackConfig.PublicationEmailChecker.ToList();
                    //    string MemberId = string.Join("/", members);
                    //    currentEmail.MemberId = MemberId;
                    //    _context.SaveChanges();

                    //    string slackMessage = $"We have received an email from {publicationExists.ClientName} {publicationExists.ProjectRef}";
                    //    await SendSlackMessage(members, slackMessage);
                    //}
                    //else 
                    //{
                    var emailChecker = await _context.Employees
                            .Where(x => x.IsActive && x.IsEmailChecker)
                            .Select(x => x.MemberId)
                            .ToListAsync();

                    string MemberId = string.Join("/", emailChecker);
                    currentEmail.MemberId = MemberId;
                    _context.SaveChanges();

                    string slackMessage = $"We have received an email from {email.ClientName}";
                    await SendSlackMessage(emailChecker, slackMessage);
                    //}
                }
                return (true, Array.Empty<string>()); 
            }
            catch (Exception ex)
            {
                errors.Add(ex.Message); 
                return (false, errors.ToArray()); 
            }
        }
        private Task SendSlackMessage(IList<string> members, string slackMessage)
        {
            return Task.Run(async () =>
            {
                try
                {
                    foreach (var item in members)
                    {
                        await _slack.SendMessage(slackMessage, item); // Send message for each member
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception($"Slack Message sending failed: {ex.Message}", ex); // Handle exceptions
                }
            });
        }
        private string ExtractEmailAddress(string fromAddress)
        {
            var match = Regex.Match(fromAddress, @"<(.+?)>");
            return match.Success ? match.Groups[1].Value : fromAddress;
        }

        private string ExtractClientName(string fromAddress)
        {
            try
            {
                var mailboxAddress = MailboxAddress.Parse(fromAddress);
                return mailboxAddress.Name;
            }
            catch (FormatException)
            {
                return "Unknown";
            }
        }

        private (string FilePath, string FileName)[] SaveAttachments(IEnumerable<MimeEntity> attachments, int emailId)
        {
            var attachmentPaths = new List<(string FilePath, string FileName)>();

            // Define the upload path and ensure the directory exists
            string uploadFolderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", "Email");
            if (!Directory.Exists(uploadFolderPath))
            {
                Directory.CreateDirectory(uploadFolderPath);
            }

            foreach (var attachment in attachments)
            {
                if (attachment is MimePart mimePart)
                {
                    var fileName = mimePart.ContentDisposition?.FileName ?? mimePart.ContentType.Name;
                    var filePath = Path.Combine(uploadFolderPath, fileName);

                    using (var stream = System.IO.File.Create(filePath))
                    {
                        mimePart.Content.DecodeTo(stream);
                    }

                    attachmentPaths.Add((filePath, fileName));
                }
            }

            return attachmentPaths.ToArray();
        }      
        public async Task<(bool Succeeded, string[] Errors, IList<EmailDto> Emails, bool IsMemberId,string Designation)> GetEmailDetailsAsync(char chkValue)
        {
            try
            {
                var Role = _httpContextAccessor.HttpContext.Session.GetString("Role");
                var Dept = _httpContextAccessor.HttpContext.Session.GetString("Dept");
                var MemberId = _httpContextAccessor.HttpContext.Session.GetString("MemberId");
                IQueryable<Emails> emailQuery = _context.Emails.Include(x => x.EmailAttachmentsFiles);
                var project = await _context.Projects
                    .Include(x => x.Phase).ThenInclude(x => x.Employees)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees1)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees2)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees3)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees4)
                    .Include(x => x.Phase).ThenInclude(x => x.Employees5)
                    .Include(x => x.Clients).ThenInclude(x => x.TechTLEmployee)
                    .Include(x => x.Clients).ThenInclude(x => x.ProgrammerTLEmployee)
                    .Where(x =>
                        x.Phase.OrderBy(p => p.PhaseId).LastOrDefault().Employees.MemberId == MemberId ||
                        x.Phase.OrderBy(p => p.PhaseId).LastOrDefault().Employees1.MemberId == MemberId ||
                        x.Phase.OrderBy(p => p.PhaseId).LastOrDefault().Employees2.MemberId == MemberId ||
                        x.Phase.OrderBy(p => p.PhaseId).LastOrDefault().Employees3.MemberId == MemberId ||
                        x.Phase.OrderBy(p => p.PhaseId).LastOrDefault().Employees4.MemberId == MemberId ||
                        x.Phase.OrderBy(p => p.PhaseId).LastOrDefault().Employees5.MemberId == MemberId ||
                        x.Clients.TechTLEmployee.MemberId == MemberId ||
                        x.Clients.ProgrammerTLEmployee.MemberId == MemberId)
                    .Select(x => x.ProjectId)
                    .ToListAsync();
                var enquiry = await _context.Clients.Include(x => x.BDAEmployee).Where(x => x.BDAEmployee.MemberId == MemberId).Select(x => x.EnquiryId).ToListAsync();
                var emailChecker = await _context.Employees.Where(x => x.IsActive && x.IsEmailChecker).Select(x => x.MemberId).ToListAsync();
                var Designation = _context.Employees.Where(x => x.IsActive && x.MemberId == MemberId.ToString()).Select(x => x.Designation).FirstOrDefault();
                switch (chkValue)
                {
                    case 'U': // Unread
                        if ((Dept == Enum.Department.BDA.ToString() || Dept == Enum.Department.Tech.ToString())
                            && Role == Enum.Roles.Manager.ToString())
                        {
                            emailQuery = emailQuery.Where(x => !x.IsRead && !x.IsSender && !x.IsTrashMail);
                        }
                        else if (emailChecker.Contains(MemberId))
                        {
                            emailQuery = emailQuery.Where(x => x.MemberId.Contains(MemberId.ToString()) && !x.IsRead && !x.IsSender && !x.IsTrashMail);
                        }
                        else
                        {
                            emailQuery = Enumerable.Empty<Emails>().AsQueryable();
                        }
                        break;
                    case 'R': // Read
                        if ((Dept == Enum.Department.BDA.ToString() || Dept == Enum.Department.Tech.ToString())
                            && Role.ToString() == Enum.Roles.Manager.ToString())
                        {
                            emailQuery = emailQuery.Where(x => x.IsRead && !x.IsSender && !x.IsTrashMail);
                        }
                        else if (emailChecker.Contains(MemberId))
                        {
                            emailQuery = emailQuery.Where(x => x.MemberId.Contains(MemberId.ToString()) && x.IsRead && !x.IsSender && !x.IsTrashMail);
                        }
                        else if (Designation == "Front Office Executive")
                        {
                            emailQuery = emailQuery.Where(x => x.IsRead && !x.IsSender && x.ProjectId != null && !x.IsTrashMail);
                        }
                        else if (Designation == "Marketing Manager")
                        {
                            emailQuery = emailQuery.Where(x => x.IsRead && !x.IsSender && x.EnquiryId != null && !x.IsTrashMail);
                        }
                        else if (Dept == Enum.Department.Tech.ToString() || Dept == Enum.Department.Programming.ToString())
                        {
                            emailQuery = emailQuery.Where(x => x.IsRead && !x.IsSender && x.ProjectId.HasValue && project.Contains(x.ProjectId.Value) && !x.Visibility && !x.IsTrashMail);
                        }
                        else if (Dept == Enum.Department.BDA.ToString())
                        {
                            emailQuery = emailQuery.Where(x => x.IsRead && !x.IsSender && x.EnquiryId.HasValue && enquiry.Contains(x.EnquiryId.Value) && !x.IsTrashMail);
                        }
                        else
                        {
                            emailQuery = Enumerable.Empty<Emails>().AsQueryable();
                        }

                        break;
                    case 'S': // Sent
                        if ((Dept == Enum.Department.BDA.ToString() || Dept == Enum.Department.Tech.ToString())
                            && Role.ToString() == Enum.Roles.Manager.ToString())
                        {
                            emailQuery = emailQuery.Where(x => !x.IsRead && x.IsSender && !x.IsTrashMail);
                        }
                        else if (emailChecker.Contains(MemberId))
                        {
                            emailQuery = emailQuery.Where(x => !x.IsRead && x.IsSender && !x.IsTrashMail);
                        }
                        else if (Designation == "Front Office Executive")
                        {
                            emailQuery = emailQuery.Where(x => !x.IsRead && x.IsSender && x.ProjectId != null && !x.IsTrashMail);
                        }
                        else if (Designation == "Marketing Manager")
                        {
                            emailQuery = emailQuery.Where(x => !x.IsRead && x.IsSender && x.EnquiryId != null && !x.IsTrashMail);
                        }
                        else if (Dept == Enum.Department.Tech.ToString() || Dept.ToString() == Enum.Department.Programming.ToString())
                        {
                            emailQuery = emailQuery.Where(x => !x.IsRead && x.IsSender && x.ProjectId.HasValue && project.Contains(x.ProjectId.Value) && !x.Visibility && !x.IsTrashMail);
                        }
                        else if (Dept.ToString() == Enum.Department.BDA.ToString())
                        {
                            emailQuery = emailQuery.Where(x => !x.IsRead && x.IsSender && x.EnquiryId.HasValue && enquiry.Contains(x.EnquiryId.Value) && !x.IsTrashMail);
                        }
                        else
                        {
                            emailQuery = Enumerable.Empty<Emails>().AsQueryable();
                        }
                        break;
                    case 'T':
                        emailQuery = emailQuery.Where(x => !x.IsRead && !x.IsSender && x.IsTrashMail);
                        break;
                    case 'N': // Pending Reply
                        //var email = emailQuery.Where(x => x.IsRead).Select(x => new
                        //{
                        //    EnquiryId =x.EnquiryId,
                        //    ProjectId = x.ProjectId
                        //}).ToList();
                        //emailQuery = emailQuery.GroupBy(x => new { x.ProjectId, x.EnquiryId });
                        break;
                }
                var emailDetails = await emailQuery
                    .Select(x => new EmailDto
                    {
                        EmailId = x.EmailId,
                        FromAddress = x.FromAddress,
                        ToAddress = x.ToAddress,
                        IsFromAddress = _context.Clients
                                    .Any(y => y.Contact.Contains(x.FromAddress)),
                        IsToAddress = _context.Clients
                                    .Any(y => y.Contact.Contains(x.ToAddress)),
                        //ClientName = _context.Clients
                        //        .Where(c => c.Contact.Contains(x.FromAddress))
                        //        .Select(c => c.ClientName)
                        //        .FirstOrDefault() ?? x.ClientName,
                        ClientName = x.EnquiryId != null
            ? _context.Clients
                .Where(c => c.EnquiryId == x.EnquiryId)
                .Select(c => c.ClientName)
                .FirstOrDefault() + " - " +
                _context.Clients
                .Where(c => c.EnquiryId == x.EnquiryId)
                .Select(c => c.EnquiryRef)
                .FirstOrDefault()
            : x.ProjectId != null
                ? _context.Clients
                    .Where(c => c.Contact.Contains(x.FromAddress))
                    .Select(c => c.ClientName)
                    .FirstOrDefault() + " - " +
                    _context.Projects
                    .Where(p => p.ProjectId == x.ProjectId)
                    .Select(p => p.ProjectRef)
                    .FirstOrDefault()
                : _context.Clients
                    .Where(c => c.Contact.Contains(x.FromAddress))
                    .Select(c => c.ClientName)
                    .FirstOrDefault() ?? x.ClientName,
                        Subject = x.Subject,
                        Body = x.IsRead ? x.UpdatedMessage : x.Body,
                        EnquiryId = x.EnquiryId,
                        IsSender = x.IsSender,
                        ProjectId = x.ProjectId != null && !x.IsPublication ? x.ProjectId : null,
                        PublicationProjectId = x.ProjectId != null && x.IsPublication ? x.ProjectId : null,
                        ReceivedDate = x.ReceivedDate,
                        UpdatedBy = _context.Employees
                            .Where(y => y.EmpId == x.UpdatedBy)
                            .Select(y => y.EmployeeName)
                            .FirstOrDefault(),
                        EmailAttachmentDto = x.EmailAttachmentsFiles.Where(a =>
                                (Dept == Enum.Department.Tech.ToString() && x.IsTechVisibility && a.IsSelected && Role != Enum.Roles.Manager.ToString()) ||
                                    (Dept == Enum.Department.Programming.ToString() && x.IsProgrammerVisibility && a.IsSelected && Role != Enum.Roles.Manager.ToString()) ||
                                    Dept == Enum.Department.BDA.ToString() || Role == Enum.Roles.Manager.ToString()
                                ).Select(a => new EmailAttachmentDto
                                {
                                    AttachmentFilePath = a.AttachmentFilePath,
                                    AttachmentFileName = a.AttachmentFileName
                                }).ToList(),                      
                        SenderClientName = x.EnquiryId != null
                            ? _context.Clients
                                .Where(c => c.EnquiryId == x.EnquiryId)
                                .Select(c => c.ClientName)
                                .FirstOrDefault()
                            : x.ProjectId != null
                                ? _context.Projects.Include(c => c.Clients)
                                    .Where(c => c.Clients.Contact.Contains(x.ToAddress) && c.ProjectId == x.ProjectId)
                                    .Select(c => c.Clients.ClientName)
                                    .FirstOrDefault()
                                : _context.Clients
                                    .Where(c => c.Contact.Contains(x.ToAddress))
                                    .Select(c => c.ClientName)
                                    .FirstOrDefault() ?? x.ClientName,
                    })
                    .OrderByDescending(x => x.ReceivedDate)
                    .ToListAsync();
                var IsMemberId = _context.Emails.Where(x => !x.IsRead).Any(x => x.MemberId.Contains(MemberId.ToString()));
                return (true, Array.Empty<string>(), emailDetails, IsMemberId, Designation);
            }
            catch (Exception ex)
            {
                return (false, new[] { ex.Message }, new List<EmailDto>(), false, null);
            }
        }
        public async Task<(bool Succeeded, string[] Errors, IList<EnquiryDropdown> Enquiry, IList<ProjectDropdown> Project, IList<PublicationDropdown> Publication)> GetDropdownListAsync(string Email)
        {
            try
            {
                var enquires = await _context.Clients
                    .Where(x => x.Contact.Contains(Email))
                    .Include(x => x.Projects)
                        .ThenInclude(p => p.Phase)
                            .ThenInclude(ph => ph.WorkStatus)
                    .Include(x => x.TechTLEmployee)
                    .Include(x => x.Projects).ThenInclude(x => x.Publication).ThenInclude(x=> x.JournalStatus)
                    .ToListAsync();

                var enquiryDropdown = enquires.Where(x => !x.Registered)
                    .Select(x => new EnquiryDropdown
                    {
                        EnquiryId = x.EnquiryId,
                        ClientName = x.ClientName,
                        TechTl = x.TechTLEmployee?.EmployeeName,
                        EnquiryRef = x.EnquiryRef
                    })
                    .ToList();

                var projectDropdown = enquires.Where(x => x.Registered)
                    .SelectMany(x => x.Projects
                        .Select(ph => new ProjectDropdown
                        {
                            ProjectId = ph.ProjectId,
                            ClientName = ph.Clients.ClientName,
                            ProjectRef = ph.ProjectRef,
                            ProjectName = ph.ProjectName,
                            Status = ph.Phase
                                .OrderByDescending(p => p.PhaseId)
                                .FirstOrDefault()?.WorkStatus?.WorkStatusName ?? "N/A"
                        })
                    )
                    .ToList();
                var publicationDropdown = enquires
    .Where(x => x.Registered)
    .SelectMany(x => x.Projects
        .Where(p => p.Phase
            .OrderByDescending(ph => ph.PhaseId)
            .FirstOrDefault(ph => ph.Status == (int)Enum.WorkStatus.Publication) != null)
        .Select(p =>
        {
            var latestPhase = p.Phase
                .OrderByDescending(ph => ph.PhaseId)
                .First(ph => ph.Status == (int)Enum.WorkStatus.Publication);

            return new PublicationDropdown
            {
                ProjectId = p.ProjectId,
                ClientName = p.Clients.ClientName,
                ProjectRef = p.ProjectRef,
                ProjectName = p.ProjectName,
                ToApplyCount = p.Publication.Count(pub => pub.Status == 8)
            };
        })
    )
    .ToList();
                return (true, Array.Empty<string>(), enquiryDropdown, projectDropdown, publicationDropdown);
            }
            catch (Exception ex)
            {
                return (false, new[] { ex.Message }, null, null, null);
            }
        }

        public async Task<(bool Succeeded, string[] Errors)> UpdateEmailAsync(int? EnquiryId, int? ProjectId, bool IsRead, int EmailId, int? PublicationProjectId)
        {
            try
            {
                var updateEmail = await _context.Emails.FindAsync(EmailId);
                    updateEmail.EnquiryId = EnquiryId;
                
                if (PublicationProjectId != null)
                {
                    updateEmail.ProjectId = PublicationProjectId;
                    updateEmail.IsPublication = true;
                }
                else
                {
                    updateEmail.ProjectId = ProjectId;
                    updateEmail.IsPublication = false;
                }
                updateEmail.IsRead= IsRead;
                await _context.SaveChangesAsync();
                return (true,null);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message });
            }
        }
        public async Task<(bool Succeeded, string[] Errors, EmailDto Emails)> GetEmailFormAsync(int EmailId)
        {
            try
            {
                var emailDetails = _context.Emails
                    .Where(x => x.EmailId == EmailId)
                    .Select(x => new EmailDto
                    {
                        EmailId = x.EmailId,
                        FromAddress = x.FromAddress,
                        ToAddress = x.ToAddress,
                        ClientName = x.ClientName,
                        Subject = x.Subject,
                        Body = $"{x.Subject}\n\n{x.Body}",
                        EnquiryId = x.EnquiryId,
                        ProjectId = x.ProjectId,
                        IsPublication = x.IsPublication,
                        IsProgrammerVisibility = x.IsProgrammerVisibility,
                        IsTechVisibility = x.IsTechVisibility,
                        Visibility = x.Visibility,
                        EmailAttachmentDto = x.EmailAttachmentsFiles.Select(a => new EmailAttachmentDto
                        {
                            AttachmentFileId = a.EmailAttachmentId,
                            AttachmentFilePath = a.AttachmentFilePath,
                            AttachmentFileName = a.AttachmentFileName,
                            IsSelected = a.IsSelected
                        }).ToList()
                    }).FirstOrDefault();

                return (true, Array.Empty<string>(), emailDetails);
            }
            catch (Exception ex)
            {
                return (false, new[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Errors)> UpdateAttachmentAsync(int AttachmentFileId, bool IsSelected)
        {
            try
            {
                var SelectedAttachment = await _context.EmailAttachmentsFiles.FindAsync(AttachmentFileId);
                SelectedAttachment.IsSelected = IsSelected;
                await _context.SaveChangesAsync();
                return (true, Array.Empty<string>());
            }
            catch (Exception ex)
            {
                return (false, new[] { ex.Message });
            }
        }
        public async Task<(bool Succeeded, string[] Errors)> UpdateEmailMessageAsync(EmailDto email)
        {
            try
            {
                if (_httpContextAccessor.HttpContext.Session.GetString("Dept") == Enum.Department.Tech.ToString() && _httpContextAccessor.HttpContext.Session.GetString("Role") != Enum.Roles.Manager.ToString())
                {
                    email.IsTechVisibility = true;
                }
                if (_httpContextAccessor.HttpContext.Session.GetString("Dept") == Enum.Department.Programming.ToString() && _httpContextAccessor.HttpContext.Session.GetString("Role") != Enum.Roles.Manager.ToString())
                {
                    email.IsProgrammerVisibility = true;
                }
                var SelectedEmail = await _context.Emails.FindAsync(email.EmailId);
                SelectedEmail.UpdatedMessage = email.Body;
                SelectedEmail.Visibility = email.Visibility;
                SelectedEmail.IsTechVisibility = email.IsTechVisibility;
                SelectedEmail.IsProgrammerVisibility = email.IsProgrammerVisibility;
                await _context.SaveChangesAsync();
                var clientName = "";
                var projectRef = "";
                Projects project = null;
                if (email.ProjectId != null)
                {
                    project = await _context.Projects
                               .Where(x => x.ProjectId == email.ProjectId)
                               .Include(x => x.Clients)
                                   .ThenInclude(x => x.TechTLEmployee)
                               .Include(x => x.Clients)
                                   .ThenInclude(x => x.ProgrammerTLEmployee)
                               .Include(x => x.Phase)
                                   .ThenInclude(x => x.Employees)
                               .Include(x => x.Phase)
                                   .ThenInclude(x => x.Employees1)
                               .Include(x => x.Phase)
                                   .ThenInclude(x => x.Employees2)
                               .Include(x => x.Phase)
                                   .ThenInclude(x => x.Employees3)
                               .Include(x => x.Phase)
                                   .ThenInclude(x => x.Employees4)
                               .Include(x => x.Phase)
                                   .ThenInclude(x => x.Employees5)
                               .FirstOrDefaultAsync();

                    clientName = project.Clients?.ClientName;
                    projectRef = project.ProjectRef;
                }
                else if(email.EnquiryId != null)
                {
                    var Enquiry = await _context.Clients.Include(x => x.TechEmployee).Include(x => x.BDAEmployee).Where(x => x.EnquiryId == email.EnquiryId)
                        .Select(x => new {
                            ClientName = x.ClientName,
                            EnquiryRef = x.EnquiryRef,                            
                        }).FirstOrDefaultAsync();
                    clientName = Enquiry.ClientName;
                    projectRef = Enquiry.EnquiryRef;
                }
                if(email.ProjectId != null && email.IsPublication)
                {
                    var publicationMemberId = _context.Employees.Include(x => x.Department).Include(x => x.Roles)
                        .Where(x => x.Department.DeptName == Enquiry.Blazor.Enum.Department.Publication.ToString() &&
                        x.Roles.RoleName == EnumerationDescription.GetDescription(Enquiry.Blazor.Enum.Roles.TeamLead)).Select(x => x.MemberId).ToList();
                    var slackMessage = $"We have received an email from {clientName} {projectRef}";
                    await SendSlackMessage(publicationMemberId, slackMessage);
                }
                if (email.Visibility)
                {                    
                    var members = _context.Employees
                                          .Where(x => x.Designation.Contains("Front Office Executive"))
                                          .Select(x => x.MemberId)
                                          .ToList();
                    var slackMessage = $"We have received an email from {clientName} {projectRef}";
                    await SendSlackMessage(members, slackMessage);
                }
                
                if ((email.IsTechVisibility || email.IsProgrammerVisibility) && email.ProjectId != null)
                {
                    
                    List<string> members = new List<string>();

                    if (email.IsTechVisibility)
                    {
                        members.Add(project?.Clients?.TechTLEmployee?.MemberId);
                        members.Add(project?.Phase?.Select(p => p.Employees?.MemberId).LastOrDefault());
                        members.Add(project?.Phase?.Select(p => p.Employees1?.MemberId).LastOrDefault());
                        members.Add(project?.Phase?.Select(p => p.Employees2?.MemberId).LastOrDefault());
                        members.Add(project?.Phase?.Select(p => p.Employees3?.MemberId).LastOrDefault());
                                            
                    }
                    else if (email.IsProgrammerVisibility)
                    {
                        members.Add(project?.Clients?.ProgrammerTLEmployee?.MemberId);
                        members.Add(project?.Phase?.Select(p => p.Employees4?.MemberId).LastOrDefault());
                        members.Add(project?.Phase?.Select(p => p.Employees5?.MemberId).LastOrDefault()); 
                    }

                    string slackMessage = $"We have received an email from {clientName} {projectRef}";
                    await SendSlackMessage(members.Where(x => x != null).ToList(), slackMessage);
                }
                return (true, Array.Empty<string>());
            }
            catch (Exception ex)
            {
                return (false, new[] { ex.Message });
            }
        }
        public async Task<(bool Succeeded, string[] Errors)> UpdateDeletedEmailAsync(int EmailId)
        {
            try
            {
                var Email = await _context.Emails.FindAsync(EmailId);
                if (Email != null)
                {
                    Email.IsTrashMail = true; 
                    _context.Update(Email);
                    await _context.SaveChangesAsync();
                }
                    return (true, Array.Empty<string>());
            }
            catch (Exception ex)
            {
                return (false, new[] { ex.Message });
            }
        }
        public async Task<(bool Succeeded, string[] Errors)> UpdateEmailCloseEmailFormAsync(int EmailId)
        {
            try
            {
                var Email = await _context.Emails.FindAsync(EmailId);
                if (Email != null)
                {
                    Email.IsRead = false;
                    Email.IsPublication = false;
                    Email.EnquiryId = null;
                    Email.ProjectId = null;
                    Email.UpdatedMessage = null;
                    _context.Update(Email);
                    await _context.SaveChangesAsync();
                }
                return (true, Array.Empty<string>());
            }
            catch (Exception ex)
            {
                return (false, new[] { ex.Message });
            }
        }
        public async Task<(bool Succeeded, string[] Errors)> UpdatePermanentDeletedEmailAsync(int EmailId)
        {
            try
            {
                var email = await _context.Emails.FindAsync(EmailId);
                if (email == null)
                {
                    return (false, new[] { "Email not found." });
                }

                var emailAttachments = _context.EmailAttachmentsFiles
                    .Where(x => x.EmailId == EmailId)
                    .ToList();

                if (emailAttachments != null && emailAttachments.Any())
                {
                    foreach (var attachment in emailAttachments)
                    {
                        if (File.Exists(attachment.AttachmentFilePath))
                        {
                            File.Delete(attachment.AttachmentFilePath);
                        }
                        _context.EmailAttachmentsFiles.Remove(attachment);
                    }
                }
                _context.Emails.Remove(email);
                await _context.SaveChangesAsync();

                return (true, Array.Empty<string>());
            }
            catch (Exception ex)
            {
                return (false, new[] { ex.Message });
            }
        }

    }
}
