﻿using AutoMapper;
using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Models;
using Enquiry.Blazor.Services.Interface;
using Microsoft.EntityFrameworkCore;

namespace Enquiry.Blazor.Services
{
    public class ReportService : IReport
    {
        readonly ApplicationDbContext _context;
        readonly IMapper _mapper;
        private readonly ISession _session;
        public ReportService(ApplicationDbContext context, IMapper mapper, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _mapper = mapper;
            _session = httpContextAccessor.HttpContext.Session;
        }

        public async Task<(bool Succeeded, string[] Error, IList<EnquiryWisePaymentDto> Data)> GetEnquiryPaymentListAsync(int EmpId, DateTime startDate, DateTime endDate, bool regType)
        {
            IQueryable<EnquiryWisePaymentDto> payments = new List<EnquiryWisePaymentDto>().AsQueryable();
            if (regType)
            {
                 payments = from payment in _context.Payments
                               join project in _context.Projects on payment.ProjectId equals project.ProjectId
                               join client in _context.Clients on project.EnquiryId equals client.EnquiryId
                               join employee in _context.Employees on client.BDA equals employee.EmpId
                               join employee1 in _context.Employees on payment.CreatedBy equals employee1.EmpId
                            where payment.PaymentDate >= startDate && payment.PaymentDate <= endDate 
                                && payment.CreatedBy == EmpId && (client.IsAgent == true || client.PreviousEnquiryId > 0)
                            select new EnquiryWisePaymentDto()
                               {
                                   EmpId = employee.EmpId,
                                   EmpName = employee.EmployeeName + employee1.EmployeeName,
                                   EnquiryId = client.EnquiryId,
                                   EnquiryName = client.ClientName,
                                   Payment = payment.PartPayment.Value,
                                   Date = payment.CreatedDate
                               };
            }
            else
            {
                payments = from payment in _context.Payments
                           join project in _context.Projects on payment.ProjectId equals project.ProjectId
                           join client in _context.Clients on project.EnquiryId equals client.EnquiryId
                           join employee in _context.Employees on client.BDA equals employee.EmpId
                           join employee1 in _context.Employees on payment.CreatedBy equals employee1.EmpId
                           where payment.PaymentDate >= startDate && payment.PaymentDate <= endDate && client.IsAgent == false && client.PreviousEnquiryId == 0 && payment.CreatedBy == EmpId
                           select new EnquiryWisePaymentDto()
                           {
                               EmpId = employee.EmpId,
                               EmpName = employee.EmployeeName + employee1.EmployeeName,
                               EnquiryId = client.EnquiryId,
                               EnquiryName = client.ClientName,
                               Payment = payment.PartPayment.Value,
                               Date = payment.CreatedDate
                           };
            }
            
            return (true, new string[] { },  payments.ToList());
        }

        public async Task<(bool Succeeded, string[] Error, ScoreDto Data)> GetBDAScoreListAsync(DateTime startDate, DateTime endDate)
        {
            var score = new ScoreDto();
            try
            {
                //var payments = from employee in _context.Employees
                //               join payment in _context.Payments on employee.EmpId equals payment.CreatedBy
                //               where payment.PaymentDate >= startDate && payment.PaymentDate <= endDate
                //               group payment by new { employee.EmpId, employee.EmployeeName, employee.RoleId, employee.DeptId } into g
                //               select new PaymentDto()
                //               {
                //                   EmpId = g.Key.EmpId,
                //                   EmpName = g.Key.EmployeeName,
                //                   Role = g.Key.RoleId,
                //                   Department = g.Key.DeptId,
                //                   TotalPaid = g.Sum(s => s.PartPayment.Value)
                //               };
                var payments = from employee in _context.Employees
                               join payment in _context.Payments on employee.EmpId equals payment.CreatedBy
                               join project in _context.Projects on payment.ProjectId equals project.ProjectId
                               join client in _context.Clients on project.EnquiryId equals client.EnquiryId
                               where payment.PaymentDate >= startDate && payment.PaymentDate <= endDate
                               group payment by new { employee.EmpId, employee.EmployeeName, employee.RoleId, employee.DeptId, client.PreviousEnquiryId, client.IsAgent } into g
                               select new PaymentDto()
                               {
                                   EmpId = g.Key.EmpId,
                                   EmpName = g.Key.EmployeeName,
                                   Role = g.Key.RoleId,
                                   Department = g.Key.DeptId,
                                   TotalPaid = g.Sum(s => s.PartPayment.Value),
                                   OldReg = g.Key.PreviousEnquiryId > 0 || g.Key.IsAgent ? g.Sum(s => s.PartPayment.Value) : 0,
                                   NewReg = g.Key.PreviousEnquiryId == 0 && !g.Key.IsAgent ? g.Sum(s => s.PartPayment.Value) : 0
                               } into result
                               group result by new
                               {
                                   result.EmpId,
                                   result.EmpName,
                                   result.Role,
                                   result.Department
                               } into groupedResult
                               select new PaymentDto()
                               {
                                   EmpId = groupedResult.Key.EmpId,
                                   EmpName = groupedResult.Key.EmpName,
                                   Role = groupedResult.Key.Role,
                                   Department = groupedResult.Key.Department,
                                   TotalPaid = groupedResult.Sum(r => r.TotalPaid),
                                   OldReg = groupedResult.Sum(r => r.OldReg),
                                   NewReg = groupedResult.Sum(r => r.NewReg)
                               };
                if (!((_session.GetString("Dept") == Enum.Department.BDA.ToString() || _session.GetString("Dept") == Enum.Department.Tech.ToString()) && _session.GetString("Role") == Enum.Roles.Manager.ToString()))
                {
                    payments = payments.Where(x => x.EmpId == (int)_session.GetInt32("CurrentUserId"));
                }

                score.PaymentDto = payments.ToList();

                var query = _context.Clients
                    .Join(_context.Employees.Where(emp => emp.DeptId == (int)Enum.Department.BDA),
                        cli => cli.CreatedBy,
                        emp => emp.EmpId,
                        (cli, emp) => new { cli.CreatedBy, emp.EmployeeName })
                        .GroupBy(result => result.CreatedBy)
                    .Select(group => new NewEnquiryDto
                    {
                        BDAId = group.Key,
                        BDA = group.First().EmployeeName,
                        OldEnquiry = _context.Clients.Count(y => y.CreatedDate >= startDate
                        && y.CreatedDate <= endDate && (y.PreviousEnquiryId > 0 || y.IsAgent == true) && y.CreatedBy == group.Key),
                        NewEnquiry = _context.Clients.Count(y => y.CreatedDate >= startDate && y.CreatedDate <= endDate
                        && (y.PreviousEnquiryId == 0 && y.IsAgent == false) && y.CreatedBy == group.Key)
                    });

                score.NewEnquiryDto = query.ToList();

                var rawData = from emp in _context.Employees
                              join cli in _context.Clients on emp.EmpId equals cli.BDA into clientGroup
                              from cli in clientGroup.DefaultIfEmpty()
                              join pro in _context.Projects on cli.EnquiryId equals pro.EnquiryId into projectGroup
                              from pro in projectGroup.DefaultIfEmpty()
                              where emp.DeptId == (int)Enum.Department.BDA &&
                                    pro.RegistrationDate >= startDate && pro.RegistrationDate <= endDate
                              select new
                              {
                                  emp.EmpId,
                                  emp.EmployeeName,
                                  cli.Registered,
                                  cli.PreviousEnquiryId,
                                  cli.IsAgent,
                                  pro.ProjectName,
                                  pro.TotalPayment,
                                  pro.ProjectId
                              };

                var dataList = await rawData.ToListAsync();
                var engReg = from data in dataList
                             group data by new { data.EmpId, data.EmployeeName } into g
                             select new NewRegistrationDto
                             {
                                 BDAId = g.Key.EmpId,
                                 BDA = g.Key.EmployeeName,
                                 OldRegistrationCount = g.Count(x => x.Registered && (x.PreviousEnquiryId > 0 || x.IsAgent)),
                                 NewRegistrationCount = g.Count(x => x.Registered && (x.PreviousEnquiryId == 0 && !x.IsAgent)),
                                 Incentive = g.Where(x => x.Registered && x.PreviousEnquiryId == 0 && !x.IsAgent)
                                             .Select(x => new
                                             {
                                                 ProjectName = x.ProjectName.Contains("_") ? x.ProjectName.Split(new[] { '_' })[0] : x.ProjectName,
                                                 WorkType = x.ProjectName.Contains("_")
                                                            ? x.ProjectName.Split(new[] { '_' })[1].Split(new[] { '(' })[0]
                                                            : string.Empty,
                                                 Amount = x.TotalPayment,
                                                 x.ProjectId
                                             })
                                             .GroupBy(x => new { x.ProjectName, x.WorkType })
                                             .Select(grp => new
                                             {
                                                 ProjectName = grp.Key.ProjectName,
                                                 WorkType = grp.Key.WorkType,
                                                 Amount = grp.Sum(x => x.Amount)
                                             })
                                             .Join(
                                                 _context.ProjectStatus.ToList(), // Fetch ProjectStatus into memory
                                                 proj => new { proj.ProjectName, proj.WorkType },
                                                 status => new { status.ProjectName, status.WorkType },
                                                 (proj, status) => new
                                                 {
                                                     Incentive = status.Incentive,
                                                     NormalPayment = status.NormalPayment,
                                                     ReducedIncentive = status.ReducedIncentive,
                                                     Amount = proj.Amount
                                                 })
                                             .Sum(x => x.Amount == x.NormalPayment
                                                 ? x.Incentive
                                                 : (x.Amount < x.NormalPayment ? x.ReducedIncentive : 0))
                             };


                score.NewRegistrationDto = engReg.ToList();
                var discoveryCounts = await _context.Clients
                        .Select(c => new
                        {
                            updatedDate = c.UpdatedDate,
                            EmployeeName = _context.Employees.FirstOrDefault(x => x.EmpId == c.BDA).EmployeeName,
                            GoogleCount = c.Discovery.Contains("Google") ? 1 : 0,
                            FacebookCount = c.Discovery.Contains("FaceBook") ? 1 : 0,
                            LinkedInCount = c.Discovery.Contains("LinkedIn") ? 1 : 0,
                            CallCount = c.Discovery.Contains("TeamContacted") ? 1 : 0,
                            WhatsAppCount = c.Discovery.Contains("WhatsApp") ? 1 : 0,
                            EmailCount = c.Discovery.Contains("Email") ? 1 : 0,
                            OthersCount = c.Discovery.Contains("Others") ? 1 : 0,
                            ReferredCount = c.Discovery.Contains("SomeoneReferred") ? 1 : 0,
                            JustDialCount = c.Discovery.Contains("Justdial") ? 1 : 0
                        }).Where(x => x.updatedDate >= startDate && x.updatedDate <= endDate)
                        .GroupBy(x => x.EmployeeName) // Group all results into a single group (to calculate aggregates)
                        .Select(g => new Discovery
                        {
                            EmployeeName = g.Key,
                            Google = g.Sum(x => x.GoogleCount),
                            Facebook = g.Sum(x => x.FacebookCount),
                            LinkedIn = g.Sum(x => x.LinkedInCount),
                            Call = g.Sum(x => x.CallCount),
                            WhatsApp = g.Sum(x => x.WhatsAppCount),
                            Email = g.Sum(x => x.EmailCount),
                            Others = g.Sum(x => x.OthersCount),
                            Referred = g.Sum(x => x.ReferredCount),
                            JustDial = g.Sum(x => x.JustDialCount),

                        })
                        .ToListAsync();
                score.Discovery = discoveryCounts.ToList();
                var BDApayments = from payment in _context.Payments
                                  join project in _context.Projects on payment.ProjectId equals project.ProjectId
                                  join client in _context.Clients on project.EnquiryId equals client.EnquiryId
                                  join employee in _context.Employees on client.BDA equals employee.EmpId
                                  join employee1 in _context.Employees on payment.CreatedBy equals employee1.EmpId
                                  where payment.PaymentDate >= startDate && payment.PaymentDate <= endDate && employee1.Designation != "Front Office Executive" && (employee.SuperiorId == payment.CreatedBy || client.BDA == payment.CreatedBy)
                                  group payment by new { employee.EmployeeName, employee.RoleId, employee.DeptId, client.BDA, client.PreviousEnquiryId, client.IsAgent } into g
                                  select new BDAPaymentDto
                                  {
                                      EmpId = g.Key.BDA,
                                      EmpName = g.Key.EmployeeName,
                                      Role = g.Key.RoleId,
                                      Department = g.Key.DeptId,
                                      TotalPaid = g.Sum(s => s.PartPayment.Value) ,
                                      OldReg =  (g.Key.PreviousEnquiryId > 0 || g.Key.IsAgent) ? g.Sum(s => s.PartPayment.Value) : 0,
                                      NewReg = (g.Key.PreviousEnquiryId == 0 && !g.Key.IsAgent) ? g.Sum(s => s.PartPayment.Value) : 0
                                  } into result
                                  group result by new
                                  {
                                      result.EmpId,
                                      result.EmpName,
                                      result.Role,
                                      result.Department
                                  } into groupedResult
                                  select new BDAPaymentDto()
                                  {
                                      EmpId = groupedResult.Key.EmpId,
                                      EmpName = groupedResult.Key.EmpName,
                                      Role = groupedResult.Key.Role,
                                      Department = groupedResult.Key.Department,
                                      TotalPaid = groupedResult.Sum(r => r.TotalPaid),
                                      OldReg = groupedResult.Sum(r => r.OldReg),
                                      NewReg = groupedResult.Sum(r => r.NewReg)
                                  };

                score.BDAPaymentDto = BDApayments.ToList();
                return (true, new string[] { }, score);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }

        }
        public async Task<(bool Succeeded, string[] Error, ScoreTechDto Data)> GetTechScoreListAsync(DateTime startDate, DateTime endDate)
        {
            var score = new ScoreTechDto();
            try
            {
                var engReg = from emp in _context.Employees
                             join cli in _context.Clients on emp.EmpId equals cli.TechExpert into clientGroup
                             from cli in clientGroup.DefaultIfEmpty()
                             join pro in _context.Projects on cli.EnquiryId equals pro.EnquiryId into projectGroup
                             from pro in projectGroup.DefaultIfEmpty()
                             where emp.DeptId == (int)Enum.Department.Tech &&
                                   pro.RegistrationDate >= startDate && pro.RegistrationDate <= endDate
                             group new { emp, cli } by new { emp.EmpId, emp.EmployeeName } into g
                             select new NewRegistrationTechDto()
                             {
                                 TechId = g.Key.EmpId,
                                 TechName = g.Key.EmployeeName,
                                 OldRegistrationCount = g.Count(x => x.cli.Registered == true && (x.cli.PreviousEnquiryId > 0 || x.cli.IsAgent == true)),
                                 NewRegistrationCount = g.Count(x => x.cli.Registered == true && (x.cli.PreviousEnquiryId == 0 && x.cli.IsAgent == false))
                             };

                score.NewRegistrationTechDto = engReg.ToList();

                var query = await _context.PhaseHistory
                                .Include(phis => phis.Phase)
                                .Include(phis => phis.Employees)
                                .Include(phis => phis.Phase.Projects)
                                .Include(phis => phis.Phase.Projects.Clients)
                                .Where(phis => phis != null && phis.Employees != null
                                            && phis.Employees.DeptId == 2 && phis.Employees.RoleId >= 2
                                            && phis.IsReassigned == false
                                            && (phis.EmpId == phis.Phase.TechExpert || phis.EmpId == phis.Phase.TechExpert1 ||
                                                phis.EmpId == phis.Phase.TechExpert2 || phis.EmpId == phis.Phase.TechExpert3)
                                            && phis.CreatedDate >= startDate && phis.CreatedDate <= endDate)
                                .GroupBy(phis => new { phis.PhaseId,phis.EmpId })
                                .Select(group => group.OrderByDescending(phis => phis.CreatedDate).FirstOrDefault())
                                .ToListAsync();

               var production = query.Select(z => new TechProductionDto
               {
                   TechName = z.Employees.EmployeeName,
                   ClientName = z.Phase.Projects.Clients.ClientName,
                   PhaseName = z.Phase.PhaseName,
                   Reason = z.Comments,
                   TechId = z.EmpId,
                   ProjectRef = z.Phase.Projects.ProjectRef,
                   ProjectId = z.Phase.Projects.ProjectId,
                   EnquiryId = z.Phase.Projects.Clients.EnquiryId,
                   //Score = (z.Employees.EmpId) switch
                   //{
                   //    _ when z.Phase.TechExpert == z.Employees.EmpId => z.Phase.TechScore ?? 0,
                   //    _ when z.Phase.TechExpert1 == z.Employees.EmpId => z.Phase.TechScore1 ?? 0,
                   //    _ when z.Phase.TechExpert2 == z.Employees.EmpId => z.Phase.TechScore2 ?? 0,
                   //    _ when z.Phase.TechExpert3 == z.Employees.EmpId => z.Phase.TechScore3 ?? 0,
                   //    _ => null
                   //},
                   //Point = _context.PhaseStatus.FirstOrDefault(x => x.PhaseName == z.Phase.PhaseName && z.Phase.Status == 3) != null ?
                   //                   _context.PhaseStatus.FirstOrDefault(x => x.PhaseName == z.Phase.PhaseName && z.Phase.Status == 3).EmployeeDeadline : 0,        
                   Points = _context.PhaseStatus.FirstOrDefault(x => x.PhaseName == z.Phase.PhaseName && z.Phase.Status == 3) != null ?
                                            (_context.PhaseStatus.FirstOrDefault(x => x.PhaseName == z.Phase.PhaseName && z.Phase.Status == 3).EmployeeDeadline
                                            / 100m) * (z.EmpId) switch
                                            {
                                                _ when z.Phase.TechExpert == z.EmpId => z.Phase.TechScore ?? 0,
                                                _ when z.Phase.TechExpert1 == z.EmpId => z.Phase.TechScore1 ?? 0,
                                                _ when z.Phase.TechExpert2 == z.EmpId => z.Phase.TechScore2 ?? 0,
                                                _ when z.Phase.TechExpert3 == z.EmpId => z.Phase.TechScore3 ?? 0,
                                                _ => null
                                            } : 0
               }).ToList();

                score.TechProductionDto = production.OrderBy(x => x.TechId).ToList();
                var TechPointsCountDtos = production
                .GroupBy(x => x.TechName)
                .Select(group => new TechPointCountDto
                {
                    TechId = group.FirstOrDefault()?.TechId,
                    TechName = group.Key,
                    TotalRows = group.Count(),
                    RowsWithPoints = group.Count(x => x.Points > 0),
                    RowsWithoutPoints = group.Count(x => x.Points == 0),
                    Points = group.Sum(x => x.Points)
                })
                .ToList();
                score.TechPointCountDto = TechPointsCountDtos.OrderBy(x => x.TechId).ToList();

                return (true, new string[] { }, score);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }

        }
        public async Task<(bool Succeeded, string[] Error, ScoreProgrammingDto Data)> GetProgrammingScoreListAsync(DateTime startDate, DateTime endDate)
        {
            var score = new ScoreProgrammingDto();
            try
            {
                var engReg = from emp in _context.Employees
                             join cli in _context.Clients on emp.EmpId equals cli.Programmer into clientGroup
                             from cli in clientGroup.DefaultIfEmpty()
                             join pro in _context.Projects on cli.EnquiryId equals pro.EnquiryId into projectGroup
                             from pro in projectGroup.DefaultIfEmpty()
                             where emp.DeptId == (int)Enum.Department.Programming &&
                                   pro.RegistrationDate >= startDate && pro.RegistrationDate <= endDate
                             group new { emp, cli } by new { emp.EmpId, emp.EmployeeName } into g
                             select new NewRegistrationProgrammingDto()
                             {
                                 ProgrammerId = g.Key.EmpId,
                                 ProgrammerName = g.Key.EmployeeName,
                                 OldRegistrationCount = g.Count(x => x.cli.Registered == true && (x.cli.PreviousEnquiryId > 0 || x.cli.IsAgent == true)),
                                 NewRegistrationCount = g.Count(x => x.cli.Registered == true && (x.cli.PreviousEnquiryId == 0 && x.cli.IsAgent == false))
                             };

                score.NewRegistrationProgrammingDto = engReg.ToList();

                var query = await _context.PhaseHistory
                                .Include(phis => phis.Phase)
                                .Include(phis => phis.Employees)
                                .Include(phis => phis.Phase.Projects)
                                .Include(phis => phis.Phase.Projects.Clients)
                                .Where(phis => phis != null && phis.Employees != null
                                            && phis.Employees.DeptId == 3 && phis.Employees.RoleId >= 2
                                            && (phis.EmpId == phis.Phase.Programmer || phis.EmpId == phis.Phase.Programmer1)
                                            && phis.IsReassigned == false
                                            && phis.CreatedDate >= startDate && phis.CreatedDate <= endDate)
                               .GroupBy(phis => new { phis.PhaseId, phis.EmpId})
                                .Select(group => group.OrderByDescending(phis => phis.CreatedDate).FirstOrDefault())
                .ToListAsync();

                var production = query.Select(z => new ProgrammingProductionDto
                {
                    programmerName = z.Employees.EmployeeName,
                    ClientName = z.Phase.Projects.Clients.ClientName,
                    PhaseName = z.Phase.PhaseName,
                    Reason = z.Comments,
                    ProgrammerId = z.EmpId,
                    ProjectRef = z.Phase.Projects.ProjectRef,
                    ProjectId = z.Phase.Projects.ProjectId,
                    EnquiryId = z.Phase.Projects.Clients.EnquiryId,
                    Points = _context.PhaseStatus.FirstOrDefault(x => x.PhaseName == z.Phase.PhaseName && z.Phase.Status == 3) != null ?
                                            (_context.PhaseStatus.FirstOrDefault(x => x.PhaseName == z.Phase.PhaseName && z.Phase.Status == 3).EmployeeDeadline
                                            / 100m) * (z.EmpId) switch
                                            {
                                                _ when z.Phase.Programmer == z.EmpId => z.Phase.ProgrammerScore ?? 0,
                                                _ when z.Phase.Programmer1 == z.EmpId => z.Phase.ProgrammerScore1 ?? 0,
                                                _ => null
                                            } : 0
                }).ToList();

                score.ProgrammingProductionDto = production.OrderBy(x => x.ProgrammerId).ToList();
                var programmingPointsCountDtos = production
                .GroupBy(x => x.programmerName)
                .Select(group => new ProgrammingPointCountDto
                {
                    ProgrammerId = group.FirstOrDefault()?.ProgrammerId,
                    ProgrammerName = group.Key,
                    TotalRows = group.Count(),
                    RowsWithPoints = group.Count(x => x.Points > 0),
                    RowsWithoutPoints = group.Count(x => x.Points == 0),
                    Points = group.Sum(x => x.Points)
                })
                .ToList();
                score.ProgrammingPointCountDto = programmingPointsCountDtos.OrderBy(x => x.ProgrammerId).ToList();
                return (true, new string[] { }, score);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }

        }
        public async Task<(bool Succeeded, string[] Error, List<EnquiryDetailDto> Data)> GetEnquiryDetailsAsync(DateTime startDate, DateTime endDate, int EmployId, string EnquiryType)
        {
            try
            {
                var Enquiry = new List<EnquiryDetailDto>();
                if (EnquiryType == "OldEnquiry")
                {
                    Enquiry = _context.Clients.Where(y => y.CreatedDate >= startDate
                               && y.CreatedDate <= endDate && (y.PreviousEnquiryId > 0 || y.IsAgent == true) && y.CreatedBy == EmployId)
                           .Select(group => new EnquiryDetailDto
                           {
                               EnquiryRef = group.EnquiryRef,
                               ClientName = group.ClientName,
                               TechExpertId = group.TechExpert,
                               EnquiryId = group.EnquiryId,
                               TechExpertName = _context.Employees.FirstOrDefault(e => e.EmpId == group.TechExpert) != null
                                ? _context.Employees.FirstOrDefault(e => e.EmpId == group.TechExpert).EmployeeName : null,
                               Domain = group.Domain
                           })
                           .ToList();
                }
                else
                {
                    Enquiry = _context.Clients.Where(y => y.CreatedDate >= startDate && y.CreatedDate <= endDate
                        && (y.PreviousEnquiryId == 0 && y.IsAgent == false) && y.CreatedBy == EmployId)
                               .Select(group => new EnquiryDetailDto
                               {
                                   EnquiryRef = group.EnquiryRef,
                                   ClientName = group.ClientName,
                                   TechExpertId = group.TechExpert,
                                   EnquiryId = group.EnquiryId,
                                   TechExpertName = _context.Employees.FirstOrDefault(e => e.EmpId == group.TechExpert) != null
                                    ? _context.Employees.FirstOrDefault(e => e.EmpId == group.TechExpert).EmployeeName : null,
                                   Domain = group.Domain
                               })
                               .ToList();
                }
                return (true, new string[] { }, Enquiry);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Error, List<BDARegistrationDto> Data)> GetBDARegistrationAsync(DateTime startDate, DateTime endDate, int EmployId, string RegistrationType)
        {
            try
            {
                var BDARegistration = new List<BDARegistrationDto>();
                if (RegistrationType == "OldRegistration")
                {
                    BDARegistration = await (from cli in _context.Clients
                                             join pro in _context.Projects on cli.EnquiryId equals pro.EnquiryId into projectGroup
                                             from pro in projectGroup.DefaultIfEmpty()
                                             where cli.BDA == EmployId &&
                                                   pro != null &&
                                                   pro.RegistrationDate >= startDate &&
                                                   pro.RegistrationDate <= endDate &&
                                                   cli.Registered &&
                                                   (cli.PreviousEnquiryId > 0 || cli.IsAgent)
                                             select new BDARegistrationDto
                                             {
                                                 ProjectRef = pro.ProjectRef,
                                                 ClientName = cli.ClientName,
                                                 ProjectName = pro.ProjectName,
                                                 EnquiryId = cli.EnquiryId,
                                                 TechExpert = _context.Employees.FirstOrDefault(e => e.EmpId == cli.TechExpert) != null
                                            ? _context.Employees.FirstOrDefault(e => e.EmpId == cli.TechExpert).EmployeeName : null,
                                             }).ToListAsync();
                }
                else
                {
                    BDARegistration = await (from cli in _context.Clients
                                             join pro in _context.Projects on cli.EnquiryId equals pro.EnquiryId into projectGroup
                                             from pro in projectGroup.DefaultIfEmpty()
                                             where cli.BDA == EmployId &&
                                                   pro != null &&
                                                   pro.RegistrationDate >= startDate &&
                                                   pro.RegistrationDate <= endDate &&
                                                   cli.Registered &&
                                                   (cli.PreviousEnquiryId == 0 && !cli.IsAgent)
                                             select new BDARegistrationDto
                                             {
                                                 ProjectRef = pro.ProjectRef,
                                                 ClientName = cli.ClientName,
                                                 ProjectName = pro.ProjectName,
                                                 EnquiryId = cli.EnquiryId,
                                                 TechExpert = _context.Employees.FirstOrDefault(e => e.EmpId == cli.TechExpert) != null
                                    ? _context.Employees.FirstOrDefault(e => e.EmpId == cli.TechExpert).EmployeeName : null,
                                             }).ToListAsync();
                }
                return (true, new string[] { }, BDARegistration);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Error, List<TechRegistrationDto> Data)> GetTechRegistrationAsync(DateTime startDate, DateTime endDate, int EmployId, string RegistrationType)
        {
            try
            {
                var TechReg = new List<TechRegistrationDto>();
                if (RegistrationType == "OldRegistration")
                {
                    TechReg = (from cli in _context.Clients
                               join pro in _context.Projects on cli.EnquiryId equals pro.EnquiryId into projectGroup
                               from pro in projectGroup.DefaultIfEmpty()
                               where cli.TechExpert == EmployId &&
                                     pro.RegistrationDate >= startDate && pro.RegistrationDate <= endDate &&
                                     cli.Registered && (cli.PreviousEnquiryId > 0 || cli.IsAgent)
                               select new TechRegistrationDto
                               {
                                   ProjectRef = pro.ProjectRef,
                                   ProjectName = pro.ProjectName,
                                   ClientName = cli.ClientName,
                                   EnquiryId = cli.EnquiryId,
                                   BDA = _context.Employees.FirstOrDefault(e => e.EmpId == cli.BDA) != null
                                    ? _context.Employees.FirstOrDefault(e => e.EmpId == cli.BDA).EmployeeName : null
                               }).ToList();
                }
                else
                {
                    TechReg = (from cli in _context.Clients
                               join pro in _context.Projects on cli.EnquiryId equals pro.EnquiryId into projectGroup
                               from pro in projectGroup.DefaultIfEmpty()
                               where cli.TechExpert == EmployId &&
                                     pro.RegistrationDate >= startDate && pro.RegistrationDate <= endDate &&
                                     cli.Registered && (cli.PreviousEnquiryId == 0 && !cli.IsAgent)
                               select new TechRegistrationDto
                               {
                                   ProjectRef = pro.ProjectRef,
                                   ProjectName = pro.ProjectName,
                                   ClientName = cli.ClientName,
                                   EnquiryId = cli.EnquiryId,
                                   BDA = _context.Employees.FirstOrDefault(e => e.EmpId == cli.BDA) != null
                                    ? _context.Employees.FirstOrDefault(e => e.EmpId == cli.BDA).EmployeeName : null
                               }).ToList();
                }
                return (true, new string[] { }, TechReg);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Error, List<ProgrammerRegistrationDto> Data)> GetProgrammerRegistrationAsync(DateTime startDate, DateTime endDate, int EmployId, string RegistrationType)
        {
            try
            {
                var TechReg = new List<ProgrammerRegistrationDto>();
                if (RegistrationType == "OldRegistration")
                {
                    TechReg = (from cli in _context.Clients
                               join pro in _context.Projects on cli.EnquiryId equals pro.EnquiryId into projectGroup
                               from pro in projectGroup.DefaultIfEmpty()
                               where cli.Programmer == EmployId &&
                                     pro.RegistrationDate >= startDate && pro.RegistrationDate <= endDate &&
                                     cli.Registered && (cli.PreviousEnquiryId > 0 || cli.IsAgent)
                               select new ProgrammerRegistrationDto
                               {
                                   ProjectRef = pro.ProjectRef,
                                   ProjectName = pro.ProjectName,
                                   ClientName = cli.ClientName,
                                   EnquiryId = cli.EnquiryId,
                                   TechExpert = _context.Employees.FirstOrDefault(e => e.EmpId == cli.TechExpert) != null
                                    ? _context.Employees.FirstOrDefault(e => e.EmpId == cli.TechExpert).EmployeeName : null
                               }).ToList();
                }
                else
                {
                    TechReg = (from cli in _context.Clients
                               join pro in _context.Projects on cli.EnquiryId equals pro.EnquiryId into projectGroup
                               from pro in projectGroup.DefaultIfEmpty()
                               where cli.Programmer == EmployId &&
                                     pro.RegistrationDate >= startDate && pro.RegistrationDate <= endDate &&
                                     cli.Registered && (cli.PreviousEnquiryId == 0 && !cli.IsAgent)
                               select new ProgrammerRegistrationDto
                               {
                                   ProjectRef = pro.ProjectRef,
                                   ProjectName = pro.ProjectName,
                                   ClientName = cli.ClientName,
                                   EnquiryId = cli.EnquiryId,
                                   TechExpert = _context.Employees.FirstOrDefault(e => e.EmpId == cli.TechExpert) != null
                                    ? _context.Employees.FirstOrDefault(e => e.EmpId == cli.TechExpert).EmployeeName : null
                               }).ToList();
                }
                return (true, new string[] { }, TechReg);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Error, ScorePublicationDto Data)> GetPublicationScoreListAsync(DateTime startDate, DateTime endDate)
        {
            try
            {
                var score = new ScorePublicationDto();

                var query = await _context.PublicationHistory
                    .Include(phis => phis.Publication)
                    .Include(phis => phis.Employees)
                    .Include(phis => phis.JournalStatus)
                    .Include(phis => phis.Publication.Projects)
                    .Include(phis => phis.Publication.Projects.Clients)
                    .Where(phis => phis != null &&
                                   phis.Employees != null &&
                                   //phis.Employees.DeptId == 4 &&
                                   //phis.Employees.RoleId >= 2 &&
                                   phis.CreatedDate >= startDate &&
                                   phis.CreatedDate <= endDate).ToListAsync();

                var Publication = query.Select(z => new PublicationDto
                {
                    EmpName = z.Employees.EmployeeName,
                    ClientName = z.Publication.Projects.Clients.ClientName,
                    ProjectId = z.Publication.Projects.ProjectId,
                    EnquiryId = z.Publication.Projects.Clients.EnquiryId,
                    JournalName = z.Publication.JournelName,
                    Reason = z.Publication.Reason,
                    EmpId = z.Employees.EmpId, // Assuming EmpId is from Employees entity
                    Status = z.JournalStatus.Id,
                    RejectionStatus = z.Publication.IsTechnicalRejected,
                    Domain = z.Publication.Projects.Clients.Domain,
                    ProjectRef = z.Publication.Projects.ProjectRef
                }).ToList();

                score.PublicationDto = Publication.OrderBy(x => x.EmpId).ToList();

                var PublicationPointsCountDtos = Publication
                    .GroupBy(x => x.EmpName)
                    .Select(group => new PublicationPointCountDto
                    {
                        EmpId = group.FirstOrDefault()?.EmpId,
                        EmpName = group.Key,
                        Submitted = group.Count(x => x.Status == 1),
                        Rejected = group.Count(x => x.Status == 2),
                        MajorOrMinor = group.Count(x => x.Status == 3 || x.Status == 4),
                        Accepted = group.Count(x => x.Status == 5),
                        ToApply = group.Count(x => x.Status == 8),
                        MailAccount = group.Count(x => x.Status == 7),
                        ClientWithdraw = group.Count(x => x.Status == 9),
                        Terminated = group.Count(x => x.Status == 10)
                    })
                    .ToList();

                score.PublicationPointCountDto = PublicationPointsCountDtos.OrderBy(x => x.EmpName).ToList();



                return (true, new string[] { }, score);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Error, List<PublicationDto> Data)> GetPublicationScoreDetailsAsync(DateTime startDate, DateTime endDate, int EmployId, int journalStatus, int journalStatus1)
        {
            try
            {
                var query = await _context.PublicationHistory
                    .Include(phis => phis.Publication)
                    .Include(phis => phis.Employees)
                    .Include(phis => phis.JournalStatus)
                    .Include(phis => phis.Publication.Projects)
                    .Include(phis => phis.Publication.Projects.Clients)
                    .Where(phis => phis != null &&
                                   phis.Employees != null &&
                                   //phis.Employees.DeptId == 4 &&
                                   //phis.Employees.RoleId >= 2 &&
                                   phis.CreatedDate >= startDate &&
                                   phis.CreatedDate <= endDate)
                    //.GroupBy(phis => phis.PublicationId)
                    //.Select(group => group.OrderByDescending(phis => phis.CreatedDate).FirstOrDefault())
                    .ToListAsync();
                List<PublicationHistory> data;
                if (journalStatus1 == 0)
                {
                    data = query.Where(x => x.Employees.EmpId == EmployId && x.JournalStatus.Id == journalStatus).ToList();
                }
                else
                {
                    data = query.Where(x => x.Employees.EmpId == EmployId && (x.JournalStatus.Id == journalStatus || x.JournalStatus.Id == journalStatus1)).ToList();
                }

                var Publication = data.Select(z => new PublicationDto
                {
                    EmpName = z.Employees.EmployeeName,
                    ClientName = z.Publication.Projects.Clients.ClientName,
                    JournalName = z.Publication.JournelName,
                    Reason = z.Publication.Reason,
                    EmpId = z.Employees.EmpId,
                    Status = z.JournalStatus.Id,
                    EnquiryId = z.Publication.Projects.Clients.EnquiryId,
                    ProjectId = z.Publication.Projects.ProjectId,
                    ProjectRef = z.Publication.Projects.ProjectRef
                }).ToList();

                return (true, new string[] { }, Publication);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }

        public async Task<(bool Succeeded, string[] Error, List<EmpPointsDto> Data)> GetTechPointsAsync(DateTime startDate, DateTime endDate, int EmployId, string Type)
        {
            try
            {
                var PointsList = new List<EmpPointsDto>();
                if (Type == "WithOutPoints")
                {
                    var query = await _context.PhaseHistory
                                .Include(phis => phis.Phase)
                                .Include(phis => phis.Employees)
                                .Include(phis => phis.Phase.Projects)
                                .Include(phis => phis.Phase.Projects.Clients)
                                .Where(phis => phis != null && phis.Employees != null
                                            && phis.Employees.DeptId == 2 && phis.Employees.RoleId >= 2
                                            && phis.IsReassigned == false
                                            && phis.CreatedDate >= startDate && phis.CreatedDate <= endDate)
                                .GroupBy(phis => new { phis.PhaseId, phis.EmpId})
                                .Select(group => group.OrderByDescending(phis => phis.CreatedDate).FirstOrDefault())
                .ToListAsync();
                    var data = query.Where(x => x.Employees.EmpId == EmployId).ToList();
                    PointsList = data.Select(z => new EmpPointsDto
                    {
                        Name = z.Employees.EmployeeName,
                        ClientName = z.Phase.Projects.Clients.ClientName,
                        EnquiryId = z.Phase.Projects.Clients.EnquiryId,
                        ProjectId = z.Phase.Projects.ProjectId,
                        PhaseName = z.Phase.PhaseName,
                        Reason = z.Comments,
                        Id = z.EmpId,
                        ProjectRef = z.Phase.Projects.ProjectRef,
                        Points = _context.PhaseStatus.FirstOrDefault(x => x.PhaseName == z.Phase.PhaseName && z.Phase.Status == 3) != null ?
                                            (_context.PhaseStatus.FirstOrDefault(x => x.PhaseName == z.Phase.PhaseName && z.Phase.Status == 3).EmployeeDeadline
                                            / 100m) * (z.EmpId) switch
                                            {
                                                _ when z.Phase.TechExpert == z.EmpId => z.Phase.TechScore ?? 0,
                                                _ when z.Phase.TechExpert1 == z.EmpId => z.Phase.TechScore1 ?? 0,
                                                _ when z.Phase.TechExpert2 == z.EmpId => z.Phase.TechScore2 ?? 0,
                                                _ when z.Phase.TechExpert3 == z.EmpId => z.Phase.TechScore3 ?? 0,
                                                _ => null
                                            } : 0
                    }).Where(x => x.Points <= 0).ToList();
                }
                else
                {
                    var query = await _context.PhaseHistory
                                .Include(phis => phis.Phase)
                                .Include(phis => phis.Employees)
                                .Include(phis => phis.Phase.Projects)
                                .Include(phis => phis.Phase.Projects.Clients)
                                .Where(phis => phis != null && phis.Employees != null
                                            && phis.Employees.DeptId == 2 && phis.Employees.RoleId >= 2
                                            && phis.IsReassigned == false
                                            && phis.CreatedDate >= startDate && phis.CreatedDate <= endDate)
                                .GroupBy(phis => new { phis.PhaseId, phis.EmpId })
                                .Select(group => group.OrderByDescending(phis => phis.CreatedDate).FirstOrDefault())
                .ToListAsync();
                    var data = query.Where(x => x.Employees.EmpId == EmployId).ToList();
                    PointsList = data.Select(z => new EmpPointsDto
                    {
                        Name = z.Employees.EmployeeName,
                        ClientName = z.Phase.Projects.Clients.ClientName,
                        EnquiryId = z.Phase.Projects.Clients.EnquiryId,
                        ProjectId = z.Phase.Projects.ProjectId,
                        PhaseName = z.Phase.PhaseName,
                        Reason = z.Comments,
                        Id = z.EmpId,
                        ProjectRef = z.Phase.Projects.ProjectRef,
                        Points = _context.PhaseStatus.FirstOrDefault(x => x.PhaseName == z.Phase.PhaseName && z.Phase.Status == 3) != null ?
                                            (_context.PhaseStatus.FirstOrDefault(x => x.PhaseName == z.Phase.PhaseName && z.Phase.Status == 3).EmployeeDeadline
                                            / 100m) * (z.EmpId) switch
                                            {
                                                _ when z.Phase.TechExpert == z.EmpId => z.Phase.TechScore ?? 0,
                                                _ when z.Phase.TechExpert1 == z.EmpId => z.Phase.TechScore1 ?? 0,
                                                _ when z.Phase.TechExpert2 == z.EmpId => z.Phase.TechScore2 ?? 0,
                                                _ when z.Phase.TechExpert3 == z.EmpId => z.Phase.TechScore3 ?? 0,
                                                _ => null
                                            } : 0
                    }).Where(x => x.Points > 0).ToList();
                }
                return (true, new string[] { }, PointsList);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }
        public async Task<(bool Succeeded, string[] Error, List<EmpPointsDto> Data)> GetProgrammerPointsAsync(DateTime startDate, DateTime endDate, int EmployId, string Type)
        {
            try
            {
                var PointsList = new List<EmpPointsDto>();
                if (Type == "WithOutPoints")
                {
                    var query = await _context.PhaseHistory
                                .Include(phis => phis.Phase)
                                .Include(phis => phis.Employees)
                                .Include(phis => phis.Phase.Projects)
                                .Include(phis => phis.Phase.Projects.Clients)
                                .Where(phis => phis != null && phis.Employees != null
                                            && phis.Employees.DeptId == 3 && phis.Employees.RoleId >= 2
                                            && phis.IsReassigned == false
                                            && phis.CreatedDate >= startDate && phis.CreatedDate <= endDate)
                                .GroupBy(phis => new { phis.PhaseId, phis.EmpId })
                                .Select(group => group.OrderByDescending(phis => phis.CreatedDate).FirstOrDefault())
                .ToListAsync();
                    var data = query.Where(x => x.Employees.EmpId == EmployId).ToList();
                    PointsList = data.Select(z => new EmpPointsDto
                    {
                        Name = z.Employees.EmployeeName,
                        ClientName = z.Phase.Projects.Clients.ClientName,
                        EnquiryId = z.Phase.Projects.Clients.EnquiryId,
                        ProjectId = z.Phase.Projects.ProjectId,
                        PhaseName = z.Phase.PhaseName,
                        Reason = z.Comments,
                        Id = z.EmpId,
                        ProjectRef = z.Phase.Projects.ProjectRef,
                        Points = _context.PhaseStatus.FirstOrDefault(x => x.PhaseName == z.Phase.PhaseName && z.Phase.Status == 3) != null ?
                                            (_context.PhaseStatus.FirstOrDefault(x => x.PhaseName == z.Phase.PhaseName && z.Phase.Status == 3).EmployeeDeadline
                                            / 100m) * (z.EmpId) switch
                                            {
                                                _ when z.Phase.Programmer == z.EmpId => z.Phase.ProgrammerScore ?? 0,
                                                _ when z.Phase.Programmer1 == z.EmpId => z.Phase.ProgrammerScore1 ?? 0,
                                                _ => null
                                            } : 0
                    }).Where(x => x.Points <= 0).ToList();
                }
                else
                {
                    var query = await _context.PhaseHistory
                                .Include(phis => phis.Phase)
                                .Include(phis => phis.Employees)
                                .Include(phis => phis.Phase.Projects)
                                .Include(phis => phis.Phase.Projects.Clients)
                                .Where(phis => phis != null && phis.Employees != null
                                            && phis.Employees.DeptId == 3 && phis.Employees.RoleId >= 2
                                            && phis.IsReassigned == false
                                            && phis.CreatedDate >= startDate && phis.CreatedDate <= endDate)
                                .GroupBy(phis => new { phis.PhaseId, phis.EmpId })
                                .Select(group => group.OrderByDescending(phis => phis.CreatedDate).FirstOrDefault())
                .ToListAsync();
                    var data = query.Where(x => x.Employees.EmpId == EmployId).ToList();
                    PointsList = data.Select(z => new EmpPointsDto
                    {
                        Name = z.Employees.EmployeeName,
                        ClientName = z.Phase.Projects.Clients.ClientName,
                        EnquiryId = z.Phase.Projects.Clients.EnquiryId,
                        ProjectId = z.Phase.Projects.ProjectId,
                        PhaseName = z.Phase.PhaseName,
                        Reason = z.Comments,
                        Id = z.EmpId,
                        ProjectRef = z.Phase.Projects.ProjectRef,
                        Points = _context.PhaseStatus.FirstOrDefault(x => x.PhaseName == z.Phase.PhaseName && z.Phase.Status == 3) != null ?
                                            (_context.PhaseStatus.FirstOrDefault(x => x.PhaseName == z.Phase.PhaseName && z.Phase.Status == 3).EmployeeDeadline
                                            / 100m) * (z.EmpId) switch
                                            {
                                                _ when z.Phase.Programmer == z.EmpId => z.Phase.ProgrammerScore ?? 0,
                                                _ when z.Phase.Programmer1 == z.EmpId => z.Phase.ProgrammerScore1 ?? 0,
                                                _ => null
                                            } : 0
                    }).Where(x => x.Points > 0).ToList();
                }
                return (true, new string[] { }, PointsList);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }
        }

    }
}
