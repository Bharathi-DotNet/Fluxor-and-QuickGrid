﻿using AutoMapper;
using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Models;
using Enquiry.Blazor.Services.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace Enquiry.Blazor.Services
{
    public class MCubeService: IMcube
    {
        private readonly ApplicationDbContext _context;
        readonly IMapper _mapper;
        public MCubeService(ApplicationDbContext context, IMapper mapper) 
        { 
            _context = context;
            _mapper = mapper;
        }

        public async Task<(bool Succeeded, string[] Error)> AddMCubeInboundCall(McubeInboundCallData dto)
        {
            try
            {
                var map = _mapper.Map<VoipCallHistory>(dto);
                await _context.AddAsync(map);
                int result = await _context.SaveChangesAsync();
                if (result > 0)
                    return (true, new string[] { "Inbound call added successfully" });
                else 
                    return (false, new string[] { "Failed to add inbound call" });
            }
            catch (Exception ex)
            {

                return (false, new string[] { ex.Message });
            }

        }
    }
}
