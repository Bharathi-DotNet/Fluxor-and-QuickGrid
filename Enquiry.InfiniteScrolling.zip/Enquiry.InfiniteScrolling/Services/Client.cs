﻿using AutoMapper;
using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Extensions;
using Enquiry.Blazor.Models;
using Enquiry.Blazor.Services.Interface;
using Hangfire;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System.Diagnostics;

namespace Enquiry.Blazor.Services;

public class Client : IClient
{
    readonly ApplicationDbContext _context;
    readonly IMapper _mapper;
    private readonly ISession _session;
    readonly ISlack _slack;
    readonly IEmployee _employee;
    private readonly IBackgroundJobClient _backgroundJobClient;
    private readonly SlackConfig _slackConfig;
    private readonly HttpContext _httpContext;
    public Client(ApplicationDbContext context, IMapper mapper, IHttpContextAccessor httpContextAccessor,
        ISlack slack, IEmployee employee, IBackgroundJobClient backgroundJobClient = null, IOptions<SlackConfig> slackConfig = null)
    {
        _context = context;
        _mapper = mapper;
        _session = httpContextAccessor.HttpContext.Session;
        _slack = slack;
        _employee = employee;
        _backgroundJobClient = backgroundJobClient;
        _slackConfig = slackConfig.Value;
        _httpContext = httpContextAccessor.HttpContext;
    }

    public async Task<(bool Succeeded, string[] Error, VirtualizeResponse<ClientListDto> Data)> GetVirtualizeClientsAsync(char chkValue, ClientListParameters clientParams)
    {
        try
        {
            var data = new List<ClientListDto>();
            var result = new List<Clients>();
            List<string> falseRegisteredContactNumbers = new List<string>();
            List<string> trueRegisteredContactNumbers = new List<string>();
            int totalSize = 0;

            // Method to extract contact number from a string
            static string GetContactNumber(string combinedColumn)
            {
                // Split the string by space and take the first part as the contact number
                string[] parts = combinedColumn.Split(' ');

                // Return the entire contact number or the whole string if no space is found
                return parts.Length > 0 ? parts[0] : combinedColumn;
            }



            if (_session.GetString("Role") != Enum.Roles.Executive.ToString())
            {

                //if ( _session.GetString("Dept") == Enum.Department.BDA.ToString())
                //{
                //      result = await _context.Clients.Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false)).
                //       Include(x => x.History).ThenInclude(x => x.Employees)
                //     .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).ToListAsync();
                //}
                var stopwatch = new Stopwatch();
                stopwatch.Start();  // Start the stopwatch
                result = await _context.Clients
     .Where(c => c.IsActive == true &&
                 (clientParams.SearchTerm == null ||
                 c.ClientName.ToLower().Contains(clientParams.SearchTerm.ToLower())))
     .Include(x => x.History).ThenInclude(x => x.Employees)
     .Include(x => x.BDAEmployee)
     .Include(x => x.TechEmployee)
     .OrderByDescending(x => x.EnquiryDate)
     .Skip(clientParams.StartIndex)
     .Take(clientParams.PageSize)
     .ToListAsync();


                stopwatch.Stop();  // Stop the stopwatch

                totalSize = await _context.Clients.CountAsync(x => x.IsActive.Equals(true));
                // Log the elapsed time
                Console.WriteLine($"Query executed in {stopwatch.ElapsedMilliseconds} milliseconds.");
                Console.WriteLine($"Total coune {result.Count} .");
                    //totalSize = result.Count;

                    falseRegisteredContactNumbers = result
                        .Where(x => !x.Registered)
                        .Select(x => GetContactNumber(x.Contact))
                        .ToList();

                    trueRegisteredContactNumbers = result
                        .Where(x => x.Registered)
                        .Select(x => GetContactNumber(x.Contact))
                        .ToList();

                    // Check if all contact numbers in trueRegisteredContactNumbers are present in the original list
                    bool AreAllRegisteredTrueContacts = trueRegisteredContactNumbers
                        .All(contactNumber => result.Any(x => GetContactNumber(x.Contact) == contactNumber));

               
                if (_session.GetString("Dept") == Enum.Department.Tech.ToString())
                {
                    if (_session.GetString("Role") == Enum.Roles.Manager.ToString())
                    {
                        result = await _context.Clients.Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false)).
                       Include(x => x.History).ThenInclude(x => x.Employees)
                       .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).ToListAsync();
                    }
                    else if (_session.GetString("Role") == EnumerationDescription.GetDescription(Enum.Roles.TeamLead))
                    {
                        result = await _context.Clients
                    .Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false)
                    && (x.BDA == _session.GetInt32("CurrentUserId") || x.TechExpert == _session.GetInt32("CurrentUserId"))).Include(x => x.History)
                    .ThenInclude(x => x.Employees)
                    .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).ToListAsync();
                        var employees = _employee.GetEmployeeSuperiorWiseTree().Result.Data;
                        foreach (var employee in employees)
                        {
                            var client = await _context.Clients
                    .Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false)
                    && (x.BDA == employee.EmpId || x.TechExpert == employee.EmpId)).Include(x => x.History)
                    .ThenInclude(x => x.Employees)
                    .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).ToListAsync();
                            result.AddRange(client);
                        }
                    }
                    else
                    {
                        result = await _context.Clients
                    .Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false)
                    && (x.BDA == _session.GetInt32("CurrentUserId") || x.TechExpert == _session.GetInt32("CurrentUserId"))).Include(x => x.History)
                    .ThenInclude(x => x.Employees)
                    .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).ToListAsync();
                    }

                }

            }
            else if (_session.GetString("Dept") == Enum.Department.Programming.ToString())
            {
                if (_session.GetString("Role") == EnumerationDescription.GetDescription(Enum.Roles.TeamLead))
                {
                    var employees = _employee.GetEmployeeSuperiorWiseTree().Result.Data;
                    result = await _context.Clients
                .Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false) && x.IsTechAppoinment == true
                && x.Programmer == _session.GetInt32("CurrentUserId")).Include(x => x.History)
                .ThenInclude(x => x.Employees)
                .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).Include(x => x.ProgrammerEmployee).ToListAsync();
                    foreach (var item in employees)
                    {
                        var client = await _context.Clients
                            .Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false) && x.IsTechAppoinment == true
                            && x.Programmer == item.EmpId).Include(x => x.History)
                            .ThenInclude(x => x.Employees)
                            .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).Include(x => x.ProgrammerEmployee).ToListAsync();
                        result.AddRange(client);
                    }
                }
                else
                {
                    result = await _context.Clients
            .Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false) && x.IsTechAppoinment == true
            && x.Programmer == _session.GetInt32("CurrentUserId")).Include(x => x.History)
            .ThenInclude(x => x.Employees)
            .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).Include(x => x.ProgrammerEmployee).ToListAsync();
                }
            }

            else
            {
                result = await _context.Clients
                    .Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false)
                    && (x.BDA == _session.GetInt32("CurrentUserId") || x.TechExpert == _session.GetInt32("CurrentUserId"))).Include(x => x.History)
                    .ThenInclude(x => x.Employees)
                    .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).ToListAsync();
            }

            if (result == null)
            {

                return (true, new string[] { }, new VirtualizeResponse<ClientListDto> { Items = data, TotalSize = totalSize });
            }

            DateTime date = DateTime.Now.AddDays(1);

            //var splitContact = data.Select(x => x.Contact.Split(" "))[0].ToList();

            data = result.Select(x => new ClientListDto()
            {

                EnquiryId = x.EnquiryId,
                ClientName = x.ClientName,
                Contact = x.Contact,
                Domain = x.Domain,
                TechRemarks = x.History != null
                && x.History.Any(y => (y.Employees.DeptId == (int)Enum.Department.Tech || y.Employees.DeptId == (int)Enum.Department.Programming) && y.IsComment == true)
                ? x.History.LastOrDefault(z => (z.Employees.DeptId == (int)Enum.Department.Tech || z.Employees.DeptId == (int)Enum.Department.Programming) && z.IsComment == true).UpdatedDate.Date.ToString("dd/MM/yyyy") + Environment.NewLine +
                    x.History.LastOrDefault(z => (z.Employees.DeptId == (int)Enum.Department.Tech || z.Employees.DeptId == (int)Enum.Department.Programming) && z.IsComment == true).Comments

                : " ",
                BDARemarks = x.History != null
                && x.History.Any(y => y.Employees.DeptId == (int)Enum.Department.BDA && y.IsComment == true)
                ? x.History.LastOrDefault(z => z.Employees.DeptId == (int)Enum.Department.BDA && z.IsComment == true).UpdatedDate.Date.ToString("dd/MM/yyyy") + Environment.NewLine +
                    x.History.LastOrDefault(z => z.Employees.DeptId == (int)Enum.Department.BDA && z.IsComment == true).Comments
                : " ",
                PaymentRemarks = x.PaymentRemarks,
                EnquiryDate = x.EnquiryDate,
                AppoinmentDate = x.AppoinmentDate,
                EnquiryRef = x.EnquiryRef,
                IsTechAppoinment = x.IsTechAppoinment,
                TechExperts = x.TechEmployee != null ? x.TechEmployee.EmployeeName : "",
                BDA = x.BDAEmployee != null ? x.BDAEmployee.EmployeeName : "",
                Programmer = x.ProgrammerEmployee != null ? x.ProgrammerEmployee.EmployeeName : "",
                Registered = x.Registered,
                IsEmailed = x.IsEmailed,
                IsRegisteredTrueContact = trueRegisteredContactNumbers.Contains(GetContactNumber(x.Contact)) || falseRegisteredContactNumbers
                                        .Count(contactNumber => contactNumber == GetContactNumber(x.Contact)) > 1,
                IsBackToEnquiry = result.Any(y => y.EnquiryRef.Count() > 1)
            }).OrderByDescending(x => x.EnquiryDate).ToList();

            DateTime dtIST = DatetimeExtension.IndiaStandardTimeNow();
            if (chkValue.Equals('F'))
            {   //Future
                DateTime dt = (new DateTime(dtIST.Year, dtIST.Month, dtIST.Day, 10, 30, 0)).AddDays(1);
                data = data.Where(x => x.AppoinmentDate >= dt && x.IsTechAppoinment == false).OrderBy(x => x.AppoinmentDate).ToList();
            }
            else if (chkValue.Equals('P'))
            {   //Past
                DateTime dtTo = (new DateTime(dtIST.Year, dtIST.Month, dtIST.Day, 17, 30, 0)).AddDays(-1);
                dtTo = dtTo.AddDays(-7);
                data = data.Where(x => x.AppoinmentDate < dtTo && x.IsTechAppoinment == false).OrderBy(x => x.AppoinmentDate).ToList();
            }
            else if (chkValue.Equals('L'))
            {   //Last week
                DateTime dtTo = (new DateTime(dtIST.Year, dtIST.Month, dtIST.Day, 17, 30, 0)).AddDays(-1);
                DateTime dtFrom = dtTo.AddDays(-7);
                data = data.Where(x => (x.AppoinmentDate >= dtFrom && x.AppoinmentDate <= dtTo) && x.IsTechAppoinment == false).OrderBy(x => x.AppoinmentDate).ToList();
            }
            else if (chkValue.Equals('T'))
            {   //Today
                DateTime dtFrom = (new DateTime(dtIST.Year, dtIST.Month, dtIST.Day, 17, 30, 0)).AddDays(-1);
                DateTime dtTo = (new DateTime(dtIST.Year, dtIST.Month, dtIST.Day, 10, 30, 0)).AddDays(1);
                data = data.Where(x => (x.AppoinmentDate >= dtFrom && x.AppoinmentDate <= dtTo) && x.IsTechAppoinment == false).OrderBy(x => x.AppoinmentDate).ToList();
            }
            else if (chkValue.Equals('E'))
            {
                data = data.Where(x => x.IsTechAppoinment == true || x.IsEmailed == true).OrderBy(x => x.AppoinmentDate).ToList();
            }

            //Show Tech enabled under ALL
            if (!chkValue.Equals('A') && !chkValue.Equals('E'))
            {
                data = data.Where(x => x.IsTechAppoinment == false).OrderBy(x => x.AppoinmentDate).ToList();
            }

            return (true, new string[] { }, new VirtualizeResponse<ClientListDto> { Items = data, TotalSize = totalSize });
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }
    public async Task<(bool Succeeded, string[] Error, IList<ClientListDto> Data)> GetClientsAsync(char chkValue)
    {
        try
        {
            var data = new List<ClientListDto>();
            var result = new List<Clients>();
            List<string> falseRegisteredContactNumbers = new List<string>();
            List<string> trueRegisteredContactNumbers = new List<string>();

            // Method to extract contact number from a string
            static string GetContactNumber(string combinedColumn)
            {
                // Split the string by space and take the first part as the contact number
                string[] parts = combinedColumn.Split(' ');

                // Return the entire contact number or the whole string if no space is found
                return parts.Length > 0 ? parts[0] : combinedColumn;
            }



            if (_session.GetString("Role") != Enum.Roles.Executive.ToString())
            {

                //if ( _session.GetString("Dept") == Enum.Department.BDA.ToString())
                //{
                //      result = await _context.Clients.Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false)).
                //       Include(x => x.History).ThenInclude(x => x.Employees)
                //     .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).ToListAsync();
                //}
                if (_session.GetString("Dept") == Enum.Department.BDA.ToString())
                {
                    result = await _context.Clients.Where(x => x.IsActive.Equals(true)).
                             Include(x => x.History).ThenInclude(x => x.Employees)
                           .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).ToListAsync();

                    falseRegisteredContactNumbers = result
                        .Where(x => !x.Registered)
                        .Select(x => GetContactNumber(x.Contact))
                        .ToList();

                    trueRegisteredContactNumbers = result
                        .Where(x => x.Registered)
                        .Select(x => GetContactNumber(x.Contact))
                        .ToList();

                    // Check if all contact numbers in trueRegisteredContactNumbers are present in the original list
                    bool AreAllRegisteredTrueContacts = trueRegisteredContactNumbers
                        .All(contactNumber => result.Any(x => GetContactNumber(x.Contact) == contactNumber));

                }
                if (_session.GetString("Dept") == Enum.Department.Tech.ToString())
                {
                    if (_session.GetString("Role") == Enum.Roles.Manager.ToString())
                    {
                        result = await _context.Clients.Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false)).
                       Include(x => x.History).ThenInclude(x => x.Employees)
                       .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).ToListAsync();
                    }
                    else if (_session.GetString("Role") == EnumerationDescription.GetDescription(Enum.Roles.TeamLead))
                    {
                        result = await _context.Clients
                    .Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false)
                    && (x.BDA == _session.GetInt32("CurrentUserId") || x.TechExpert == _session.GetInt32("CurrentUserId"))).Include(x => x.History)
                    .ThenInclude(x => x.Employees)
                    .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).ToListAsync();
                        var employees = _employee.GetEmployeeSuperiorWiseTree().Result.Data;
                        foreach (var employee in employees)
                        {
                            var client = await _context.Clients
                    .Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false)
                    && (x.BDA == employee.EmpId || x.TechExpert == employee.EmpId)).Include(x => x.History)
                    .ThenInclude(x => x.Employees)
                    .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).ToListAsync();
                            result.AddRange(client);
                        }
                    }
                    else
                    {
                        result = await _context.Clients
                    .Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false)
                    && (x.BDA == _session.GetInt32("CurrentUserId") || x.TechExpert == _session.GetInt32("CurrentUserId"))).Include(x => x.History)
                    .ThenInclude(x => x.Employees)
                    .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).ToListAsync();
                    }

                }

            }
            else if (_session.GetString("Dept") == Enum.Department.Programming.ToString())
            {
                if (_session.GetString("Role") == EnumerationDescription.GetDescription(Enum.Roles.TeamLead))
                {
                    var employees = _employee.GetEmployeeSuperiorWiseTree().Result.Data;
                    result = await _context.Clients
                .Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false) && x.IsTechAppoinment == true
                && x.Programmer == _session.GetInt32("CurrentUserId")).Include(x => x.History)
                .ThenInclude(x => x.Employees)
                .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).Include(x => x.ProgrammerEmployee).ToListAsync();
                    foreach (var item in employees)
                    {
                        var client = await _context.Clients
                            .Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false) && x.IsTechAppoinment == true
                            && x.Programmer == item.EmpId).Include(x => x.History)
                            .ThenInclude(x => x.Employees)
                            .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).Include(x => x.ProgrammerEmployee).ToListAsync();
                        result.AddRange(client);
                    }
                }
                else
                {
                    result = await _context.Clients
            .Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false) && x.IsTechAppoinment == true
            && x.Programmer == _session.GetInt32("CurrentUserId")).Include(x => x.History)
            .ThenInclude(x => x.Employees)
            .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).Include(x => x.ProgrammerEmployee).ToListAsync();
                }
            }

            else
            {
                result = await _context.Clients
                    .Where(x => x.IsActive.Equals(true) && x.Registered.Equals(false)
                    && (x.BDA == _session.GetInt32("CurrentUserId") || x.TechExpert == _session.GetInt32("CurrentUserId"))).Include(x => x.History)
                    .ThenInclude(x => x.Employees)
                    .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).ToListAsync();
            }

            if (result == null) return (true, new string[] { }, data);

            DateTime date = DateTime.Now.AddDays(1);

            //var splitContact = data.Select(x => x.Contact.Split(" "))[0].ToList();

            data = result.Select(x => new ClientListDto()
            {

                EnquiryId = x.EnquiryId,
                ClientName = x.ClientName,
                Contact = x.Contact,
                Domain = x.Domain,
                TechRemarks = x.History != null
                && x.History.Any(y => (y.Employees.DeptId == (int)Enum.Department.Tech || y.Employees.DeptId == (int)Enum.Department.Programming) && y.IsComment == true)
                ? x.History.LastOrDefault(z => (z.Employees.DeptId == (int)Enum.Department.Tech || z.Employees.DeptId == (int)Enum.Department.Programming) && z.IsComment == true).UpdatedDate.Date.ToString("dd/MM/yyyy") + Environment.NewLine +
                    x.History.LastOrDefault(z => (z.Employees.DeptId == (int)Enum.Department.Tech || z.Employees.DeptId == (int)Enum.Department.Programming) && z.IsComment == true).Comments

                : " ",
                BDARemarks = x.History != null
                && x.History.Any(y => y.Employees.DeptId == (int)Enum.Department.BDA && y.IsComment == true)
                ? x.History.LastOrDefault(z => z.Employees.DeptId == (int)Enum.Department.BDA && z.IsComment == true).UpdatedDate.Date.ToString("dd/MM/yyyy") + Environment.NewLine +
                    x.History.LastOrDefault(z => z.Employees.DeptId == (int)Enum.Department.BDA && z.IsComment == true).Comments
                : " ",
                PaymentRemarks = x.PaymentRemarks,
                EnquiryDate = x.EnquiryDate,
                AppoinmentDate = x.AppoinmentDate,
                EnquiryRef = x.EnquiryRef,
                IsTechAppoinment = x.IsTechAppoinment,
                TechExperts = x.TechEmployee != null ? x.TechEmployee.EmployeeName : "",
                BDA = x.BDAEmployee != null ? x.BDAEmployee.EmployeeName : "",
                Programmer = x.ProgrammerEmployee != null ? x.ProgrammerEmployee.EmployeeName : "",
                Registered = x.Registered,
                IsEmailed = x.IsEmailed,
                IsRegisteredTrueContact = trueRegisteredContactNumbers.Contains(GetContactNumber(x.Contact)) || falseRegisteredContactNumbers
                                        .Count(contactNumber => contactNumber == GetContactNumber(x.Contact)) > 1,
                IsBackToEnquiry = result.Any(y => y.EnquiryRef.Count() > 1)
            }).OrderByDescending(x => x.EnquiryDate).ToList();

            DateTime dtIST = DatetimeExtension.IndiaStandardTimeNow();
            if (chkValue.Equals('F'))
            {   //Future
                DateTime dt = (new DateTime(dtIST.Year, dtIST.Month, dtIST.Day, 10, 30, 0)).AddDays(1);
                data = data.Where(x => x.AppoinmentDate >= dt && x.IsTechAppoinment == false).OrderBy(x => x.AppoinmentDate).ToList();
            }
            else if (chkValue.Equals('P'))
            {   //Past
                DateTime dtTo = (new DateTime(dtIST.Year, dtIST.Month, dtIST.Day, 17, 30, 0)).AddDays(-1);
                dtTo = dtTo.AddDays(-7);
                data = data.Where(x => x.AppoinmentDate < dtTo && x.IsTechAppoinment == false).OrderBy(x => x.AppoinmentDate).ToList();
            }
            else if (chkValue.Equals('L'))
            {   //Last week
                DateTime dtTo = (new DateTime(dtIST.Year, dtIST.Month, dtIST.Day, 17, 30, 0)).AddDays(-1);
                DateTime dtFrom = dtTo.AddDays(-7);
                data = data.Where(x => (x.AppoinmentDate >= dtFrom && x.AppoinmentDate <= dtTo) && x.IsTechAppoinment == false).OrderBy(x => x.AppoinmentDate).ToList();
            }
            else if (chkValue.Equals('T'))
            {   //Today
                DateTime dtFrom = (new DateTime(dtIST.Year, dtIST.Month, dtIST.Day, 17, 30, 0)).AddDays(-1);
                DateTime dtTo = (new DateTime(dtIST.Year, dtIST.Month, dtIST.Day, 10, 30, 0)).AddDays(1);
                data = data.Where(x => (x.AppoinmentDate >= dtFrom && x.AppoinmentDate <= dtTo) && x.IsTechAppoinment == false).OrderBy(x => x.AppoinmentDate).ToList();
            }
            else if (chkValue.Equals('E'))
            {
                data = data.Where(x => x.IsTechAppoinment == true || x.IsEmailed == true).OrderBy(x => x.AppoinmentDate).ToList();
            }

            //Show Tech enabled under ALL
            if (!chkValue.Equals('A') && !chkValue.Equals('E'))
            {
                data = data.Where(x => x.IsTechAppoinment == false).OrderBy(x => x.AppoinmentDate).ToList();
            }

            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }

    public async Task<(bool Succeeded, string[] Error, ClientDetailDto Data)> GetClientDetailAsync(int enquiryId)
    {
        try
        {
            var data = new ClientDetailDto();
            var result = await _context.Clients.Where(x => x.EnquiryId.Equals(enquiryId) && x.IsActive.Equals(true))
                .Include(x => x.BDAEmployee).Include(x => x.TechEmployee).Include(x => x.ProgrammerEmployee)
                .Include(x => x.History).ThenInclude(x => x.Employees).ThenInclude(x => x.Department).FirstOrDefaultAsync();

            if (result == null) return (true, new string[] { }, data);
            var contacts = result.Contact.Split(" ", StringSplitOptions.RemoveEmptyEntries);
            if (contacts.Count() > 0)
                data.MainContactNo = contacts[0];
            if (contacts.Count() > 1)
                data.Email = contacts[1];
            if (contacts.Count() > 2)
                data.AlternateNo = contacts[2];

            data.EnquiryId = result.EnquiryId;
            data.ClientName = result.ClientName;
            data.Contact = result.Contact;
            data.Domain = result.Domain;
            if(result.TechExpert != null)
            {
                var techEmployee = _context.Employees
                         .Where(x => x.EmpId == result.TechExpert && x.RoleId == 2)
                         .Select(e => new { e.EmployeeName, e.IsActive })
                         .FirstOrDefault();
                if (techEmployee == null)
                {
                    techEmployee = _context.Employees
                        .Where(e => e.EmpId == result.TechExpert)
                        .Join(_context.Employees,
                              emp => emp.SuperiorId,
                              superior => superior.EmpId,
                              (emp, superior) => new { superior.EmployeeName, superior.IsActive })
                        .FirstOrDefault();
                }
                data.TechIsActive = techEmployee.IsActive;
            }
            else
            {
                data.TechIsActive = false;
            }
            data.TechName = result.TechEmployee != null ? result.TechEmployee.EmployeeName : "";
            data.BDAName = result.BDAEmployee != null ? result.BDAEmployee.EmployeeName : "";
            data.ProName = result.ProgrammerEmployee != null ? result.ProgrammerEmployee.EmployeeName : "";
            data.TechId = result.TechEmployee != null ? result.TechEmployee.EmpId : null;
            data.BDAId = result.BDAEmployee != null ? result.BDAEmployee.EmpId : null;
            data.ProId = result.ProgrammerEmployee != null ? result.ProgrammerEmployee.EmpId : null;
            data.PaymentRemarks = result.PaymentRemarks;
            data.EnquiryDate = result.EnquiryDate;
            data.AppoinmentDate = new DateTime(result.AppoinmentDate.Value.Year,
                                        result.AppoinmentDate.Value.Month,
                                        result.AppoinmentDate.Value.Day,
                                        result.AppoinmentDate.Value.Hour,
                                        result.AppoinmentDate.Value.Minute,
                                        0);
            data.IsTechAppoinment = result.IsTechAppoinment;
            data.IsEmailed = result.IsEmailed;
            data.EnquiryRef = result.EnquiryRef;
            data.IsAgent = result.IsAgent;
            data.Query = result.ClientQuery;
            data.Token = result.ClientToken;
            data.Discovery = result.Discovery;
            data.PreviousEnquiryId = result.PreviousEnquiryId;
            data.LastComment = result.History != null
                && result.History.Any(y => y.Employees.Department.DeptName == _session.GetString("Dept") && y.IsComment == true && y.EnquiryId == result.EnquiryId)
                ? result.History.LastOrDefault(z => z.Employees.Department.DeptName == _session.GetString("Dept") && z.IsComment == true && z.EnquiryId == result.EnquiryId).Comments
                : "";

            var plagiarism = _context.Plagiarism.Where(x => x.EnquiryId == enquiryId).OrderByDescending(x => x.PlagiarismId).Select(x => new
            {
                x.EnquiryId,
                x.PlagiarismId
            }).FirstOrDefault();
            PlagiarismfileView plagiarismfileView = null;
            if (plagiarism != null)
            {
                var plag = await _context.PlagiarismRecipient.Where(x => x.PlagiarismId == plagiarism.PlagiarismId &&
               x.IsUploaded).ToListAsync();
                plagiarismfileView = new PlagiarismfileView
                {
                    EnquiryId = plagiarism?.EnquiryId ?? 0,
                    PlagFileId = plag.FirstOrDefault(x => x.UploadedFileName.Contains(".docx"))?.PlagiarismRecipientId,
                    PlagFileName = plag.FirstOrDefault(x => x.UploadedFileName.Contains(".docx"))?.UploadedFileName,
                    PlagFilePath = plag.FirstOrDefault(x => x.UploadedFileName.Contains(".docx"))?.UploadedFilePath,
                    AIFileId = plag.FirstOrDefault(x => !x.UploadedFileName.Contains(".docx"))?.PlagiarismRecipientId,
                    AIFileName = plag.FirstOrDefault(x => !x.UploadedFileName.Contains(".docx"))?.UploadedFileName,
                    AIFilePath = plag.FirstOrDefault(x => !x.UploadedFileName.Contains(".docx"))?.UploadedFilePath,
                    CreatedDate = plag.FirstOrDefault()?.CreatedDate
                };
            }
            var enquiryFiles = await _context.EnquiryFiles
                             .Where(x => x.EnquiryId == enquiryId).Select(x => new EnquiryFilesDto
                             {
                                 FileName = x.FileName,
                                 FilePath = x.FilePath,
                                 EnquiryFileId = x.EnquiryFileId,
                                 EnquiryId = x.EnquiryId,
                                 CreatedDate = x.CreatedDate,
                                 IsTech = x.IsTech,
                             }).ToListAsync();
            data.PlagiarismfileView = plagiarismfileView;
            data.EnquiryFilesDto = enquiryFiles;
            return (true, new string[] { }, data);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }

    public async Task<(bool Succeeded, string[] Error)> CreateClientAsync(CreateClientDto dto)
    {
        try
        {
            if (dto.IsAgent == false)
            {
                var contacts = await _context.Clients.FirstOrDefaultAsync(x => x.Contact.Contains(dto.ContactNo) || (!string.IsNullOrEmpty(dto.AlternateNo) && x.Contact.Contains(dto.AlternateNo)) || (!string.IsNullOrEmpty(dto.Email) && x.Contact.Contains(dto.Email)));
                if (contacts != null)
                {
                    contacts.IsAgent = dto.IsAgent;
                    _context.Update(contacts);
                    await _context.SaveChangesAsync();
                    string message = "Client already exists. Please contact the Manager";
                    return (false, new string[] { message });
                }
            }
            var map = _mapper.Map<Clients>(dto);
            var techExpert = _context.Employees
            .Where(x => x.EmpId == dto.TechExpert && x.RoleId == 2).Select(x => x.EmpId).FirstOrDefault();
            if (techExpert == null || techExpert == 0)
            {
                techExpert = _context.Employees.Where(e => e.EmpId == dto.TechExpert).Join(_context.Employees, emp => emp.SuperiorId,
                          superior => superior.EmpId,
                          (emp, superior) => superior.EmpId)
                    .FirstOrDefault();
            }
            map.TechTL = techExpert;
            map.AppoinmentDate = null;
            map.BDA = _session.GetInt32("CurrentUserId");
            map.IsTechAppoinment = dto.IsTechAppoinment;
            map.IsAgent = dto.IsAgent;
            await _context.AddAsync(map);
            int result = await _context.SaveChangesAsync().ConfigureAwait(false);
            if (result > 0)
            {
                if (dto.AppoinmentDate.HasValue)
                {
                    await UpdateAppoinmentDateAsync(dto.AppoinmentDate.Value, map.EnquiryId);
                }
                if (!string.IsNullOrEmpty(dto.BDARemarks))
                    await AddEnquiryActivity(map.EnquiryId, (int)_session.GetInt32("CurrentUserId"), dto.BDARemarks, true);
            }
            return (true, new string[] { "Client successfully created" });
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message });
        }

    }

    public async Task<(bool Succeeded, string[] Error, EditClientDto data)> EditClientFormAsync(int enquiryId)
    {
        try
        {
            var result = await _context.Clients.FindAsync(enquiryId);
            var map = _mapper.Map<EditClientDto>(result);
            var contacts = result.Contact.Split(" ", StringSplitOptions.RemoveEmptyEntries);
            if(contacts.Count() > 0)
                map.ContactNo = contacts[0];
            if (contacts.Count() > 1)
                map.Email = contacts[1];
            if (contacts.Count() > 2)
                map.AlternateNo = contacts[2];
            return (true, new string[] { }, map);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }

    public async Task<(bool Succeeded, string[] Error)> EditClientAsync(EditClientDto dto)
    {
        try
        {
            var client = await _context.Clients.FindAsync(dto.EnquiryId);

            // Check if the ContactNo is changing and if the new ContactNo already exists in other records
            if (!string.IsNullOrEmpty(dto.ContactNo) && !client.Contact.Contains(dto.ContactNo))
            {
                var contactExists = await _context.Clients
                    .AnyAsync(x => x.EnquiryId != dto.EnquiryId && x.Contact.Contains(dto.ContactNo));

                if (contactExists)
                {
                    return (false, new string[] { "Client with the same contact number already exists. Please contact the Manager." });
                }
            }

            // Check if the AlternateNo is provided, changing, and if it already exists in other records
            if (!string.IsNullOrEmpty(dto.AlternateNo) && !client.Contact.Contains(dto.AlternateNo))
            {
                var alternateExists = await _context.Clients
                    .AnyAsync(x => x.EnquiryId != dto.EnquiryId && x.Contact.Contains(dto.AlternateNo));

                if (alternateExists)
                {
                    return (false, new string[] { "Client with the same alternate number already exists. Please contact the Manager." });
                }
            }

            // Check if the Email is provided, changing, and if it already exists in other records
            if (!string.IsNullOrEmpty(dto.Email) && !client.Contact.Contains(dto.Email))
            {
                var emailExists = await _context.Clients
                    .AnyAsync(x => x.EnquiryId != dto.EnquiryId && x.Contact.Contains(dto.Email));

                if (emailExists)
                {
                    return (false, new string[] { "Client with the same email already exists. Please contact the Manager." });
                }
            }

            // If no conflicts, update the client's contact information
            var map = _mapper.Map<EditClientDto, Clients>(dto, client);
            map.Contact = string.Join(" ", dto.ContactNo, dto.Email, dto.AlternateNo).Trim(); // Join the new contact info

            _context.Update(map);
            await _context.SaveChangesAsync().ConfigureAwait(false);

            return (true, new string[] { "Client successfully updated" });
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message });
        }
    }

    public async Task<(bool Succeeded, string[] Error)> DeleteClientAsync(int enquiryId)
    {
        try
        {
            var client = await _context.Clients.FindAsync(enquiryId);
            _context.Remove(client);
            await _context.SaveChangesAsync().ConfigureAwait(false);
            return (true, new string[] { "Client successfully removed" });
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message });
        }

    }

    public async Task<(bool Succeeded, string[] Error)> UpdateBDAForClientAsync(int bdaId, int enquiryId)
    {
        try
        {
            var result = await _context.Clients.FindAsync(enquiryId);
            result.BDA = bdaId;
            _context.Update(result);
            int val = await _context.SaveChangesAsync().ConfigureAwait(false);
            if (val > 0)
            {
                string message = "Assigned BDA";
                await AddEnquiryActivity(result.EnquiryId, bdaId, message);
            }
            return (true, new string[] { });
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message });
        }

    }

    public async Task<(bool Succeeded, string[] Error)> UpdateTechExpertForClientAsync(int techId, int enquiryId)
    {
        try
        {
            var result = await _context.Clients.FindAsync(enquiryId);
            result.TechExpert = techId;
            var TechnicalId = _context.Employees.Where(x => x.EmpId == techId && x.RoleId == 2).Select(x => x.EmpId).FirstOrDefault();
            if (TechnicalId == 0)
            {
                TechnicalId = _context.Employees
                        .Where(e => e.EmpId == techId)
                        .Join(_context.Employees,
                              emp => emp.SuperiorId,
                              superior => superior.EmpId,
                              (emp, superior) => superior.EmpId)
                        .FirstOrDefault();
            }
            result.TechTL = TechnicalId;
            _context.Update(result);
            int val = await _context.SaveChangesAsync().ConfigureAwait(false);
            if (val > 0)
            {
                string message = "Assigned Technician";
                await AddEnquiryActivity(result.EnquiryId, techId, message);
            }
            return (true, new string[] { });
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message });
        }

    }

    public async Task<(bool Succeeded, string[] Error)> UpdateProgrammerForClientAsync(int pgmId, int enquiryId)
    {
        try
        {
            var result = await _context.Clients.FindAsync(enquiryId);
            result.Programmer = pgmId;
            var ProgrammerId = _context.Employees.Where(x => x.EmpId == pgmId && x.RoleId == 2).Select(x => x.EmpId).FirstOrDefault();
            if (ProgrammerId == 0)
            {
                ProgrammerId = _context.Employees
                        .Where(e => e.EmpId == pgmId)
                        .Join(_context.Employees,
                              emp => emp.SuperiorId,
                              superior => superior.EmpId,
                              (emp, superior) => superior.EmpId)
                        .FirstOrDefault();
            }
            result.ProgrammerTL = ProgrammerId;
            _context.Update(result);
            int val = await _context.SaveChangesAsync().ConfigureAwait(false);
            if (val > 0)
            {
                string message = "Assigned Programmer";
                await AddEnquiryActivity(result.EnquiryId, pgmId, message);
            }
            return (true, new string[] { });
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message });
        }

    }

    public async Task<(bool Succeeded, string[] Error, IList<ClientActivityDto> Data)> GetClientActivityAsync(int enquiryId, bool isComment)
    {
        try
        {
            var data = new List<ClientActivityDto>();
            var history = await _context.Clients.Where(x => x.EnquiryId == enquiryId).Include(x => x.History).Include(x => x.EnquiryFiles)
                .Include(x => x.Plagiarism).ThenInclude(x => x.PlagiarismRecipients).Include(x => x.Emails).ToListAsync();
            var result = await _context.History.Where(x => x.EnquiryId.Equals(enquiryId))
    .Include(x => x.Employees).Include(x => x.Clients).ToListAsync();

            if (result == null) return (true, new string[] { }, data);
            if (result == null && !isComment) return (true, new string[] { }, data);
             data = result.Where(t => t.IsComment == isComment).Select(x => new ClientActivityDto()
            {
                Id = x.HistoryId,
                ClientName = x.Clients.ClientName,
                EmployeeName = x.Employees.EmployeeName,
                Comments = x.Comments,
                CreatedDate = x.CreatedDate
            }).OrderByDescending(t => t.CreatedDate).ThenByDescending(t => t.Id).ToList();
            var emailQuery = _context.Emails
                 .Where(x => x.EnquiryId.Equals(enquiryId))
                 .Include(x => x.EmailAttachmentsFiles)
                 .Include(x => x.Clients).AsQueryable(); ;
            if ((_session.GetString("Dept") == Enum.Department.Tech.ToString() || _session.GetString("Dept") == Enum.Department.Programming.ToString()) && _session.GetString("Role") != Enum.Roles.Manager.ToString())
            {
                emailQuery = emailQuery.Where(x => !x.Visibility);
            }
            var role = _session.GetString("Role");
            var department = _session.GetString("Dept");
            var emailData = emailQuery.Select(x => new ClientActivityDto
                            {
                                Id = x.EmailId,
                                ClientName = x.IsSender ? x.ClientName : x.Clients.ClientName,
                                EmployeeName = null,
                                Comments = x.UpdatedMessage,
                                CreatedDate = x.ReceivedDate,
                                EmailAttachmentDto = x.EmailAttachmentsFiles.Where(a => a.IsSelected &&
                                ((department == Enum.Department.Tech.ToString() && x.IsTechVisibility) ||
                                    (department == Enum.Department.Programming.ToString() && x.IsProgrammerVisibility) ||
                                    department == Enum.Department.BDA.ToString() || role == Enum.Roles.Manager.ToString()
                                )).Select(a => new EmailAttachmentDto
                                            {
                                                AttachmentFileId = a.EmailAttachmentId,
                                                AttachmentFilePath = a.AttachmentFilePath,
                                                AttachmentFileName = a.AttachmentFileName
                                            }).ToList(),
                            }).ToList();
            var enquiryFilesRaw = await _context.EnquiryFiles
                .Where(x => x.EnquiryId == enquiryId)
                .Include(x => x.Employees)
                .Select(x => new
                {
                    Id = x.EnquiryId,
                    EmployeeName = x.Employees.EmployeeName,
                    CreatedDate = x.CreatedDate,
                    FileName = x.FileName,
                    FilePath = x.FilePath
                })
                .ToListAsync();  // Materialize the query first

            // Grouping by formatted date (ToString("d")) and Id
            var enquiryFiles = enquiryFilesRaw
                .GroupBy(x => new { x.Id, FormattedDate = x.CreatedDate.ToString("g") })  // Group by Id and formatted date
                .Select(group => new ClientActivityDto
                {
                    Id = group.Key.Id,
                    CreatedDate = DateTime.Parse(group.Key.FormattedDate),
                    EmployeeName = group.FirstOrDefault()?.EmployeeName,                   
                    EmailAttachmentDto = group.Select(g => new EmailAttachmentDto
                    {
                        AttachmentFileName = g.FileName,
                        AttachmentFilePath = g.FilePath
                    }).ToList()  // Collect all attachment details from the group
                })
                .ToList();

            var plagiarism = _context.PlagiarismRecipient
                .Where(x => x.Plagiarism.EnquiryId == enquiryId && x.IsUploaded)
                .ToList(); // Load data into memory
            var plag = new List<ClientActivityDto>();
            if (plagiarism != null)
            {
                 plag = plagiarism
                    .GroupBy(x => new
                    {
                        x.PlagiarismId,
                        CreatedDate = x.CreatedDate.Date // Group by date part only
                    })
                    .Select(group => new ClientActivityDto
                    {
                        CreatedDate = group.Key.CreatedDate, // Keep the DateTime for now
                        EmployeeName = null,
                        EmailAttachmentDto = group.Select(g => new EmailAttachmentDto
                        {
                            AttachmentFileName = g.UploadedFileName.Contains(".docx") ? $"<span style='color:darkred'>Plag</span> : {g.UploadedFileName}" : $"<span style='color:darkred'>AI</span> : {g.UploadedFileName}",
                            AttachmentFilePath = g.UploadedFilePath
                        }).ToList()
                    })
                    .ToList(); // Final list of grouped data
            }

            var combinedData = data
                .Union(emailData).Union(enquiryFiles).Union(plag)
                .OrderByDescending(t => t.CreatedDate)
                .ThenByDescending(t => t.Id)
                .ToList();
            return (true, new string[] { }, combinedData);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }

    public async Task<(bool Succeeded, string[] Error)> UpdatePaymentRemarksAsync(int enquiryId, string remarks, bool isRegsitered)
    {
        try
        {
            var result = await _context.Clients.FindAsync(enquiryId);
            result.PaymentRemarks = remarks;
            result.Registered = isRegsitered;
            _context.Update(result);
            await _context.SaveChangesAsync().ConfigureAwait(false);
            return (true, new string[] { });
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message });
        }

    }

    public async Task AddEnquiryActivity(int enquiryId, int empId, string comment, bool isComment = false)
    {
        var history = new History()
        {
            EnquiryId = enquiryId,
            EmpId = empId,
            Comments = comment,
            IsComment = isComment
        };
        await _context.AddAsync(history);
        await _context.SaveChangesAsync().ConfigureAwait(false);
    }

    public async Task<(bool Succeeded, string[] Error)> UpdateAppoinmentDateAsync(DateTime appoinmentDate, int enquiryId)
    {
        try
        {
            string message = String.Empty;
            var result = await _context.Clients.FindAsync(enquiryId);

            if (result.AppoinmentDate == null) message = $"Appoinment dated on {appoinmentDate}";
            else message = $"Changed appoinment date from {result.AppoinmentDate} to {appoinmentDate}";

            result.AppoinmentDate = DatetimeExtension.ToDateTime(appoinmentDate);
            _context.Update(result);
            int val = await _context.SaveChangesAsync().ConfigureAwait(false);
            if (val > 0)
            {
                await AddEnquiryActivity(result.EnquiryId, (int)_session.GetInt32("CurrentUserId"), message);
            }
            return (true, new string[] { });
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message });
        }
    }

    public async Task<(bool Succeeded, string[] Error)> UpdateAsTechAppoinmentAsync(bool ChkValue, int enquiryId)
    {
        try
        {
            string message = String.Empty;
            var result = await _context.Clients.Where(x => x.EnquiryId == enquiryId)
                .Include(x => x.TechEmployee).Include(x => x.BDAEmployee).FirstOrDefaultAsync();
            var appointmentDateForSchedule = result.AppoinmentDate;
            DateTime dt = DatetimeExtension.IndiaStandardTimeNow();
            if (ChkValue) result.AppoinmentDate = appointmentDateForSchedule;
            else result.AppoinmentDate = dt;
            result.IsTechAppoinment = ChkValue;
            result.IsEmailed = false;
            _context.Update(result);
            int val = await _context.SaveChangesAsync().ConfigureAwait(false);
            if (val > 0)
            {
                string memberId = string.Empty;
                if (ChkValue)
                {
                    var uriBuilder = new UriBuilder
                    {
                        Scheme = _httpContext.Request.Scheme,
                        Host = _httpContext.Request.Host.Host,
                        Port = _httpContext.Request.Host.Port ?? (_httpContext.Request.Scheme == "https" ? 443 : 80),
                        Path = $"Enquiry/GetClientActivity?enquiryId={result.EnquiryId}&isComment=true&isActive=true"
                    };

                    Uri fileUri = uriBuilder.Uri;
                    string fileDownloadLink = Uri.UnescapeDataString(fileUri.ToString());
                    message = $"Enquiry: An appointment was scheduled with {result.ClientName} ({result.Domain}) on {result.AppoinmentDate.Value.ToString("dd/MM/yy hh:mm tt")} <{fileDownloadLink} | Details>";
                    memberId = result.TechEmployee.MemberId;
                    double timeRemains = (appointmentDateForSchedule.Value - DateTime.Now).TotalMinutes;
                    if (timeRemains > 10)
                        _backgroundJobClient.Schedule(() => _slack.SendMessage(message, memberId), TimeSpan.FromMinutes(timeRemains - 5));
                    else
                        await _slack.SendMessage(message, memberId);
                }
                if (!ChkValue)
                {
                    var uriBuilder = new UriBuilder
                    {
                        Scheme = _httpContext.Request.Scheme,
                        Host = _httpContext.Request.Host.Host,
                        Port = _httpContext.Request.Host.Port ?? (_httpContext.Request.Scheme == "https" ? 443 : 80),
                        Path = $"Enquiry/GetClientActivity?enquiryId={result.EnquiryId}&isComment=true&isActive=true"
                    };

                    Uri fileUri = uriBuilder.Uri;
                    string fileDownloadLink = Uri.UnescapeDataString(fileUri.ToString());
                    message = $"{result.TechEmployee.EmployeeName} has disabled the technical discussion of {result.ClientName}<{fileDownloadLink} | Details>";
                    await _slack.SendMessage(message, result.BDAEmployee.MemberId);
                }
                await AddEnquiryActivity(result.EnquiryId, (int)_session.GetInt32("CurrentUserId"), message);
            }
            return (true, new string[] { });
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message });
        }
    }

    public async Task<(bool Succeeded, string[] Error)> UpdateIsEmailedAsync(int enquiryId, bool isEmailed)
    {
        try
        {
            var result = await _context.Clients.Where(x => x.EnquiryId == enquiryId)
                .Include(x => x.TechEmployee).Include(x => x.BDAEmployee).FirstOrDefaultAsync();
            DateTime dt = DatetimeExtension.IndiaStandardTimeNow();
            result.IsEmailed = isEmailed;
            _context.Update(result);
            int val = await _context.SaveChangesAsync().ConfigureAwait(false);
            if(val > 0 && !isEmailed)
            {
                var message = $"{result.TechEmployee.EmployeeName} has disabled the technical discussion of {result.ClientName}";
                await _slack.SendMessage(message, result.BDAEmployee.MemberId);
            }
            return (true, new string[] { });
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message });
        }
    }
    public async Task<(bool Succeeded, string[] Error, Clients Clients)> IsRegisteredAsync(int enquiryId, bool isRegsitered)
    {
        try
        {
            var result = await _context.Clients.FindAsync(enquiryId);
            result.Registered = isRegsitered;
            _context.Update(result);
            await _context.SaveChangesAsync().ConfigureAwait(false);
            return (true, new string[] { }, result);
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message }, null);
        }

    }

    public async Task<(bool Succeeded, string[] Error)> UpdateBackToEnquiryAsync(int enquiryId)
    {
        try
        {
            var client = await _context.Clients.FindAsync(enquiryId);
            client.BackToEnquiry = true;
            _context.Update(client);
            int result = await _context.SaveChangesAsync().ConfigureAwait(false);
            var src = DateTime.Now;
            if (result > 0)
            {
                var map = _mapper.Map<Clients>(client);
                map.EnquiryId = 0;
                map.PreviousEnquiryId = enquiryId;
                map.IsTechAppoinment = false;
                map.Registered = false;
                map.BackToEnquiry = false;
                map.AppoinmentDate = new DateTime(src.Year, src.Month, src.Day, src.Hour, src.Minute, 0);
                await _context.AddAsync(map);
                await _context.SaveChangesAsync().ConfigureAwait(false);
            }
            return (true, new string[] { });
        }
        catch (Exception ex)
        {

            return (false, new string[] { ex.Message });
        }
    }

    public async Task<(bool Succeeded, string[] Error, IList<IndividualClientListDto> Data)> GetContactBasedClientsAsync(string username)
    {
        var result = await _context.Projects.Where(x => x.Clients.Contact.Contains(username))
            .Include(x => x.Clients).Include(x => x.Phase).ThenInclude(x => x.WorkStatus).
            Select(x => new IndividualClientListDto()
            {
                EnquiryId = x.Clients.EnquiryId,
                ClientName = x.Clients.ClientName,
                EnquiryRef = x.Clients.EnquiryRef,
                Domain = x.Clients.Domain,
                Contact = x.Clients.Contact,
                projectId = x.ProjectId,
                RegistrationDate = x.RegistrationDate,
                Status = x.Phase.OrderBy(x => x.ProjectId).LastOrDefault().WorkStatus.WorkStatusName
            }).OrderByDescending(x => x.RegistrationDate).ToListAsync();
        if (result == null) return (true, new string[] { "No client records found" }, null);
        return (true, new string[] { }, result);
    }
     
    public async Task<bool> ClientFormAsync( string token , int enquiryid)
    {
        var clienttoken =  _context.Clients.Where(x => x.EnquiryId == enquiryid).FirstOrDefault();
        if (clienttoken!=null)
        {
            clienttoken.ClientToken=token;
            _context.Update(clienttoken);
          await _context.SaveChangesAsync();
            return true;
        }
        else
        {
            return false;
        }
    }

    public async Task<(bool Succeeded, string[] Error, ClientformDto clientform)> GetClientFormDetailsAsync (string token)
    {
        try
        {
            var clienttoken =await _context.Clients.Where(x => x.ClientToken == token && x.ClientToken != null).Select(x => new ClientformDto() { ClientName = x.ClientName, Contact = x.Contact, Domain=x.Domain}).FirstOrDefaultAsync();
            if (clienttoken!=null) {
                return (true, null, clienttoken);
            }
            else
            {
                return (false, null, null);
            }
        }
        catch(Exception ex)
        {
            return (false, new[] { ex.Message }, null);
        }
    }
    public async Task<bool> UpdateClientFormAsync(ClientformDto formdto)
    {
        var clientData = _context.Clients.Where(x => x.ClientToken == formdto.ClientToken).FirstOrDefault();
        if (clientData != null)
        {
            //clientData.ResearchArea = formdto.ResearchArea;
            //clientData.Requirements = formdto.Requirements;
            clientData.Discovery = formdto.Discovery;
            clientData.ClientQuery = formdto.ClientQuery;
            clientData.DateOfBirth = formdto.DateOfBirth;
            clientData.ClientToken = null;
            _context.Update(clientData);
            await _context.SaveChangesAsync();
            return true;
        }
        else
        {
            return false;
        }
    }
    public async Task<(bool Succeeded, string[] Error)> CreateClientDataAsync(DataDto dataDto)
    {
        try
        {
            var dataId = _context.Data
            .Where(x =>
                (!string.IsNullOrEmpty(dataDto.PhoneNo1) && (x.PhoneNo1 == dataDto.PhoneNo1 || x.PhoneNo2 == dataDto.PhoneNo1)) ||
                (!string.IsNullOrEmpty(dataDto.PhoneNo2) && (x.PhoneNo1 == dataDto.PhoneNo2 || x.PhoneNo2 == dataDto.PhoneNo2)) ||
                (!string.IsNullOrEmpty(dataDto.Email1) && (x.Email1 == dataDto.Email1 || x.Email2 == dataDto.Email1)) ||
                (!string.IsNullOrEmpty(dataDto.Email2) && (x.Email1 == dataDto.Email2 || x.Email2 == dataDto.Email2))
            )
            .Select(x => x.DataId)
            .FirstOrDefault();

            var contacts = await _context.Clients.FirstOrDefaultAsync(x => x.Contact.Contains(dataDto.PhoneNo1) || x.Contact.Contains(dataDto.PhoneNo2) || (!string.IsNullOrEmpty(dataDto.Email1) && x.Contact.Contains(dataDto.Email1)) || (!string.IsNullOrEmpty(dataDto.Email2) && x.Contact.Contains(dataDto.Email2)));
            if (dataId == 0 && contacts == null)
            {
                var clientData = _mapper.Map<Data>(dataDto);
                _context.Data.Add(clientData);
                await _context.SaveChangesAsync();
            }
            else if (dataId > 0 && contacts == null)
            {
                var clientData = await _context.Data.FindAsync(dataId);
                if (clientData != null)
                {
                    clientData.Name = dataDto.Name;
                    clientData.Department = dataDto.Department;
                    clientData.PhoneNo1 = dataDto.PhoneNo1;
                    clientData.PhoneNo2 = dataDto.PhoneNo2;
                    clientData.Email1 = dataDto.Email1;
                    clientData.Email2 = dataDto.Email2;
                    _context.Data.Update(clientData);
                    await _context.SaveChangesAsync();
                }
            }

            return (true, null);
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message });
        }
    }
    public async Task<(bool Succeeded, string[] Error, DataDto data)> GetClientDetailAsync(string PhoneNo)
    {
        try
        {
            var contacts = await _context.Clients.FirstOrDefaultAsync(x => x.Contact.Contains(PhoneNo) || x.Contact.Contains(PhoneNo) 
            || (!string.IsNullOrEmpty(PhoneNo) && x.Contact.Contains(PhoneNo)) || (!string.IsNullOrEmpty(PhoneNo) 
            && x.Contact.Contains(PhoneNo)));
            if(contacts != null)
            {
                return (false, null, null);
            }
            else
            {
               var result = await _context.Data.Where(x => x.PhoneNo1 == PhoneNo || x.PhoneNo2 == PhoneNo || x.Email1 == PhoneNo || x.Email2 == PhoneNo).Select(x => new DataDto
                {
                    Name = x.Name,
                    Department = x.Department,
                    PhoneNo1 = x.PhoneNo1,
                    PhoneNo2 = x.PhoneNo2,
                    Email1 = x.Email1,
                    Email2 = x.Email2,
                }).FirstOrDefaultAsync();
                return (true, null, result);
            }
        }
        catch (Exception ex) { 
            return (false,(new string[] { ex.Message }), null);
        }
    }
    public async Task<(bool Succeeded, string[] Error, DataCount dataCount)> GetDataCountAsync()
    {
        try
        {
            DateTime today = DateTime.Today;

            var result = await _context.Data
                .GroupBy(x => 1)
                .Select(g => new DataCount
                {
                    // Counts for today
                    TodayPhoneNumberCount = g.Count(x => x.CreatedDate.Date == today && !string.IsNullOrEmpty(x.PhoneNo1)) + g.Count(x => x.CreatedDate.Date == today && !string.IsNullOrEmpty(x.PhoneNo2)),
                    TodayEmailCount = g.Count(x => x.CreatedDate.Date == today && !string.IsNullOrEmpty(x.Email1)) + g.Count(x => x.CreatedDate.Date == today && !string.IsNullOrEmpty(x.Email2)),
                    TotalPhoneNumberCount = g.Count(x => !string.IsNullOrEmpty(x.PhoneNo1)) + g.Count(x => !string.IsNullOrEmpty(x.PhoneNo2)),
                    TotalEmailCount = g.Count(x => !string.IsNullOrEmpty(x.Email1)) + g.Count(x => !string.IsNullOrEmpty(x.Email2)),
                })
                .FirstOrDefaultAsync();
            return (true, null, result);
        }
        catch (Exception ex)
        {
            return (false, (new string[] { ex.Message }), null);
        }
    }
    public async Task<(bool Succeeded, string[] Errors)> CreateEnquiryFileAsync(EnquiryFiles file)
    {
        try
        {
            await _context.EnquiryFiles.AddAsync(file);
            await _context.SaveChangesAsync();
            return (true, new string[] { "Files added successfully" });
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message });
        }
    }
    public async Task<(bool Succeeded, string[] Error, ComposedEmailDto compose)> GetClientEmailIdAsync(int? enquiryId, int? projectId, bool IsPublication)
    {
        try
        {
            var composedEmail = new ComposedEmailDto();
            int empId = (int)_session.GetInt32("CurrentUserId");
            var plagFiles = new PlagiarismfileView();
            var PhasefileView = new PhasefileView();
            if (empId > 0)
            {
                var employee = await _context.Employees.FindAsync(empId);
                composedEmail.EmployeeName = employee.EmployeeName;
                composedEmail.Designation = employee.Designation;
            }
            dynamic client = null;
            int? techTL = null;
            int? pgmTL = null;
            if (enquiryId != null)
            {
                client = _context.Clients
                   .Where(x => x.EnquiryId == enquiryId)
                   .Select(x => new {
                       TechTL = x.TechTL,
                       PgmTL = x.ProgrammerTL,
                       Contacts = x.Contact,
                       Subject = x.IsAgent ? $"Enquiry | {x.EnquiryRef} | " +
           (x.ClientName.Contains("(") && x.ClientName.Contains(")")
               ? x.ClientName.Substring(x.ClientName.IndexOf("(") + 1, x.ClientName.IndexOf(")") - x.ClientName.IndexOf("(") - 1)
               : string.Empty) : $"Enquiry | {x.EnquiryRef}"
                   })
                   .FirstOrDefault();
                techTL = client.TechTL;
                pgmTL = client.PgmTL;
            }
            else if (projectId != null && !IsPublication)
            {
                client = _context.Projects.Where(x => x.ProjectId == projectId).Include(x => x.Clients).Select(x => new {
                    Contacts = x.Clients.Contact,
                    Subject = x.Clients.IsAgent ? $"{x.ProjectName} | {x.ProjectRef} | " +
            (x.Clients.ClientName.Contains("(") && x.Clients.ClientName.Contains(")")
                ? x.Clients.ClientName.Substring(x.Clients.ClientName.IndexOf("(") + 1, x.Clients.ClientName.IndexOf(")") - x.Clients.ClientName.IndexOf("(") - 1)
                : string.Empty) : $"{x.ProjectName} | {x.ProjectRef} "
                }).FirstOrDefault();
                var phaseId = _context.Phase.Where(x => x.ProjectId == projectId).OrderBy(x => x.PhaseId).Select(x => x.PhaseId).LastOrDefault();
                var phaseFiles = _context.PhaseFiles
                    .Where(x => x.PhaseId == phaseId && !x.IsPublication)
                    .Select(x => new PhaseFilesDto
                    {
                        FileName = x.FileName,
                        FilePath = x.FilePath,
                        PhaseFileId = x.PhaseFileId,
                        PhaseId = x.PhaseId,
                        IsPublication = x.IsPublication
                    })
                    .ToList();

                PhasefileView = new PhasefileView
                {
                    IsPublication = phaseFiles.FirstOrDefault()?.IsPublication,
                    PhaseId = phaseId, // Since there's only one PhaseId
                    ProposalId = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Proposal_Manuscript_Thesis"))?.PhaseFileId,
                    ProposalPath = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Proposal_Manuscript_Thesis"))?.FilePath,
                    Proposal = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Proposal_Manuscript_Thesis"))?.FileName,
                    VisoId = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Viso"))?.PhaseFileId,
                    VisoPath = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Viso"))?.FilePath,
                    Viso = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Viso"))?.FileName,
                    ReferencePaperId = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("ReferencePaper"))?.PhaseFileId,
                    ReferencePaperPath = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("ReferencePaper"))?.FilePath,
                    ReferencePaper = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("ReferencePaper"))?.FileName,
                    OthersId = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Others"))?.PhaseFileId,
                    OthersPath = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Others"))?.FilePath,
                    Others = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Others"))?.FileName,
                    CodeId = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Code"))?.PhaseFileId,
                    CodePath = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Code"))?.FilePath,
                    Code = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Code"))?.FileName,
                    DataSetId = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("DataSet"))?.PhaseFileId,
                    DataSetPath = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("DataSet"))?.FilePath,
                    DataSet = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("DataSet"))?.FileName,
                    GraphId = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Graph"))?.PhaseFileId,
                    GraphPath = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Graph"))?.FilePath,
                    Graph = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Graph"))?.FileName,
                    OthersPgmId = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Others(p)"))?.PhaseFileId,
                    OthersPgmPath = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Others(p)"))?.FilePath,
                    OthersPgm = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Others(p)"))?.FileName
                };

                var lastplag = _context
                    .Plagiarism
                    .Where(x => x.PhaseId == phaseId).OrderBy(x=> x.PlagiarismId)
                    .Select(x => x.PlagiarismId)
                    .LastOrDefault();

                if (lastplag != 0)
                {
                    var recipients = _context
                        .PlagiarismRecipient
                        .Where(x => x.PlagiarismId == lastplag && x.IsUploaded).Select(x=> new
                        {
                            UploadedFileName = x.UploadedFileName,
                            UploadedFilePath = x.UploadedFilePath
                        })
                        .ToList();
                    if(recipients.Any())
                    plagFiles = new PlagiarismfileView
                    {
                        PlagFileName = recipients.FirstOrDefault().UploadedFileName.Contains(".docx") ? recipients.FirstOrDefault().UploadedFileName : null,
                        PlagFilePath = recipients.FirstOrDefault().UploadedFileName.Contains(".docx") ? recipients.FirstOrDefault().UploadedFilePath : null,
                        AIFileName = !recipients.FirstOrDefault().UploadedFileName.Contains(".docx") ? recipients.FirstOrDefault().UploadedFileName : null,
                        AIFilePath = !recipients.FirstOrDefault().UploadedFileName.Contains(".docx") ? recipients.FirstOrDefault().UploadedFilePath : null,
                    };
                }

            }
            else if (projectId != null && IsPublication)
            {
                client = _context.Projects.Where(x => x.ProjectId == projectId).Include(x => x.Clients).Include(x => x.Phase).Select(x => new
                {
                    Contacts = x.Clients.Contact,
                    Subject = x.Clients.IsAgent ? $"{x.Phase.Where(p => p.Status == 4).OrderByDescending(p => p.PhaseId).Select(p => p.PhaseName).FirstOrDefault()} | {x.ProjectRef} | " +
            (x.Clients.ClientName.Contains("(") && x.Clients.ClientName.Contains(")")
                ? x.Clients.ClientName.Substring(x.Clients.ClientName.IndexOf("(") + 1, x.Clients.ClientName.IndexOf(")") - x.Clients.ClientName.IndexOf("(") - 1)
                : string.Empty) : $"{x.Phase.Where(p => p.Status == 4).OrderByDescending(p => p.PhaseId).Select(p => p.PhaseName).FirstOrDefault()} | {x.ProjectRef} "
                }).FirstOrDefault();
            }
            if (client != null)
            {
                composedEmail.ToAddress = !string.IsNullOrEmpty(client.Contacts)
                        ? client.Contacts.Split(' ')[1]
                        : null;
                composedEmail.TechTL = techTL;
                composedEmail.PgmTL = pgmTL; 
                composedEmail.EnquiryId = enquiryId;
                composedEmail.ProjectId = projectId;
                composedEmail.Subject = client.Subject;
                composedEmail.Proposal = PhasefileView.Proposal;
                composedEmail.ProposalPath = PhasefileView.ProposalPath;
                composedEmail.ReferencePaper = PhasefileView.ReferencePaper;
                composedEmail.ReferencePaperPath = PhasefileView.ReferencePaperPath;
                composedEmail.Viso = PhasefileView.Viso;
                composedEmail.VisoPath = PhasefileView.VisoPath;
                composedEmail.Others = PhasefileView.Others;
                composedEmail.OthersPath = PhasefileView.OthersPath;
                composedEmail.Code = PhasefileView.Code;
                composedEmail.CodePath = PhasefileView.CodePath;
                composedEmail.DataSet = PhasefileView.DataSet;
                composedEmail.DataSetPath = PhasefileView.DataSetPath;
                composedEmail.Graph = PhasefileView.Graph;
                composedEmail.GraphPath = PhasefileView.GraphPath;
                composedEmail.OthersPgm = PhasefileView.OthersPgm;
                composedEmail.OthersPgmPath = PhasefileView.OthersPgmPath;
                composedEmail.PlagFileName = plagFiles.PlagFileName;
                composedEmail.PlagFilePath = plagFiles.PlagFilePath;
                composedEmail.AIFileName = plagFiles.AIFileName;
                composedEmail.AIFilePath = plagFiles.AIFilePath;
                return (true, new string[] { }, composedEmail);
            }

            return (false, new string[] { "Client not found" }, null);
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message }, null);
        }
    }
    public async Task<(bool Succeeded, string[] Error, ComposedEmailDto reply)> GetClientReplyEmailAsync(int? enquiryId, int emailId, int? projectId, bool IsPublication)
    {
        try
        {
            var replyEmail = new ComposedEmailDto();
            int empId = (int)_session.GetInt32("CurrentUserId");
            var plagFiles = new PlagiarismfileView();
            var PhasefileView = new PhasefileView();
            if (empId > 0)
            {
                var employee = await _context.Employees.FindAsync(empId);
                replyEmail.EmployeeName = employee.EmployeeName;
                replyEmail.Designation = employee.Designation;
            }
            string client = null;
            string projectOrEnquiryRef = null;
            int? techTL = null;
            int? pgmTL = null;
            if (enquiryId != null)
            {
               var clientData = _context.Clients
                   .Where(x => x.EnquiryId == enquiryId)
                   .Select(x => new { x.Contact, x.EnquiryRef,x.TechTL,x.ProgrammerTL })
                   .FirstOrDefault();
                techTL = clientData.TechTL;
                pgmTL = clientData.ProgrammerTL;
                client = clientData.Contact;
                projectOrEnquiryRef = clientData.EnquiryRef;
            }
            else if (projectId != null && !IsPublication)
            {

               var clientData = _context.Projects.Where(x => x.ProjectId == projectId).Include(x => x.Clients).Select(x => new { x.Clients.Contact , x.ProjectRef}).FirstOrDefault();
                client = clientData.Contact;
                projectOrEnquiryRef = clientData.ProjectRef;
                var phaseId = _context.Phase.Where(x => x.ProjectId == projectId).OrderBy(x => x.PhaseId).Select(x => x.PhaseId).LastOrDefault();
                var phaseFiles = _context.PhaseFiles
                    .Where(x => x.PhaseId == phaseId && !x.IsPublication)
                    .Select(x => new PhaseFilesDto
                    {
                        FileName = x.FileName,
                        FilePath = x.FilePath,
                        PhaseFileId = x.PhaseFileId,
                        PhaseId = x.PhaseId,
                        IsPublication = x.IsPublication
                    })
                    .ToList();

                PhasefileView = new PhasefileView
                {
                    IsPublication = phaseFiles.FirstOrDefault()?.IsPublication,
                    PhaseId = phaseId, // Since there's only one PhaseId
                    ProposalId = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Proposal_Manuscript_Thesis"))?.PhaseFileId,
                    ProposalPath = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Proposal_Manuscript_Thesis"))?.FilePath,
                    Proposal = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Proposal_Manuscript_Thesis"))?.FileName,
                    VisoId = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Viso"))?.PhaseFileId,
                    VisoPath = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Viso"))?.FilePath,
                    Viso = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Viso"))?.FileName,
                    ReferencePaperId = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("ReferencePaper"))?.PhaseFileId,
                    ReferencePaperPath = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("ReferencePaper"))?.FilePath,
                    ReferencePaper = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("ReferencePaper"))?.FileName,
                    OthersId = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Others"))?.PhaseFileId,
                    OthersPath = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Others"))?.FilePath,
                    Others = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Others"))?.FileName,
                    CodeId = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Code"))?.PhaseFileId,
                    CodePath = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Code"))?.FilePath,
                    Code = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Code"))?.FileName,
                    DataSetId = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("DataSet"))?.PhaseFileId,
                    DataSetPath = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("DataSet"))?.FilePath,
                    DataSet = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("DataSet"))?.FileName,
                    GraphId = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Graph"))?.PhaseFileId,
                    GraphPath = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Graph"))?.FilePath,
                    Graph = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Graph"))?.FileName,
                    OthersPgmId = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Others(p)"))?.PhaseFileId,
                    OthersPgmPath = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Others(p)"))?.FilePath,
                    OthersPgm = phaseFiles.FirstOrDefault(x => x.FilePath.Contains("Others(p)"))?.FileName
                };

                var lastplag = _context
                    .Plagiarism
                    .Where(x => x.PhaseId == phaseId).OrderBy(x => x.PlagiarismId)
                    .Select(x => x.PlagiarismId)
                    .LastOrDefault();

                if (lastplag != 0)
                {
                    var recipients = _context
                        .PlagiarismRecipient
                        .Where(x => x.PlagiarismId == lastplag && x.IsUploaded).Select(x => new
                        {
                            UploadedFileName = x.UploadedFileName,
                            UploadedFilePath = x.UploadedFilePath
                        })
                        .ToList();

                    plagFiles = new PlagiarismfileView
                    {
                        PlagFileName = recipients.FirstOrDefault().UploadedFileName.Contains(".docx") ? recipients.FirstOrDefault().UploadedFileName : null,
                        PlagFilePath = recipients.FirstOrDefault().UploadedFileName.Contains(".docx") ? recipients.FirstOrDefault().UploadedFilePath : null,
                        AIFileName = !recipients.FirstOrDefault().UploadedFileName.Contains(".docx") ? recipients.FirstOrDefault().UploadedFileName : null,
                        AIFilePath = !recipients.FirstOrDefault().UploadedFileName.Contains(".docx") ? recipients.FirstOrDefault().UploadedFilePath : null,
                    };
                }
            }
            else if (projectId != null && IsPublication)
            {
                var clientData = _context.Projects.Where(x => x.ProjectId == projectId).Include(x => x.Clients).Select(x => new { x.Clients.Contact, x.ProjectRef }).FirstOrDefault();
                client = clientData.Contact;
                projectOrEnquiryRef = clientData.ProjectRef;
            }
            var replyDetails = _context.Emails.Where(x => x.EmailId == emailId).Select(x => new { x.MessageId , x.Subject, x.Body}).FirstOrDefault();
            if (client != null)
            {
                replyEmail.ToAddress = !string.IsNullOrEmpty(client) && client.Contains(" ")
                        ? client.Split(' ')[1]
                        : null;
                replyEmail.TechTL = techTL;
                replyEmail.PgmTL = pgmTL;
                replyEmail.MessageId = !string.IsNullOrEmpty(replyDetails.MessageId) ? replyDetails.MessageId : null;
                replyEmail.Subject = (!string.IsNullOrEmpty(replyDetails.Subject) && replyDetails.Subject.Contains(projectOrEnquiryRef)) ? replyDetails.Subject : $"{replyDetails.Subject} | {projectOrEnquiryRef}";
                replyEmail.OriginalMessage = !string.IsNullOrEmpty(replyDetails.Body) ? replyDetails.Body : null;
                replyEmail.EnquiryId = enquiryId;
                replyEmail.ProjectId = projectId;
                replyEmail.Proposal = PhasefileView.Proposal;
                replyEmail.ProposalPath = PhasefileView.ProposalPath;
                replyEmail.ReferencePaper = PhasefileView.ReferencePaper;
                replyEmail.ReferencePaperPath = PhasefileView.ReferencePaperPath;
                replyEmail.Viso = PhasefileView.Viso;
                replyEmail.VisoPath = PhasefileView.VisoPath;
                replyEmail.Others = PhasefileView.Others;
                replyEmail.OthersPath = PhasefileView.OthersPath;
                replyEmail.Code = PhasefileView.Code;
                replyEmail.CodePath = PhasefileView.CodePath;
                replyEmail.DataSet = PhasefileView.DataSet;
                replyEmail.DataSetPath = PhasefileView.DataSetPath;
                replyEmail.Graph = PhasefileView.Graph;
                replyEmail.GraphPath = PhasefileView.GraphPath;
                replyEmail.OthersPgm = PhasefileView.OthersPgm;
                replyEmail.OthersPgmPath = PhasefileView.OthersPgmPath;
                replyEmail.PlagFileName = plagFiles.PlagFileName;
                replyEmail.PlagFilePath = plagFiles.PlagFilePath;
                replyEmail.AIFileName = plagFiles.AIFileName;
                replyEmail.AIFilePath = plagFiles.AIFilePath;

                return (true, new string[] { }, replyEmail);
            }

            return (false, new string[] { "Client not found" }, null);
        }
        catch (Exception ex)
        {
            return (false, new string[] { ex.Message }, null);
        }
    }
    public async Task<(bool Succeeded, string[] Errors, List<dynamic> Attachments)> CreateSentEmailAsync(ComposedEmailDto composedMail, string SenderName, string SenderEmail)
    {
        var errors = new List<string>();

        try
        {
            if(_session.GetString("Dept") == Enum.Department.Tech.ToString() && _session.GetString("Role") != Enum.Roles.Manager.ToString())
            {
                composedMail.IsTechVisibility = true;
            }
            if (_session.GetString("Dept") == Enum.Department.Programming.ToString() && _session.GetString("Role") != Enum.Roles.Manager.ToString())
            {
                composedMail.IsProgrammerVisibility = true;
            }
            var email = new Emails
            {
                FromAddress = SenderEmail,
                ClientName = SenderName,
                ToAddress = composedMail.ToAddress,
                Subject = composedMail.Subject,
                Body = composedMail.Message,
                UpdatedMessage = $"{composedMail.Subject}\n{composedMail.Message}",
                ReceivedDate = DateTime.Now,
                EnquiryId = composedMail.EnquiryId,
                ProjectId = composedMail.ProjectId,
                IsSender = true,
                Visibility = composedMail.Visibility,
                IsPublication = composedMail.IsPublication,
                IsTechVisibility = composedMail.IsTechVisibility,
                IsProgrammerVisibility = composedMail.IsProgrammerVisibility
            };

            _context.Emails.Add(email);
            await _context.SaveChangesAsync();
            if (composedMail.SelectedPgmFiles != null && composedMail.SelectedPgmFiles.Any())
            {
                foreach (var selectedPgmFile in composedMail.SelectedPgmFiles)
                {                
                        _context.EmailAttachmentsFiles.Add(new EmailAttachmentsFiles
                        {
                            EmailId = email.EmailId,
                            AttachmentFilePath = selectedPgmFile,
                            AttachmentFileName = Path.GetFileName(selectedPgmFile),
                            IsSelected = true
                        });
                }
                await _context.SaveChangesAsync();
            }
            if (composedMail.SelectedFiles != null && composedMail.SelectedFiles.Any())
            {
                foreach (var selectedFiles in composedMail.SelectedFiles)
                {
                    _context.EmailAttachmentsFiles.Add(new EmailAttachmentsFiles
                    {
                        EmailId = email.EmailId,
                        AttachmentFilePath = selectedFiles,
                        AttachmentFileName = Path.GetFileName(selectedFiles),
                        IsSelected = true
                    });
                }
                await _context.SaveChangesAsync();
            }

            if (composedMail.AttachmentFiles != null && composedMail.AttachmentFiles.Any())
            {
                foreach (var attachment in composedMail.AttachmentFiles)
                {
                    var (success, attachErrors) = await SaveSentAttachments(attachment, email.EmailId);
                    if (!success)
                    {
                        errors.AddRange(attachErrors);
                    }
                    else
                    {
                        _context.EmailAttachmentsFiles.Add(new EmailAttachmentsFiles
                        {
                            EmailId = email.EmailId,
                            AttachmentFilePath = attachErrors.First(),
                            AttachmentFileName = Path.GetFileName(attachment.FileName),
                            IsSelected = true
                        });
                    }
                }
                await _context.SaveChangesAsync();
            }

            var attachments =  _context.EmailAttachmentsFiles
                .Where(x => x.EmailId == email.EmailId)
                .Select(x => (dynamic)new
                {
                    AttachmentId = x.EmailAttachmentId,
                    AttachmentFileName = x.AttachmentFileName,
                    AttachmentFilePath = x.AttachmentFilePath
                })
                .ToList();

            if (errors.Any())
            {
                return (false, errors.ToArray(), null);
            }

            return (true, Array.Empty<string>(), attachments);
        }
        catch (Exception ex)
        {
            errors.Add(ex.Message);
            return (false, errors.ToArray(), null);
        }
    }
    private async Task<(bool Succeeded, string[] Errors)> SaveSentAttachments(IFormFile attachment, int emailId)
    {
        try
        {
            string folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", "Send");

            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath); 
            }

            string fileName = Path.GetFileName(attachment.FileName);
            string filePath = Path.Combine(folderPath, fileName);

            using (var fileStream = new FileStream(filePath, FileMode.Create))
            {
                await attachment.CopyToAsync(fileStream);
            }

            return (true, new[] { filePath }); 
        }
        catch (Exception ex)
        {
            return (false, new[] { ex.Message }); 
        }
    }
    public bool SetUrlToEmailAttachmentAsync(string OriginalUrl, string ShortUrl, int AttachmentId)
    {
        var attachment = _context.EmailAttachmentsFiles.Find(AttachmentId);
        if (attachment != null)
        {
            attachment.OriginalUrl = OriginalUrl;
            attachment.ShortUrl = ShortUrl;
            _context.Update(attachment);
             _context.SaveChanges();
            return true;
        }
        else
        {
            return false;
        }
    }
    public async Task<string> GetOriginalUrlAsync(string ShortUrl)
    {
        var attachment = _context.EmailAttachmentsFiles.Where(x=> x.ShortUrl == ShortUrl).Select(x=> x.OriginalUrl).FirstOrDefault();
        return attachment;
    }
    public async Task<string> GetOriginalFilePathAsync(string shortUrl)
    {
        var attachment = await _context.EmailAttachmentsFiles
            .Where(x => x.ShortUrl == shortUrl)
            .Select(x => x.AttachmentFilePath)
            .FirstOrDefaultAsync();

        return attachment; // Return null if not found
    }
}
