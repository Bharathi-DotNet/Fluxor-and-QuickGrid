﻿using Enquiry.Blazor.Models;
using Enquiry.Blazor.Services.Interface;
using Hangfire;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;


namespace Enquiry.Blazor.Services
{
    public class JobHostedService : IHostedService
    {
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly IBackgroundJobClient _backgroundJobClient;
        private readonly ISlack _slack;
        private readonly IRecurringJobManager _recurringJobManager;
        public readonly string _outputDirectory = string.Empty;
        public readonly string _htmlFilePathBirthday = string.Empty;
        public readonly string _htmlFilePathAnniversary = string.Empty;
        private Timer _timer;

        public JobHostedService(IServiceScopeFactory scopeFactory, IBackgroundJobClient backgroundJobClient, ISlack slack,
            IRecurringJobManager recurringJobManager)
        {
            _scopeFactory = scopeFactory;
            _backgroundJobClient = backgroundJobClient;
            _slack = slack;
            _recurringJobManager = recurringJobManager;
            _timer = new Timer(ExecuteScheduledTask, null, TimeSpan.Zero, TimeSpan.FromMinutes(2));
        }
        public Task StartAsync(CancellationToken cancellationToken)
        {
            // Define the local times for each job
            TimeSpan localTimeToRunJob1 = new TimeSpan(8, 0, 0); // 8:00 AM local time for Job 1 Birthday
            TimeSpan localTimeToRunJob2 = new TimeSpan(11, 30, 0); // 11:30 AM local time for Job 2
            TimeSpan localTimeToRunJob3 = new TimeSpan(17, 0, 0); // 5:00 PM local time for Job 3
            TimeSpan localTimeToRunJob4 = new TimeSpan(10, 30, 0); // 10:00 AM local time for Job 1 Anniversary

            // Convert the local times to UTC
            DateTime localDateTimeToRunJob1 = DateTime.Today.Add(localTimeToRunJob1);
            DateTime utcDateTimeToRunJob1 = localDateTimeToRunJob1.ToUniversalTime();
            TimeSpan utcTimeToRunJob1 = utcDateTimeToRunJob1.TimeOfDay;

            DateTime localDateTimeToRunJob2 = DateTime.Today.Add(localTimeToRunJob2);
            DateTime utcDateTimeToRunJob2 = localDateTimeToRunJob2.ToUniversalTime();
            TimeSpan utcTimeToRunJob2 = utcDateTimeToRunJob2.TimeOfDay;

            DateTime localDateTimeToRunJob3 = DateTime.Today.Add(localTimeToRunJob3);
            DateTime utcDateTimeToRunJob3 = localDateTimeToRunJob3.ToUniversalTime();
            TimeSpan utcTimeToRunJob3 = utcDateTimeToRunJob3.TimeOfDay;

            DateTime localDateTimeToRunJob4 = DateTime.Today.Add(localTimeToRunJob4);
            DateTime utcDateTimeToRunJob4 = localDateTimeToRunJob4.ToUniversalTime();
            TimeSpan utcTimeToRunJob4 = utcDateTimeToRunJob4.TimeOfDay;

            // Schedule the daily job to check for birthdays and anniversary
            _recurringJobManager.AddOrUpdate(
                "DailyBirthdayListJobTriggerMorning",
                () => GetEmployeeBirthdayListOf7Days(),
             Cron.Daily(utcTimeToRunJob2.Hours, utcTimeToRunJob2.Minutes)
            );
            _recurringJobManager.AddOrUpdate(
                "DailyBirthdayListJobTriggerEvening",
                () => GetEmployeeBirthdayListOf7Days(),
             Cron.Daily(utcTimeToRunJob3.Hours, utcTimeToRunJob3.Minutes)
            );
            _recurringJobManager.AddOrUpdate(
                "DailyAnniversaryListJobTriggerMorning",
                () => GetEmployeeAnniversaryListOf7Days(),
             Cron.Daily(utcTimeToRunJob2.Hours, utcTimeToRunJob2.Minutes)
            );
            _recurringJobManager.AddOrUpdate(
                "DailyAnniversaryListJobTriggerEvening",
                () => GetEmployeeAnniversaryListOf7Days(),
             Cron.Daily(utcTimeToRunJob3.Hours, utcTimeToRunJob3.Minutes)
            );
            _recurringJobManager.AddOrUpdate(
                "DailyBirthdayGreetingJob",
                () => SendEmployeeBirthdayGreetings(),
             Cron.Daily(utcTimeToRunJob1.Hours, utcTimeToRunJob1.Minutes)
            );
            _recurringJobManager.AddOrUpdate(
                "DailyAnniversaryGreetingJob",
                () => SendEmployeeAnniversaryGreetings(),
             Cron.Daily(utcTimeToRunJob4.Hours, utcTimeToRunJob4.Minutes)
            );
            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }

        public async Task GetEmployeeBirthdayListOf7Days()
        {
            using (var scope = _scopeFactory.CreateScope())
            {
                var _context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

                var today = DateTime.Today;
                var week = today.AddDays(7);
                try
                {
                    var query = @"
                        SELECT *
                        FROM Employees
                        WHERE IsActive = 1
                        AND (
                            (MONTH(DOB) = MONTH(CURDATE()) AND DAY(DOB) >= DAY(CURDATE()))
                            OR 
                            (MONTH(DOB) = MONTH(DATE_ADD(CURDATE(), INTERVAL 7 DAY)) AND DAY(DOB) <= DAY(DATE_ADD(CURDATE(), INTERVAL 7 DAY)))
                            OR
                            (MONTH(CURDATE()) = 12 AND MONTH(DATE_ADD(CURDATE(), INTERVAL 7 DAY)) = 1 AND MONTH(DOB) = 1 AND DAY(DOB) <= DAY(DATE_ADD(CURDATE(), INTERVAL 7 DAY)))
                        )
                        AND (
                            (DATE(CONCAT(YEAR(CURDATE()), '-', MONTH(DOB), '-', DAY(DOB))) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY))
                            OR
                            (DATE(CONCAT(YEAR(CURDATE()) + 1, '-', MONTH(DOB), '-', DAY(DOB))) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY))
                        );
                    ";

                    var birthday = await _context.Employees.FromSqlRaw(query).ToListAsync();

                    if (birthday.Count() > 0)
                    {
                        IList<string> employeeName = new List<string>();
                        foreach (var user in birthday)
                        {
                            if (string.IsNullOrEmpty(user.BirthdayPhotoUrl))
                            {
                                employeeName.Add($"{user.EmployeeName} - {user.IdentityNo}");
                            }
                        }
                        //var manager = await _context.Employees.Where(x => x.IsActive == true && x.DeptId == 1 && x.RoleId == 1).ToListAsync();
                        string[] manager = new string[] { "U039CQMFUH4", "U03DDTR2WLX" };
                        var stringToJoinEmployees = string.Join(", ", employeeName);
                        foreach (var memberId in manager)
                        {
                            _backgroundJobClient.Schedule(() => _slack.SendMessage($"Upcoming birthdays for {stringToJoinEmployees}. Please upload the greetings", memberId), TimeSpan.FromSeconds(5));
                        }
                    }
                }
                catch (Exception ex)
                {

                    throw;
                }


            }
        }

        public async Task GetEmployeeAnniversaryListOf7Days()
        {
            using (var scope = _scopeFactory.CreateScope())
            {
                var _context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

                var today = DateTime.Today;
                var week = today.AddDays(7);
                try
                {
                    var query = @"
                        SELECT *
                        FROM Employees
                        WHERE IsActive = 1
                        AND (
                            (MONTH(DOJ) = MONTH(CURDATE()) AND DAY(DOJ) >= DAY(CURDATE()))
                            OR 
                            (MONTH(DOJ) = MONTH(DATE_ADD(CURDATE(), INTERVAL 7 DAY)) AND DAY(DOJ) <= DAY(DATE_ADD(CURDATE(), INTERVAL 7 DAY)))
                            OR
                            (MONTH(CURDATE()) = 12 AND MONTH(DATE_ADD(CURDATE(), INTERVAL 7 DAY)) = 1 AND MONTH(DOJ) = 1 AND DAY(DOJ) <= DAY(DATE_ADD(CURDATE(), INTERVAL 7 DAY)))
                        )
                        AND (
                            (DATE(CONCAT(YEAR(CURDATE()), '-', MONTH(DOJ), '-', DAY(DOJ))) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY))
                            OR
                            (DATE(CONCAT(YEAR(CURDATE()) + 1, '-', MONTH(DOJ), '-', DAY(DOJ))) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY))
                        );
                    ";

                    var anniversary = await _context.Employees.FromSqlRaw(query).ToListAsync();

                    if (anniversary.Count() > 0)
                    {
                        IList<string> employeeName = new List<string>();
                        foreach (var user in anniversary)
                        {
                            if (string.IsNullOrEmpty(user.AnniversaryPhotoUrl))
                            {
                                employeeName.Add($"{user.EmployeeName} - {user.IdentityNo}");
                            }
                        }
                        //var manager = await _context.Employees.Where(x => x.IsActive == true && x.DeptId == 1 && x.RoleId == 1).ToListAsync();
                        string[] manager = new string[] { "U039CQMFUH4", "U03DDTR2WLX" };
                        var stringToJoinEmployees = string.Join(", ", employeeName);
                        foreach (var memberId in manager)
                        {
                            _backgroundJobClient.Schedule(() => _slack.SendMessage($"Upcoming anniversary for {stringToJoinEmployees}. Please upload the greetings", memberId), TimeSpan.FromSeconds(5));
                        }
                    }
                }
                catch (Exception ex)
                {

                    throw;
                }


            }
        }

        public async Task SendEmployeeBirthdayGreetings()
        {
            using (var scope = _scopeFactory.CreateScope())
            {
                var _context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

                var today = DateTime.Today;
                var week = today.AddDays(7);

                var birthday = await _context.Employees
                    .Where(u => u.DOB.Month == today.Month && u.DOB.Day == today.Day && u.IsActive)
                    .ToListAsync();
                if (birthday.Count() > 0)
                {
                    IList<string> employeeName = new List<string>();
                    foreach (var user in birthday)
                    {
                        employeeName.Add($"\r\n- {user.EmployeeName}, our {user.Designation}\r\n");
                        //if (!string.IsNullOrEmpty(user.BirthdayPhotoUrl))
                        //{
                        //    string url = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", "birthday", user.BirthdayPhotoUrl);
                        //    if (System.IO.File.Exists(url))
                        //    {
                        //        string message = $":tada: Happy Birthday to our amazing team member! :tada:\r\nKENFRA Research is wishing a very happy birthday to:\r\n {user.EmployeeName}, our {user.Designation} \r\nWe appreciate all your hard work and dedication. May your special day be filled with joy and celebration. Here's to a year of success and happiness! :birthday::partying_face:";
                        //        byte[] fileBytes = await StreamCompression.GetDefaultPhotoBytesAsync(url);
                        //        string extension = ImageFormatHelper.GetImageExtension(fileBytes);
                        //        _backgroundJobClient.Schedule(() => _slack.SendMessageWithAttachment(message, "C0394S8MY23", "", user.EmployeeName, fileBytes, extension), TimeSpan.FromSeconds(10));
                        //    }
                        //}
                    }
                    var stringToJoinEmployees = string.Join(", ", employeeName).Replace(", ", " ");
                    string slackMessage = $":tada: Happy Birthday to our amazing team member(s)! :tada:\r\nKENFRA Research is wishing a very happy birthday to:{stringToJoinEmployees}We appreciate all your hard work and dedication. May your special day be filled with joy and celebration. Here's to a year of success and happiness! :birthday::partying_face:";
                    _backgroundJobClient.Schedule(() => _slack.SendMessage(slackMessage, "C06KQ3761CH"), TimeSpan.FromSeconds(5));
                }
            }
        }

        public async Task SendEmployeeAnniversaryGreetings()
        {
            using (var scope = _scopeFactory.CreateScope())
            {
                var _context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

                var today = DateTime.Today;
                var week = today.AddDays(7);

                var birthday = await _context.Employees
                    .Where(u => u.DOJ.Month == today.Month && u.DOJ.Day == today.Day && u.IsActive)
                    .ToListAsync();
                if (birthday.Any())
                {
                    IList<string> employeeName = new List<string>();
                    foreach (var user in birthday)
                    {
                        var workedYears = today.Year - user.DOJ.Year;
                        employeeName.Add($"\r\n- {user.EmployeeName}, our {user.Designation}, celebrating {workedYears} year(s)\r\n");
                        //if (!string.IsNullOrEmpty(user.AnniversaryPhotoUrl))
                        //{
                        //    string url = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", "anniversary", user.BirthdayPhotoUrl);
                        //    if (System.IO.File.Exists(url))
                        //    {
                        //        string message = $":tada: Happy Work Anniversary to our dedicated team member! :tada:\r\nKENFRA Research is celebrating the incredible milestones of:\r\n {user.EmployeeName}, our  {user.Designation}, celebrating {workedYears} years\r\nThank you all for your hard work and commitment. Here's to many more successful years together! :partying_face::clap:";
                        //        byte[] fileBytes = await StreamCompression.GetDefaultPhotoBytesAsync(url);
                        //        string extension = ImageFormatHelper.GetImageExtension(fileBytes);
                        //        _backgroundJobClient.Schedule(() => _slack.SendMessageWithAttachment(message, "C06KQ3761CH", "", user.EmployeeName, fileBytes, extension), TimeSpan.FromSeconds(10));
                        //    }
                        //}
                    }
                    var stringToJoinEmployees = string.Join(", ", employeeName).Replace(", ", " ");
                    string slackMessage = $":tada: Happy Work Anniversary to our dedicated team members! :tada:\r\nKENFRA Research is celebrating the incredible milestones of:{stringToJoinEmployees}Thank you all for your hard work and commitment. Here's to many more successful years together! :partying_face::clap:";
                    _backgroundJobClient.Schedule(() => _slack.SendMessage(slackMessage, "C0394S8MY23"), TimeSpan.FromSeconds(5));
                }
            }
        }

        private void ExecuteScheduledTask(object state)
        {
            //BackgroundJob.Schedule<EmailController>(
            //    controller => controller.FetchEmailsInBatches(50),
            //    TimeSpan.FromSeconds(5)
            //);
        }


        private TimeSpan ConvertLocalTimeToUtc(TimeSpan localTime)
        {
            // Assume the local time zone is the system's local time zone
            TimeZoneInfo localTimeZone = TimeZoneInfo.Local;

            // Get today's date in the local time zone
            DateTime localDateTime = DateTime.Today.Add(localTime);

            // Convert local date and time to UTC
            DateTime utcDateTime = TimeZoneInfo.ConvertTimeToUtc(localDateTime, localTimeZone);

            // Return the UTC time as a TimeSpan
            return utcDateTime.TimeOfDay;
        }

        private async Task GeneratePdfAsync(string EmployeeName, string kind)
        {
            if (!Directory.Exists(_outputDirectory))
            {
                Directory.CreateDirectory(_outputDirectory);
            }

            var outputFilePath = Path.Combine(_outputDirectory, $"{EmployeeName}.png");
            var htmlFilePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Templates", kind);
            if (Directory.Exists(htmlFilePath))
            {
                string[] files = Directory.GetFiles(_outputDirectory);

                // Delete each file
                foreach (string file in files)
                {
                    File.Delete(file);
                }
            }
            string htmlContent = File.ReadAllText(htmlFilePath);
            //await File.WriteAllTextAsync(htmlFilePath, htmlContent);
            string _wkhtmltopdfPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Rotativa", "wkhtmltoimage.exe");
            var psi = new ProcessStartInfo
            {
                FileName = _wkhtmltopdfPath,
                Arguments = $"\"{htmlFilePath}\" \"{outputFilePath}\"",
                RedirectStandardOutput = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };
            using (var process = new Process { StartInfo = psi })
            {
                process.Start();
                await process.WaitForExitAsync();
            }
        }
    }
}
