﻿using AutoMapper;
using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Models;
using Enquiry.Blazor.Services.Interface;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace Enquiry.Blazor.Services
{
    public class VisitorService : IVisitor
    {
        readonly ApplicationDbContext _context;
        readonly IMapper _mapper;
        private readonly ISession _session;

        public VisitorService(ApplicationDbContext context, IMapper mapper, IHttpContextAccessor httpContextAccessor)
        { _context = context; _mapper = mapper; _session = httpContextAccessor.HttpContext.Session; }

        public async Task<(bool Succeeded, string[] Error, IList<VisitorsListDto> Data)> GetVisitorAsync()
        {
            try
            {
                var data = await _context.Visitors.Include(x => x.Employees).ThenInclude(x => x.Department).Include(x => x.Clients).OrderByDescending(x=>x.LoginTime).Take(2000).ToListAsync();
                var result = _mapper.Map<IList<VisitorsListDto>>(data);
                return (true, new string[] { }, result);
            }
            catch (Exception ex)
            {
                return (false, new string[] { ex.Message }, null);
            }

        }

    }
}
