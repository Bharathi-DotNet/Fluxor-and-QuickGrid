﻿using Enquiry.Blazor.Models;
using Enquiry.Blazor.Services.Interface;
using Microsoft.Extensions.Options;
using SlackNet;
using SlackNet.WebApi;

namespace Enquiry.Blazor.Services
{
    public class SlackService : ISlack
    {
        private readonly ISlackApiClient _slack;
        private readonly SlackConfig _slackConfig;
        public SlackService(ISlackApiClient slack, IOptions<SlackConfig> slackConfig = null)
        {
            _slack = slack;
            _slackConfig = slackConfig.Value;
        }
        public async Task SendMessage(string text, string channel)
        {
            try
            {
                var user = await _slack.Users.List();
                var val = await _slack.Chat.PostMessage(new Message { Text = text, Channel = channel });
                Task.CompletedTask.Wait();
            }
            catch (Exception ex)
            {
                //throw;
            }
        }

        public async Task SendMessageWithAttachment(string text, string channel, string title, string fileName, byte[] file, string extension)
        {
            try
            {
                var api = new SlackServiceBuilder().UseApiToken(_slackConfig.ApiToken).GetApiClient();
                var result = await api.Files.Upload(file, extension, fileName + extension, title, text, null, new List<string>() { channel });

                //var imageMessage = new Message
                //{
                //    Channel = channel,
                //    Text = text,
                //    Attachments = new[]
                //    {
                //        new Attachment
                //        {
                //            Title = title,
                //            ImageUrl = imageUrl
                //        }
                //    }
                //};

                //var val = await _slack.Chat.PostMessage(imageMessage);
                Task.CompletedTask.Wait();
            }
            catch (Exception ex)
            {
                //throw;
            }
        }
    }
}
