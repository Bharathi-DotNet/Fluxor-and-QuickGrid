﻿using Enquiry.Blazor.Dtos;
using Enquiry.Blazor.Extensions;
using Enquiry.Blazor.Models;
using Enquiry.Blazor.Services.Interface;
using Microsoft.EntityFrameworkCore;

namespace Enquiry.Blazor.Services
{
    public class UserRepository
    {
        private readonly ApplicationDbContext _context;
        readonly IEmployee _employee;
        public UserRepository(ApplicationDbContext context, IEmployee employee)
        {
            _context = context;
            _employee = employee;
        }

        public async Task<User> GetUser(string username)
        {
            //if (CheckClientUser(username))
            //{
            //    return await GetClientUser(username);
            //}
            var val = await _context.Employees.Include(x => x.Department)
                .Include(x => x.Roles).SingleOrDefaultAsync(u => u.IdentityNo.Equals(username));
            var result = await _employee.GetPlagiarismEnabledForEmployeeAsync(val.EmpId);
            if (val == null || val.IsActive == false) return null;
            return new User()
            {
                Username = val.IdentityNo,
                Password = val.IsPasswordChanged? EncryptDecryptString.DecryptString(val.Password): val.Password,
                EmpId = val.EmpId.ToString(),
                Email = val.EmailId,
                EmployeeName = val.EmployeeName,
                Roles = new string[] { val.Roles.RoleName },
                Dept = val.Department.DeptName,
                EmployeePhotoUrl = val.EmployeePhotoUrl ?? null,
                SuperiorId = val.SuperiorId.ToString(),
                IsEnquiry = val.IsEnquiry.ToString(),
                PlagiarismEnabled = (result.employees != null ? 1 : 0).ToString(),
                MemberId = val.MemberId,
            };
        }

        public async Task<(string[] error, bool sucess)> ChangeUserPassword(ChangePasswordDto dto, int userId, string dept)
        {
            dynamic val = null;
            if (dept == "Client")
            {
                val = await _context.Clients.FirstOrDefaultAsync(x => x.EnquiryId == userId);
                if (string.IsNullOrEmpty(val.Password) && !val.Contact.Contains(dto.CurrentPassword)) return (new string[] { "Please check the current password" }, false);
            }
            else
            {
                val = await _context.Employees.FirstOrDefaultAsync(x => x.EmpId == userId);
            }
            
            if (val == null) return(new string[] {"Please check the current password, Can't able to fetch the employee details"}, false);
            string password = val.Password;
            if(!string.IsNullOrEmpty(val.Password) && val.IsPasswordChanged)
            {
                password = EncryptDecryptString.DecryptString(val.Password);
            }
            //if (!string.IsNullOrEmpty(val.Password) && password != dto.Password) return (new string[] { "Please check the current password" }, false);

            val.Password = EncryptDecryptString.EncryptString(dto.Password);
            val.IsPasswordChanged = true;
            _context.Update(val);
            int result = await _context.SaveChangesAsync();
            if(result > 0)
            {
                return (new string[] { "Successfully updated" }, true);
            }
            return (new string[] { "Something went wrong" }, false);
        }

        private bool CheckClientUser(string userName)
        {
            int numOfDigits = userName.Count(char.IsDigit);
            if(numOfDigits == 10)
            {
                return true;
            }
            return false;
        }

        public async Task<User> GetClientUser(string username)
        {
            var val = await _context.Clients.FirstOrDefaultAsync(x=>x.Contact.Contains(username));
            if (val == null) return null;
            return new User()
            {
                Username = username,
                Password = val.IsPasswordChanged ? EncryptDecryptString.DecryptString(val.Password) : username,
                EmpId = val.EnquiryId.ToString(),
                Email = val.Contact,
                EmployeeName = val.ClientName,
                Roles = new string[] { val.EnquiryRef},
                Dept = "Client",
            };
        }

        public int GenerateOtp()
        {
            Random random = new Random();
            int otp = random.Next(1000, 9999); // Generates a number between 100000 and 999999
            return otp;
        }

        public async Task<bool> ValidateOtp(LoginOtpDto dto, int userId)
        {
            var userAny = await _context.Employees.AnyAsync(x=>x.EmpId == userId && x.OtpGiven == dto.Otp);
            return userAny;
        }

        public async Task<int> GetUserOtp(int userId)
        {
            var otp = await _context.Employees.FindAsync(userId);
            return otp.OtpGiven ?? 0;
        }

        public async Task<bool> UpdateOtp(LoginOtpDto dto, int userId)
        {
            var user = await _context.Employees.FindAsync(userId);
            if(user != null)
            {
                user.OtpGiven = dto.Otp;
                user.DeviceName = dto.DeviceName;
                _context.Update(user);
                int result = await _context.SaveChangesAsync();
                if(result > 0)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
